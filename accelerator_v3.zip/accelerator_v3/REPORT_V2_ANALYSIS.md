# report_v2 analysis and accelerator_v3 changes

All five reports are Vitis HLS 2022.1 csynth results for the forced FP32
BERT-Base deployment shape: batch 1, sequence 128, hidden 768, 12 heads,
head dimension 64, and FFN intermediate 3072. The default profile is
`BERT_BALANCED` with 16 MAC lanes and 16 output lanes.

## Measured v2 results

| Kernel | Latency (cycles) | Clock target / estimated | BRAM | DSP | FF | LUT | URAM |
|---|---:|---:|---:|---:|---:|---:|---:|
| QKV | 10,068,203 | 5.00 / 5.00 ns | 256 | 1,324 | 138,657 | 139,190 | 32 |
| Attention core | 24,702,056 | 5.00 / 5.00 ns | 1,026 | 71 | 19,626 | 24,571 | 0 |
| Attention output + norm | 3,463,566 | 5.00 / 5.00 ns | 1,056 | 1,324 | 142,698 | 135,573 | 0 |
| FFN up + GELU | 13,807,200 | 5.00 / 5.00 ns | 261 | 1,362 | 142,530 | 133,768 | 96 |
| FFN down + norm | 12,793,171 | 5.00 / 5.00 ns | 800 | 1,324 | 148,205 | 149,159 | 96 |

The `m_axi` widening messages only state that 512-bit ports cannot be widened
beyond the configured maximum of 512 bits. They are not synthesis failures.

## Bottlenecks found in the reports

- In every A-W projection, `gemm_input_tiles` dominates the output-tile work.
  One K-tile iteration is about 674 cycles, including about 515 cycles spent
  copying the activation tile, while weight load is about 203 cycles and the
  parallel compute body about 155 cycles.
- Scalar output-tile clear and store each traverse 256 elements for an 8×32
  balanced tile even though the tile is already partitioned across 16 output
  lanes.
- Attention spends about 14,464 of 16,066 cycles per query row in QK score
  generation. Its 64-element dot product is divided across 16 lanes, but the
  final lane accumulation was expressed as a serial dependency chain.
- Softmax/SV and LayerNorm are materially smaller. LayerNorm already uses a
  cached, grouped implementation, so v3 does not replace its math or storage.
- Attention core plus attention output would total 2,082 BRAM, so they remain
  split across SLR1 and SLR2. FFN up plus FFN down total 1,061 BRAM and 2,686
  DSP, making their candidate SLR3 pairing the lower-memory option pending link.

## Changes made in accelerator_v3

1. The A-W engine reads activations directly from the banked resident matrix;
   it no longer copies an activation tile before every output tile.
2. Output-tile clear and store operate on `OUT_PAR` lanes in parallel.
3. QK lane reduction uses an explicit balanced adder tree for the supported
   8-lane and 16-lane profiles.
4. Compile-time checks reject an unsupported QK lane count.

The kernel names, argument order, packed weight layout, AXI bundles, stream
contracts, FP32 equations, BERT dimensions, Tcl entry points, and candidate
U250 SLR/DDR mapping remain unchanged from accelerator_v2.

## Verification status

This v3 package has only been statically reviewed in this workspace. New HLS
csynth reports are required to confirm latency, initiation interval, timing,
and resource usage. A post-link implementation report is still required to
confirm the candidate SLR placement and routing.
