#include "bert_kernel_args.h"
#include "gemm_act_weight.h"
#include "packed_io.h"
#include "stream_contracts.h"

using namespace bert;

/*
Architecture basis:
- Spatial FPGA: coarse operator kernel and FIFO edges.
- AutoTrans: a linear-specific A-W engine, distinct from attention A-A GEMM.
- ProTEA/Tiled QKV/UbiMoE: tile-major weights, persistent X, and time-multiplexed Q/K/V.

U250 adaptation:
- 512-bit DDR words and the selected bounded PE profile on candidate SLR0.
*/
extern "C" void bert_qkv_kernel(
    const axi_word_t* hidden_in,
    const axi_word_t* qkv_weights,
    const axi_word_t* qkv_parameters,
    tensor_stream_t& q_out,
    tensor_stream_t& k_out,
    tensor_stream_t& v_out,
    tensor_stream_t& residual_out,
    offset_t hidden_word_offset,
    offset_t wq_base_word,
    offset_t wk_base_word,
    offset_t wv_base_word,
    offset_t qkv_weight_layer_stride_words,
    offset_t bq_base_word,
    offset_t bk_base_word,
    offset_t bv_base_word,
    offset_t qkv_parameter_layer_stride_words,
    unsigned int layer_index) {
#pragma HLS INTERFACE m_axi port=hidden_in offset=slave bundle=gmem_act \
    max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=qkv_weights offset=slave bundle=gmem_qkv \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=qkv_parameters offset=slave bundle=gmem_qkv \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE axis port=q_out
#pragma HLS INTERFACE axis port=k_out
#pragma HLS INTERFACE axis port=v_out
#pragma HLS INTERFACE axis port=residual_out
#pragma HLS INTERFACE s_axilite port=hidden_in bundle=control
#pragma HLS INTERFACE s_axilite port=qkv_weights bundle=control
#pragma HLS INTERFACE s_axilite port=qkv_parameters bundle=control
#pragma HLS INTERFACE s_axilite port=hidden_word_offset bundle=control
#pragma HLS INTERFACE s_axilite port=wq_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=wk_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=wv_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=qkv_weight_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=bq_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=bk_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=bv_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=qkv_parameter_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=layer_index bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    float hidden[SEQ_LEN][HIDDEN_SIZE];
    float projection[SEQ_LEN][HIDDEN_SIZE];
#pragma HLS BIND_STORAGE variable=hidden type=ram_2p impl=uram
#pragma HLS BIND_STORAGE variable=projection type=ram_2p impl=bram
#pragma HLS ARRAY_PARTITION variable=hidden cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=projection cyclic factor=AXI_LANES dim=2

    const offset_t wq_word = layer_word_offset(
        wq_base_word, qkv_weight_layer_stride_words, layer_index);
    const offset_t wk_word = layer_word_offset(
        wk_base_word, qkv_weight_layer_stride_words, layer_index);
    const offset_t wv_word = layer_word_offset(
        wv_base_word, qkv_weight_layer_stride_words, layer_index);
    const offset_t bq_word = layer_word_offset(
        bq_base_word, qkv_parameter_layer_stride_words, layer_index);
    const offset_t bk_word = layer_word_offset(
        bk_base_word, qkv_parameter_layer_stride_words, layer_index);
    const offset_t bv_word = layer_word_offset(
        bv_base_word, qkv_parameter_layer_stride_words, layer_index);

    // X is loaded exactly once and remains resident for all three projections.
    load_packed_matrix<SEQ_LEN, HIDDEN_SIZE>(hidden_in, hidden_word_offset, hidden);

    gemm_act_weight<SEQ_LEN, HIDDEN_SIZE, HIDDEN_SIZE,
                    TILE_M, TILE_K, TILE_N>(
        hidden, qkv_weights, wq_word, qkv_parameters, bq_word, projection);
    stream_write_head_tensor(projection, q_out);

    gemm_act_weight<SEQ_LEN, HIDDEN_SIZE, HIDDEN_SIZE,
                    TILE_M, TILE_K, TILE_N>(
        hidden, qkv_weights, wk_word, qkv_parameters, bk_word, projection);
    stream_write_head_tensor(projection, k_out);

    gemm_act_weight<SEQ_LEN, HIDDEN_SIZE, HIDDEN_SIZE,
                    TILE_M, TILE_K, TILE_N>(
        hidden, qkv_weights, wv_word, qkv_parameters, bv_word, projection);
    stream_write_head_tensor(projection, v_out);

    // Emitted last so the downstream K3 residual path cannot block Q/K/V.
    stream_write_matrix<SEQ_LEN, HIDDEN_SIZE>(hidden, residual_out);
}
