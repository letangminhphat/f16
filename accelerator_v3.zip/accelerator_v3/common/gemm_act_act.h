#ifndef BERT_GEMM_ACT_ACT_H
#define BERT_GEMM_ACT_ACT_H

#include "bert_types.h"

namespace bert {

template <int LANES>
struct DotLaneReducer;

template <>
struct DotLaneReducer<8> {
    static accum_t reduce(const accum_t input[8]) {
#pragma HLS INLINE
        accum_t stage4[4];
        accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    reduce8_to4:
        for (int index = 0; index < 4; ++index) {
#pragma HLS UNROLL
            stage4[index] = input[index * 2] + input[index * 2 + 1];
        }
    reduce4_to2:
        for (int index = 0; index < 2; ++index) {
#pragma HLS UNROLL
            stage2[index] = stage4[index * 2] + stage4[index * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <>
struct DotLaneReducer<16> {
    static accum_t reduce(const accum_t input[16]) {
#pragma HLS INLINE
        accum_t stage8[8];
        accum_t stage4[4];
        accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage8 complete
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    reduce16_to8:
        for (int index = 0; index < 8; ++index) {
#pragma HLS UNROLL
            stage8[index] = input[index * 2] + input[index * 2 + 1];
        }
    reduce8_to4:
        for (int index = 0; index < 4; ++index) {
#pragma HLS UNROLL
            stage4[index] = stage8[index * 2] + stage8[index * 2 + 1];
        }
    reduce4_to2:
        for (int index = 0; index < 2; ++index) {
#pragma HLS UNROLL
            stage2[index] = stage4[index * 2] + stage4[index * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <int D>
accum_t dot_qk(const float query[D], const float key[D]) {
#pragma HLS INLINE
    accum_t partial[MAC_LANES];
#pragma HLS ARRAY_PARTITION variable=partial complete
initialize_dot_partial:
    for (int lane = 0; lane < MAC_LANES; ++lane) {
#pragma HLS UNROLL
        partial[lane] = 0.0f;
    }
dot_qk_dimension:
    for (int base = 0; base < D; base += MAC_LANES) {
#pragma HLS PIPELINE II=1
    dot_qk_lanes:
        for (int lane = 0; lane < MAC_LANES; ++lane) {
#pragma HLS UNROLL
            const int dim = base + lane;
            if (dim < D) {
                partial[lane] += query[dim] * key[dim];
            }
        }
    }
    return DotLaneReducer<MAC_LANES>::reduce(partial);
}

template <int N, int D>
void qk_row(const float query[D],
            const float keys[N][D],
            const float mask[N],
            unsigned int active_sequence_length,
            float scale,
            softmax_accum_t scores[N]) {
#pragma HLS INLINE
qk_row_keys:
    for (int key = 0; key < N; ++key) {
        softmax_accum_t score = dot_qk<D>(query, keys[key]) * scale;
        if (mask[key] == 0.0f || key >= static_cast<int>(active_sequence_length)) {
            score += ATTENTION_NEGATIVE_MASK;
        }
        scores[key] = score;
    }
}

template <int N, int D>
void weighted_value_row(const float probabilities[N],
                        const float values[N][D],
                        float context[D]) {
weighted_value_clear:
    for (int dim = 0; dim < D; ++dim) {
#pragma HLS PIPELINE II=1
        context[dim] = 0.0f;
    }
weighted_value_rows:
    for (int key = 0; key < N; ++key) {
    weighted_value_columns:
        for (int dim = 0; dim < D; ++dim) {
#pragma HLS PIPELINE II=1
            context[dim] += probabilities[key] * values[key][dim];
        }
    }
}

}  // namespace bert

#endif
