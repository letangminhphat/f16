#ifndef BERT_GEMM_ACT_WEIGHT_H
#define BERT_GEMM_ACT_WEIGHT_H

#include "gemm_tiled.h"

namespace bert {

template <int M, int K, int N, int TM, int TK, int TN>
void gemm_act_weight(const float input[M][K],
                     const axi_word_t* weights,
                     offset_t matrix_word_offset,
                     const axi_word_t* parameters,
                     offset_t bias_word_offset,
                     float output[M][N]) {
    float weight_tile[TK][TN];
    float output_tile[TM][TN];
#pragma HLS ARRAY_PARTITION variable=weight_tile cyclic factor=OUT_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=weight_tile cyclic factor=MAC_LANES dim=1
#pragma HLS ARRAY_PARTITION variable=output_tile cyclic factor=OUT_PAR dim=2

gemm_row_tiles:
    for (int row_base = 0; row_base < M; row_base += TM) {
    gemm_output_tiles:
        for (int output_base = 0; output_base < N; output_base += TN) {
            clear_output_tile<TM, TN>(output_tile);
        gemm_input_tiles:
            for (int input_base = 0; input_base < K; input_base += TK) {
                load_weight_tile<K, N, TK, TN>(
                    weights, matrix_word_offset, input_base, output_base, weight_tile);
                compute_output_tile_direct<M, K, TM, TK, TN>(
                    input, weight_tile, row_base, input_base, output_tile);
            }
            add_bias<N, TM, TN>(output_tile, parameters,
                                bias_word_offset, output_base);
            postprocess_and_emit<M, N, TM, TN>(
                output_tile, row_base, output_base, output);
        }
    }
}

}  // namespace bert

#endif
