#ifndef BERT_GEMM_TILED_H
#define BERT_GEMM_TILED_H

#include "bias_hls.h"
#include "bert_layout.h"
#include "packed_io.h"

namespace bert {

template <int K, int N, int TK, int TN>
void load_weight_tile(const axi_word_t* weights,
                      offset_t matrix_word_offset,
                      int input_base,
                      int output_base,
                      float tile[TK][TN]) {
    static_assert((TK * TN) % AXI_LANES == 0,
                  "A weight tile must contain a whole number of AXI words");
    const int output_tiles = (N + TN - 1) / TN;
    const int input_tile = input_base / TK;
    const int output_tile = output_base / TN;
    const offset_t tile_scalar_base =
        static_cast<offset_t>(input_tile * output_tiles + output_tile) * TK * TN;
load_weight_words:
    for (int word_index = 0; word_index < (TK * TN) / AXI_LANES; ++word_index) {
#pragma HLS PIPELINE II=1
        float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        unpack_scalar_array(
            weights[matrix_word_offset + tile_scalar_base / AXI_LANES + word_index],
            lanes);
    load_weight_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int flat = word_index * AXI_LANES + lane;
            const int input_lane = flat / TN;
            const int output_lane = flat % TN;
            const int global_input = input_base + input_lane;
            const int global_output = output_base + output_lane;
            tile[input_lane][output_lane] =
                (global_input < K && global_output < N) ? lanes[lane] : 0.0f;
        }
    }
}

template <int TM, int TN>
void clear_output_tile(float output[TM][TN]) {
clear_output_rows:
    for (int row = 0; row < TM; ++row) {
    clear_output_groups:
        for (int output_group = 0; output_group < TN; output_group += OUT_PAR) {
#pragma HLS PIPELINE II=1
        clear_output_lanes:
            for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
                const int output_lane = output_group + lane;
                if (output_lane < TN) {
                    output[row][output_lane] = 0.0f;
                }
            }
        }
    }
}

template <int M, int K, int TM, int TK, int TN>
void compute_output_tile_direct(const float input[M][K],
                                const float weight[TK][TN],
                                int row_base,
                                int input_base,
                                float output[TM][TN]) {
compute_direct_input_groups:
    for (int input_group = 0; input_group < TK; input_group += MAC_LANES) {
    compute_direct_output_groups:
        for (int output_group = 0; output_group < TN; output_group += OUT_PAR) {
        compute_direct_rows:
            for (int row = 0; row < TM; ++row) {
#pragma HLS PIPELINE II=1
            compute_direct_outputs:
                for (int output_lane = 0; output_lane < OUT_PAR; ++output_lane) {
#pragma HLS UNROLL
                    const int local_output = output_group + output_lane;
                    const int global_row = row_base + row;
                    accum_t partial = 0.0f;
                compute_direct_mac_lanes:
                    for (int mac_lane = 0; mac_lane < MAC_LANES; ++mac_lane) {
#pragma HLS UNROLL
                        const int local_input = input_group + mac_lane;
                        const int global_input = input_base + local_input;
                        if (global_row < M && global_input < K &&
                            local_output < TN) {
                            partial += input[global_row][global_input]
                                     * weight[local_input][local_output];
                        }
                    }
                    if (global_row < M && local_output < TN) {
                        output[row][local_output] += partial;
                    }
                }
            }
        }
    }
}

template <int N, int TM, int TN>
void add_bias(float output[TM][TN],
              const axi_word_t* parameters,
              offset_t bias_word_offset,
              int output_base) {
    float bias_tile[TN];
#pragma HLS ARRAY_PARTITION variable=bias_tile cyclic factor=OUT_PAR
    load_bias_tile<TN>(parameters, bias_word_offset, output_base, bias_tile);
add_bias_output_groups:
    for (int output_group = 0; output_group < TN; output_group += OUT_PAR) {
    add_bias_rows:
        for (int row = 0; row < TM; ++row) {
#pragma HLS PIPELINE II=1
        add_bias_lanes:
            for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
                const int output_lane = output_group + lane;
                const int global_output = output_base + output_lane;
                if (output_lane < TN && global_output < N) {
                    output[row][output_lane] += bias_tile[output_lane];
                }
            }
        }
    }
}

template <int M, int N, int TM, int TN>
void store_output_tile(const float tile[TM][TN],
                       int row_base,
                       int output_base,
                       float output[M][N]) {
store_output_rows:
    for (int row = 0; row < TM; ++row) {
    store_output_groups:
        for (int output_group = 0; output_group < TN; output_group += OUT_PAR) {
#pragma HLS PIPELINE II=1
        store_output_lanes:
            for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
                const int output_lane = output_group + lane;
                const int global_row = row_base + row;
                const int global_output = output_base + output_lane;
                if (output_lane < TN && global_row < M && global_output < N) {
                    output[global_row][global_output] = tile[row][output_lane];
                }
            }
        }
    }
}

template <int M, int N, int TM, int TN>
void postprocess_and_emit(const float tile[TM][TN],
                          int row_base,
                          int output_base,
                          float output[M][N]) {
#pragma HLS INLINE
    // Identity postprocess for the shared GEMM. GELU and AddNorm are fused by
    // their owning major kernels before any value leaves the chip.
    store_output_tile<M, N, TM, TN>(tile, row_base, output_base, output);
}

}  // namespace bert

#endif
