#include "bert_kernel_args.h"
#include "fused_ffn_engine.h"
#include "gelu_hls.h"
#include "layernorm_hls.h"
#include "packed_io.h"
#include "stream_contracts.h"

using namespace bert;

extern "C" void bert_ffn_fused_kernel(
    const axi_word_t* w1_weights,
    const axi_word_t* ffn_up_parameters,
    const axi_word_t* w2_weights,
    const axi_word_t* ffn_down_parameters,
    axi_word_t* hidden_out,
    tensor_stream_t& ffn_input_in,
    offset_t output_word_offset,
    offset_t w1_base_word,
    offset_t w1_layer_stride_words,
    offset_t b1_base_word,
    offset_t b1_layer_stride_words,
    offset_t w2_base_word,
    offset_t w2_layer_stride_words,
    offset_t b2_base_word,
    offset_t gamma_base_word,
    offset_t beta_base_word,
    offset_t down_parameter_layer_stride_words,
    unsigned int layer_index) {
#pragma HLS INTERFACE m_axi port=w1_weights offset=slave bundle=gmem_w1 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=ffn_up_parameters offset=slave bundle=gmem_w1 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=w2_weights offset=slave bundle=gmem_w2 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=ffn_down_parameters offset=slave bundle=gmem_w2 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=hidden_out offset=slave bundle=gmem_act \
    max_write_burst_length=64 num_write_outstanding=16
#pragma HLS INTERFACE axis port=ffn_input_in
#pragma HLS INTERFACE s_axilite port=w1_weights bundle=control
#pragma HLS INTERFACE s_axilite port=ffn_up_parameters bundle=control
#pragma HLS INTERFACE s_axilite port=w2_weights bundle=control
#pragma HLS INTERFACE s_axilite port=ffn_down_parameters bundle=control
#pragma HLS INTERFACE s_axilite port=hidden_out bundle=control
#pragma HLS INTERFACE s_axilite port=output_word_offset bundle=control
#pragma HLS INTERFACE s_axilite port=w1_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=w1_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=b1_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=b1_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=w2_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=w2_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=b2_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=gamma_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=beta_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=down_parameter_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=layer_index bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control
#pragma HLS ALLOCATION instances=fused_ffn_mac_engine limit=1 function
#pragma HLS ALLOCATION instances=fused_ffn_prefetch_compute limit=1 function

    float hidden[FUSED_HIDDEN_BLOCKS][SEQ_LEN][FUSED_FFN_BLOCK_K];
    float intermediate_block[SEQ_LEN][FUSED_FFN_BLOCK_K];
    float projection[FUSED_HIDDEN_BLOCKS][SEQ_LEN][FUSED_FFN_BLOCK_K];
    float b2_cache[HIDDEN_SIZE];
    float gamma_cache[HIDDEN_SIZE];
    float beta_cache[HIDDEN_SIZE];
#pragma HLS BIND_STORAGE variable=hidden type=ram_2p impl=uram
#pragma HLS BIND_STORAGE variable=intermediate_block type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=projection type=ram_2p impl=uram
#pragma HLS BIND_STORAGE variable=b2_cache type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=gamma_cache type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=beta_cache type=ram_2p impl=bram
#pragma HLS ARRAY_PARTITION variable=hidden complete dim=1
#pragma HLS ARRAY_PARTITION variable=hidden cyclic factor=FFN_BUFFER_BANKS dim=3
#pragma HLS ARRAY_PARTITION variable=intermediate_block cyclic factor=FFN_BUFFER_BANKS dim=2
#pragma HLS ARRAY_PARTITION variable=projection complete dim=1
#pragma HLS ARRAY_PARTITION variable=projection cyclic factor=FFN_BUFFER_BANKS dim=3
#pragma HLS ARRAY_PARTITION variable=b2_cache cyclic factor=AXI_LANES
#pragma HLS ARRAY_PARTITION variable=gamma_cache cyclic factor=AXI_LANES
#pragma HLS ARRAY_PARTITION variable=beta_cache cyclic factor=AXI_LANES

    read_fused_hidden_blocks(ffn_input_in, hidden);

    const offset_t w1_word = layer_word_offset(
        w1_base_word, w1_layer_stride_words, layer_index);
    const offset_t b1_word = layer_word_offset(
        b1_base_word, b1_layer_stride_words, layer_index);
    const offset_t w2_word = layer_word_offset(
        w2_base_word, w2_layer_stride_words, layer_index);
    const offset_t b2_word = layer_word_offset(
        b2_base_word, down_parameter_layer_stride_words, layer_index);
    const offset_t gamma_word = layer_word_offset(
        gamma_base_word, down_parameter_layer_stride_words, layer_index);
    const offset_t beta_word = layer_word_offset(
        beta_base_word, down_parameter_layer_stride_words, layer_index);

    load_packed_vector<HIDDEN_SIZE>(
        ffn_down_parameters, b2_word, b2_cache);
    load_layernorm_parameters<HIDDEN_SIZE>(
        ffn_down_parameters, gamma_word, beta_word, gamma_cache, beta_cache);

initialize_fused_projection_blocks:
    for (int hidden_block = 0;
         hidden_block < FUSED_HIDDEN_BLOCKS;
         ++hidden_block) {
    initialize_fused_projection_rows:
        for (int row = 0; row < SEQ_LEN; ++row) {
        initialize_fused_projection_groups:
            for (int base = 0; base < FUSED_FFN_BLOCK_K;
                 base += AXI_LANES) {
#pragma HLS PIPELINE II=1
            initialize_fused_projection_lanes:
                for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                    const int local_output = base + lane;
                    projection[hidden_block][row][local_output] = 0.0f;
                }
            }
        }
    }

    float weight_ping[FUSED_FFN_BLOCK_K][FUSED_FFN_TILE_N];
    float weight_pong[FUSED_FFN_BLOCK_K][FUSED_FFN_TILE_N];
#pragma HLS ARRAY_PARTITION variable=weight_ping cyclic factor=FFN_MAC_LANES dim=1
#pragma HLS ARRAY_PARTITION variable=weight_ping cyclic factor=FFN_OUT_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=weight_pong cyclic factor=FFN_MAC_LANES dim=1
#pragma HLS ARRAY_PARTITION variable=weight_pong cyclic factor=FFN_OUT_PAR dim=2

fused_intermediate_blocks:
    for (int intermediate_index = 0;
         intermediate_index < FUSED_INTERMEDIATE_BLOCKS;
         ++intermediate_index) {
        float b1_block[FUSED_FFN_BLOCK_K];
#pragma HLS ARRAY_PARTITION variable=b1_block cyclic factor=FFN_OUT_PAR
        load_packed_vector<FUSED_FFN_BLOCK_K>(
            ffn_up_parameters,
            b1_word + intermediate_index * (FUSED_FFN_BLOCK_K / AXI_LANES),
            b1_block);

    initialize_intermediate_rows:
        for (int row = 0; row < SEQ_LEN; ++row) {
        initialize_intermediate_groups:
            for (int base = 0; base < FUSED_FFN_BLOCK_K;
                 base += FFN_OUT_PAR) {
#pragma HLS PIPELINE II=1
            initialize_intermediate_lanes:
                for (int lane = 0; lane < FFN_OUT_PAR; ++lane) {
#pragma HLS UNROLL
                    intermediate_block[row][base + lane] = 0.0f;
                }
            }
        }

        load_fused_weight_tile_at_word(
            w1_weights,
            fused_w1_tile_word(w1_word, 0, intermediate_index, 0),
            weight_ping);
    fused_w1_tile_tasks:
        for (int task = 0;
             task < FUSED_TILES_PER_INTERMEDIATE_BLOCK - 1;
             ++task) {
            const int hidden_block = task / FUSED_SUBTILES_PER_BLOCK;
            const int sub_tile = task % FUSED_SUBTILES_PER_BLOCK;
            const int next_task = task + 1;
            const int next_hidden_block =
                next_task / FUSED_SUBTILES_PER_BLOCK;
            const int next_sub_tile =
                next_task % FUSED_SUBTILES_PER_BLOCK;
            const offset_t next_word = fused_w1_tile_word(
                w1_word, next_hidden_block, intermediate_index, next_sub_tile);
            if ((task & 1) == 0) {
                fused_ffn_prefetch_compute(
                    w1_weights, next_word, hidden[hidden_block],
                    sub_tile * FUSED_FFN_TILE_N, intermediate_block,
                    weight_ping, weight_pong);
            } else {
                fused_ffn_prefetch_compute(
                    w1_weights, next_word, hidden[hidden_block],
                    sub_tile * FUSED_FFN_TILE_N, intermediate_block,
                    weight_pong, weight_ping);
            }
        }
        const int last_w1_task = FUSED_TILES_PER_INTERMEDIATE_BLOCK - 1;
        const int last_w1_hidden =
            last_w1_task / FUSED_SUBTILES_PER_BLOCK;
        const int last_w1_subtile =
            last_w1_task % FUSED_SUBTILES_PER_BLOCK;
        if ((last_w1_task & 1) == 0) {
            fused_ffn_mac_engine(
                hidden[last_w1_hidden], weight_ping,
                last_w1_subtile * FUSED_FFN_TILE_N, intermediate_block);
        } else {
            fused_ffn_mac_engine(
                hidden[last_w1_hidden], weight_pong,
                last_w1_subtile * FUSED_FFN_TILE_N, intermediate_block);
        }

    fused_block_bias_gelu_rows:
        for (int row = 0; row < SEQ_LEN; ++row) {
        fused_block_bias_gelu_groups:
            for (int base = 0; base < FUSED_FFN_BLOCK_K;
                 base += FFN_GELU_PAR) {
#pragma HLS PIPELINE II=1
            fused_block_bias_gelu_lanes:
                for (int lane = 0; lane < FFN_GELU_PAR; ++lane) {
#pragma HLS UNROLL
                    const int index = base + lane;
                    intermediate_block[row][index] =
                        gelu_exact_source_formula(
                            intermediate_block[row][index] + b1_block[index]);
                }
            }
        }

        load_fused_weight_tile_at_word(
            w2_weights,
            fused_w2_tile_word(w2_word, intermediate_index, 0, 0),
            weight_ping);
    fused_w2_tile_tasks:
        for (int task = 0;
             task < FUSED_TILES_PER_INTERMEDIATE_BLOCK - 1;
             ++task) {
            const int hidden_block = task / FUSED_SUBTILES_PER_BLOCK;
            const int sub_tile = task % FUSED_SUBTILES_PER_BLOCK;
            const int next_task = task + 1;
            const int next_hidden_block =
                next_task / FUSED_SUBTILES_PER_BLOCK;
            const int next_sub_tile =
                next_task % FUSED_SUBTILES_PER_BLOCK;
            const offset_t next_word = fused_w2_tile_word(
                w2_word, intermediate_index,
                next_hidden_block, next_sub_tile);
            if ((task & 1) == 0) {
                fused_ffn_prefetch_compute(
                    w2_weights, next_word, intermediate_block,
                    sub_tile * FUSED_FFN_TILE_N, projection[hidden_block],
                    weight_ping, weight_pong);
            } else {
                fused_ffn_prefetch_compute(
                    w2_weights, next_word, intermediate_block,
                    sub_tile * FUSED_FFN_TILE_N, projection[hidden_block],
                    weight_pong, weight_ping);
            }
        }
        const int last_w2_task = FUSED_TILES_PER_INTERMEDIATE_BLOCK - 1;
        const int last_w2_hidden =
            last_w2_task / FUSED_SUBTILES_PER_BLOCK;
        const int last_w2_subtile =
            last_w2_task % FUSED_SUBTILES_PER_BLOCK;
        if ((last_w2_task & 1) == 0) {
            fused_ffn_mac_engine(
                intermediate_block, weight_ping,
                last_w2_subtile * FUSED_FFN_TILE_N,
                projection[last_w2_hidden]);
        } else {
            fused_ffn_mac_engine(
                intermediate_block, weight_pong,
                last_w2_subtile * FUSED_FFN_TILE_N,
                projection[last_w2_hidden]);
        }
    }

fused_output_tokens:
    for (int token = 0; token < SEQ_LEN; ++token) {
        float added[HIDDEN_SIZE];
        float normalized[HIDDEN_SIZE];
#pragma HLS ARRAY_PARTITION variable=added cyclic factor=AXI_LANES
#pragma HLS ARRAY_PARTITION variable=normalized cyclic factor=AXI_LANES
    assemble_fused_output_blocks:
        for (int hidden_block = 0;
             hidden_block < FUSED_HIDDEN_BLOCKS;
             ++hidden_block) {
        assemble_fused_output_groups:
            for (int base = 0; base < FUSED_FFN_BLOCK_K;
                 base += AXI_LANES) {
#pragma HLS PIPELINE II=1
            assemble_fused_output_lanes:
                for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                    const int local_hidden = base + lane;
                    const int global_hidden =
                        hidden_block * FUSED_FFN_BLOCK_K + local_hidden;
                    added[global_hidden] =
                        projection[hidden_block][token][local_hidden]
                        + b2_cache[global_hidden]
                        + hidden[hidden_block][token][local_hidden];
                }
            }
        }
        layernorm_token_cached<HIDDEN_SIZE>(
            added, gamma_cache, beta_cache, normalized);
        store_packed_vector<HIDDEN_SIZE>(
            hidden_out,
            output_word_offset
                + static_cast<offset_t>(token) * (HIDDEN_SIZE / AXI_LANES),
            normalized);
    }
}
