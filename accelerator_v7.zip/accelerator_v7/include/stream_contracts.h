#ifndef BERT_STREAM_CONTRACTS_H
#define BERT_STREAM_CONTRACTS_H

#include "bert_layout.h"
#include "bert_types.h"

namespace bert {

static const int HIDDEN_TENSOR_SCALARS = SEQ_LEN * HIDDEN_SIZE;
static const int HEAD_TENSOR_SCALARS = NUM_HEADS * SEQ_LEN * HEAD_DIM;
static const int HIDDEN_TENSOR_WORDS =
    (HIDDEN_TENSOR_SCALARS + AXI_LANES - 1) / AXI_LANES;
static const int HEAD_TENSOR_WORDS =
    (HEAD_TENSOR_SCALARS + AXI_LANES - 1) / AXI_LANES;
// Per-row/head ceilings describe logical regions. The physical stream is
// continuously packed and introduces no padding at token or head boundaries.
static const int HIDDEN_WORDS_PER_TOKEN_CEILING =
    (HIDDEN_SIZE + AXI_LANES - 1) / AXI_LANES;
static const int HEAD_WORDS_PER_TOKEN_CEILING =
    (HEAD_DIM + AXI_LANES - 1) / AXI_LANES;
static const int HEAD_WORDS_PER_HEAD_CEILING =
    (SEQ_LEN * HEAD_DIM + AXI_LANES - 1) / AXI_LANES;

static_assert(HIDDEN_TENSOR_WORDS ==
                  SEQ_LEN * HIDDEN_WORDS_PER_TOKEN_CEILING,
              "Hidden stream word count must match row-wise packing");
static_assert(HEAD_TENSOR_WORDS ==
                  NUM_HEADS * SEQ_LEN * HEAD_WORDS_PER_TOKEN_CEILING,
              "Head stream word count must match head/token packing");

enum TensorPhysicalOrder {
    ORDER_HEAD_TOKEN_DIM,
    ORDER_TOKEN_HIDDEN
};

enum KernelEndpoint {
    ENDPOINT_QKV,
    ENDPOINT_ATTENTION_CORE,
    ENDPOINT_ATTENTION_OUTPUT_NORM,
    ENDPOINT_FFN_FUSED,
    ENDPOINT_DDR
};

struct StreamContractDescriptor {
    int packed_bits;
    int scalar_count;
    int word_count;
    int fifo_depth;
    int rank;
    int dim0;
    int dim1;
    int dim2;
    TensorPhysicalOrder physical_order;
    KernelEndpoint producer;
    KernelEndpoint consumer;
};

static const StreamContractDescriptor Q_STREAM_CONTRACT =
    {AXI_BITS, HEAD_TENSOR_SCALARS, HEAD_TENSOR_WORDS, FIFO_DEPTH,
     3, NUM_HEADS, SEQ_LEN, HEAD_DIM, ORDER_HEAD_TOKEN_DIM,
     ENDPOINT_QKV, ENDPOINT_ATTENTION_CORE};
static const StreamContractDescriptor K_STREAM_CONTRACT =
    {AXI_BITS, HEAD_TENSOR_SCALARS, HEAD_TENSOR_WORDS, FIFO_DEPTH,
     3, NUM_HEADS, SEQ_LEN, HEAD_DIM, ORDER_HEAD_TOKEN_DIM,
     ENDPOINT_QKV, ENDPOINT_ATTENTION_CORE};
static const StreamContractDescriptor V_STREAM_CONTRACT =
    {AXI_BITS, HEAD_TENSOR_SCALARS, HEAD_TENSOR_WORDS, FIFO_DEPTH,
     3, NUM_HEADS, SEQ_LEN, HEAD_DIM, ORDER_HEAD_TOKEN_DIM,
     ENDPOINT_QKV, ENDPOINT_ATTENTION_CORE};
static const StreamContractDescriptor CONTEXT_STREAM_CONTRACT =
    {AXI_BITS, HIDDEN_TENSOR_SCALARS, HIDDEN_TENSOR_WORDS, FIFO_DEPTH,
     2, SEQ_LEN, HIDDEN_SIZE, 1, ORDER_TOKEN_HIDDEN,
     ENDPOINT_ATTENTION_CORE, ENDPOINT_ATTENTION_OUTPUT_NORM};
static const StreamContractDescriptor ATTENTION_OUTPUT_STREAM_CONTRACT =
    {AXI_BITS, HIDDEN_TENSOR_SCALARS, HIDDEN_TENSOR_WORDS, FIFO_DEPTH,
     2, SEQ_LEN, HIDDEN_SIZE, 1, ORDER_TOKEN_HIDDEN,
     ENDPOINT_ATTENTION_OUTPUT_NORM, ENDPOINT_FFN_FUSED};
static const StreamContractDescriptor ATTENTION_RESIDUAL_STREAM_CONTRACT =
    {AXI_BITS, HIDDEN_TENSOR_SCALARS, HIDDEN_TENSOR_WORDS, FIFO_DEPTH,
     2, SEQ_LEN, HIDDEN_SIZE, 1, ORDER_TOKEN_HIDDEN,
     ENDPOINT_QKV, ENDPOINT_ATTENTION_OUTPUT_NORM};
static const StreamContractDescriptor LAYER_OUTPUT_STREAM_CONTRACT =
    {AXI_BITS, HIDDEN_TENSOR_SCALARS, HIDDEN_TENSOR_WORDS, FIFO_DEPTH,
     2, SEQ_LEN, HIDDEN_SIZE, 1, ORDER_TOKEN_HIDDEN,
     ENDPOINT_FFN_FUSED, ENDPOINT_DDR};

inline axis_word_t make_axis_word(const float lanes[AXI_LANES], bool is_last) {
#pragma HLS INLINE
    axis_word_t packet;
    axi_word_t data = 0;
pack_axis_lanes:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
        data.range((lane + 1) * SCALAR_BITS - 1, lane * SCALAR_BITS) =
            scalar_to_bits(lanes[lane]);
    }
    packet.data = data;
    packet.keep = -1;
    packet.strb = -1;
    packet.last = is_last ? 1 : 0;
    return packet;
}

inline void unpack_axis_word(const axis_word_t& packet, float lanes[AXI_LANES]) {
#pragma HLS INLINE
unpack_axis_lanes:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
        lanes[lane] = bits_to_scalar(
            packet.data.range((lane + 1) * SCALAR_BITS - 1, lane * SCALAR_BITS));
    }
}

template <int ROWS, int COLS>
void stream_write_matrix(const float matrix[ROWS][COLS], tensor_stream_t& output) {
#pragma HLS INLINE
    const int words_per_row = (COLS + AXI_LANES - 1) / AXI_LANES;
write_matrix_rows:
    for (int row = 0; row < ROWS; ++row) {
    write_matrix_words:
        for (int word = 0; word < words_per_row; ++word) {
#pragma HLS PIPELINE II=1
            float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        write_matrix_lanes:
            for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                const int column = word * AXI_LANES + lane;
                lanes[lane] = column < COLS ? matrix[row][column] : 0.0f;
            }
            const bool is_last = row == ROWS - 1 && word == words_per_row - 1;
            output.write(make_axis_word(lanes, is_last));
        }
    }
}

template <int ROWS, int COLS>
void stream_read_matrix(tensor_stream_t& input, float matrix[ROWS][COLS]) {
#pragma HLS INLINE
    const int words_per_row = (COLS + AXI_LANES - 1) / AXI_LANES;
read_matrix_rows:
    for (int row = 0; row < ROWS; ++row) {
    read_matrix_words:
        for (int word = 0; word < words_per_row; ++word) {
#pragma HLS PIPELINE II=1
            const axis_word_t packet = input.read();
            float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
            unpack_axis_word(packet, lanes);
        read_matrix_lanes:
            for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                const int column = word * AXI_LANES + lane;
                if (column < COLS) {
                    matrix[row][column] = lanes[lane];
                }
            }
        }
    }
}

// Convert projection [token][hidden] to the attention-native physical order
// [head][token][head_dim] while packing the stream.
inline void stream_write_head_tensor(
    const float projection[SEQ_LEN][HIDDEN_SIZE], tensor_stream_t& output) {
#pragma HLS INLINE
    const int words_per_token = (HEAD_DIM + AXI_LANES - 1) / AXI_LANES;
write_head_heads:
    for (int head = 0; head < NUM_HEADS; ++head) {
    write_head_tokens:
        for (int token = 0; token < SEQ_LEN; ++token) {
        write_head_words:
            for (int word = 0; word < words_per_token; ++word) {
#pragma HLS PIPELINE II=1
                float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
            write_head_lanes:
                for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                    const int dim = word * AXI_LANES + lane;
                    lanes[lane] = dim < HEAD_DIM
                        ? projection[token][head * HEAD_DIM + dim]
                        : 0.0f;
                }
                const bool is_last = head == NUM_HEADS - 1
                                  && token == SEQ_LEN - 1
                                  && word == words_per_token - 1;
                output.write(make_axis_word(lanes, is_last));
            }
        }
    }
}

inline void stream_read_head_tensor(
    tensor_stream_t& input, float tensor[NUM_HEADS][SEQ_LEN][HEAD_DIM]) {
#pragma HLS INLINE
    const int words_per_token = (HEAD_DIM + AXI_LANES - 1) / AXI_LANES;
read_head_heads:
    for (int head = 0; head < NUM_HEADS; ++head) {
    read_head_tokens:
        for (int token = 0; token < SEQ_LEN; ++token) {
        read_head_words:
            for (int word = 0; word < words_per_token; ++word) {
#pragma HLS PIPELINE II=1
                const axis_word_t packet = input.read();
                float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
                unpack_axis_word(packet, lanes);
            read_head_lanes:
                for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                    const int dim = word * AXI_LANES + lane;
                    if (dim < HEAD_DIM) {
                        tensor[head][token][dim] = lanes[lane];
                    }
                }
            }
        }
    }
}

}  // namespace bert

#endif
