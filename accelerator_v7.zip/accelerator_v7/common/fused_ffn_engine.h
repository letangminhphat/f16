#ifndef BERT_FUSED_FFN_ENGINE_H
#define BERT_FUSED_FFN_ENGINE_H

#include "packed_io.h"
#include "stream_contracts.h"

namespace bert {

static const int FUSED_FFN_BLOCK_K = BERT_FFN_UP_TILE_K;
static const int FUSED_FFN_TILE_N = BERT_FFN_UP_TILE_N;
static const int FUSED_HIDDEN_BLOCKS = HIDDEN_SIZE / FUSED_FFN_BLOCK_K;
static const int FUSED_INTERMEDIATE_BLOCKS =
    FFN_INTERMEDIATE / FUSED_FFN_BLOCK_K;
static const int FUSED_SUBTILES_PER_BLOCK =
    FUSED_FFN_BLOCK_K / FUSED_FFN_TILE_N;
static const int FUSED_W1_OUTPUT_TILES =
    FFN_INTERMEDIATE / FUSED_FFN_TILE_N;
static const int FUSED_W2_OUTPUT_TILES =
    HIDDEN_SIZE / FUSED_FFN_TILE_N;
static const int FUSED_TILES_PER_INTERMEDIATE_BLOCK =
    FUSED_HIDDEN_BLOCKS * FUSED_SUBTILES_PER_BLOCK;
static const int FUSED_WEIGHT_TILE_WORDS =
    (FUSED_FFN_BLOCK_K * FUSED_FFN_TILE_N) / AXI_LANES;

static_assert(HIDDEN_SIZE % FUSED_FFN_BLOCK_K == 0,
              "Hidden size must divide into fused blocks");
static_assert(FFN_INTERMEDIATE % FUSED_FFN_BLOCK_K == 0,
              "Intermediate size must divide into fused blocks");
static_assert(FUSED_FFN_BLOCK_K % FUSED_FFN_TILE_N == 0,
              "A fused intermediate block must contain whole output tiles");
static_assert(BERT_FFN_UP_TILE_K == BERT_FFN_DOWN_TILE_K &&
              BERT_FFN_UP_TILE_N == BERT_FFN_DOWN_TILE_N,
              "The shared FFN engine requires identical W1/W2 tile shapes");
static_assert((FUSED_FFN_BLOCK_K * FUSED_FFN_TILE_N) % AXI_LANES == 0,
              "A fused weight tile must contain whole AXI words");

template <int LANES>
struct FusedFfnReducer;

template <>
struct FusedFfnReducer<8> {
    static accum_t reduce(const accum_t input[8]) {
#pragma HLS INLINE
        accum_t stage4[4];
        accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    fused_reduce8_to4:
        for (int lane = 0; lane < 4; ++lane) {
#pragma HLS UNROLL
            stage4[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    fused_reduce4_to2:
        for (int lane = 0; lane < 2; ++lane) {
#pragma HLS UNROLL
            stage2[lane] = stage4[lane * 2] + stage4[lane * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <>
struct FusedFfnReducer<16> {
    static accum_t reduce(const accum_t input[16]) {
#pragma HLS INLINE
        accum_t stage8[8];
        accum_t stage4[4];
        accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage8 complete
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    fused_reduce16_to8:
        for (int lane = 0; lane < 8; ++lane) {
#pragma HLS UNROLL
            stage8[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    fused_reduce8_to4:
        for (int lane = 0; lane < 4; ++lane) {
#pragma HLS UNROLL
            stage4[lane] = stage8[lane * 2] + stage8[lane * 2 + 1];
        }
    fused_reduce4_to2:
        for (int lane = 0; lane < 2; ++lane) {
#pragma HLS UNROLL
            stage2[lane] = stage4[lane * 2] + stage4[lane * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <>
struct FusedFfnReducer<24> {
    static accum_t reduce(const accum_t input[24]) {
#pragma HLS INLINE
        accum_t stage12[12];
        accum_t stage6[6];
        accum_t stage3[3];
#pragma HLS ARRAY_PARTITION variable=stage12 complete
#pragma HLS ARRAY_PARTITION variable=stage6 complete
#pragma HLS ARRAY_PARTITION variable=stage3 complete
    fused_reduce24_to12:
        for (int lane = 0; lane < 12; ++lane) {
#pragma HLS UNROLL
            stage12[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    fused_reduce12_to6:
        for (int lane = 0; lane < 6; ++lane) {
#pragma HLS UNROLL
            stage6[lane] = stage12[lane * 2] + stage12[lane * 2 + 1];
        }
    fused_reduce6_to3:
        for (int lane = 0; lane < 3; ++lane) {
#pragma HLS UNROLL
            stage3[lane] = stage6[lane * 2] + stage6[lane * 2 + 1];
        }
        return (stage3[0] + stage3[1]) + stage3[2];
    }
};

inline void read_fused_hidden_blocks(
    tensor_stream_t& input,
    float hidden[FUSED_HIDDEN_BLOCKS][SEQ_LEN][FUSED_FFN_BLOCK_K]) {
#pragma HLS INLINE
read_fused_hidden_rows:
    for (int row = 0; row < SEQ_LEN; ++row) {
    read_fused_hidden_blocks_loop:
        for (int block = 0; block < FUSED_HIDDEN_BLOCKS; ++block) {
        read_fused_hidden_words:
            for (int word = 0; word < FUSED_FFN_BLOCK_K / AXI_LANES; ++word) {
#pragma HLS PIPELINE II=1
                const axis_word_t packet = input.read();
                float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
                unpack_axis_word(packet, lanes);
            read_fused_hidden_lanes:
                for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                    hidden[block][row][word * AXI_LANES + lane] = lanes[lane];
                }
            }
        }
    }
}

inline void load_fused_weight_tile_at_word(
    const axi_word_t* weights,
    offset_t tile_word_offset,
    float weight[FUSED_FFN_BLOCK_K][FUSED_FFN_TILE_N]) {
load_fused_tile_words:
    for (int word_index = 0;
         word_index < FUSED_WEIGHT_TILE_WORDS;
         ++word_index) {
#pragma HLS PIPELINE II=1
        float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        unpack_scalar_array(weights[tile_word_offset + word_index], lanes);
    load_fused_tile_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int flat = word_index * AXI_LANES + lane;
            const int input_index = flat / FUSED_FFN_TILE_N;
            const int output_index = flat % FUSED_FFN_TILE_N;
            weight[input_index][output_index] = lanes[lane];
        }
    }
}

void fused_ffn_mac_engine(
    const float input[SEQ_LEN][FUSED_FFN_BLOCK_K],
    const float weight[FUSED_FFN_BLOCK_K][FUSED_FFN_TILE_N],
    int output_offset,
    float output[SEQ_LEN][FUSED_FFN_BLOCK_K]) {
#pragma HLS INLINE off
#pragma HLS ARRAY_PARTITION variable=input cyclic factor=FFN_BUFFER_BANKS dim=2
#pragma HLS ARRAY_PARTITION variable=weight cyclic factor=FFN_MAC_LANES dim=1
#pragma HLS ARRAY_PARTITION variable=weight cyclic factor=FFN_OUT_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=output cyclic factor=FFN_BUFFER_BANKS dim=2
mac_engine_input_groups:
    for (int input_group = 0;
         input_group < FUSED_FFN_BLOCK_K;
         input_group += FFN_MAC_LANES) {
    mac_engine_output_groups:
        for (int local_output_base = 0;
             local_output_base < FUSED_FFN_TILE_N;
             local_output_base += FFN_OUT_PAR) {
        mac_engine_rows:
            for (int row = 0; row < SEQ_LEN; ++row) {
#pragma HLS PIPELINE II=1
            mac_engine_output_lanes:
                for (int output_lane = 0; output_lane < FFN_OUT_PAR;
                     ++output_lane) {
#pragma HLS UNROLL
                    accum_t products[FFN_MAC_LANES];
#pragma HLS ARRAY_PARTITION variable=products complete
                mac_engine_mac_lanes:
                    for (int mac_lane = 0; mac_lane < FFN_MAC_LANES;
                         ++mac_lane) {
#pragma HLS UNROLL
                        const int input_index = input_group + mac_lane;
                        const int weight_output =
                            local_output_base + output_lane;
                        products[mac_lane] =
                            input[row][input_index]
                            * weight[input_index][weight_output];
                    }
                    const int output_index =
                        output_offset + local_output_base + output_lane;
                    output[row][output_index] +=
                        FusedFfnReducer<FFN_MAC_LANES>::reduce(products);
                }
            }
        }
    }
}

void fused_ffn_prefetch_compute(
    const axi_word_t* weights,
    offset_t next_tile_word,
    const float input[SEQ_LEN][FUSED_FFN_BLOCK_K],
    int output_offset,
    float output[SEQ_LEN][FUSED_FFN_BLOCK_K],
    const float current_weight[FUSED_FFN_BLOCK_K][FUSED_FFN_TILE_N],
    float next_weight[FUSED_FFN_BLOCK_K][FUSED_FFN_TILE_N]) {
#pragma HLS INLINE off
#pragma HLS DATAFLOW
    load_fused_weight_tile_at_word(weights, next_tile_word, next_weight);
    fused_ffn_mac_engine(input, current_weight, output_offset, output);
}

inline offset_t fused_w1_tile_word(offset_t matrix_word_offset,
                                   int hidden_block,
                                   int intermediate_block,
                                   int sub_tile) {
#pragma HLS INLINE
    const int output_tile =
        intermediate_block * FUSED_SUBTILES_PER_BLOCK + sub_tile;
    const int flat_tile = hidden_block * FUSED_W1_OUTPUT_TILES + output_tile;
    return matrix_word_offset
         + static_cast<offset_t>(flat_tile) * FUSED_WEIGHT_TILE_WORDS;
}

inline offset_t fused_w2_tile_word(offset_t matrix_word_offset,
                                   int intermediate_block,
                                   int hidden_block,
                                   int sub_tile) {
#pragma HLS INLINE
    const int output_tile =
        hidden_block * FUSED_SUBTILES_PER_BLOCK + sub_tile;
    const int flat_tile =
        intermediate_block * FUSED_W2_OUTPUT_TILES + output_tile;
    return matrix_word_offset
         + static_cast<offset_t>(flat_tile) * FUSED_WEIGHT_TILE_WORDS;
}

}  // namespace bert

#endif
