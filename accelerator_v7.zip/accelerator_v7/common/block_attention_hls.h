#ifndef BERT_BLOCK_ATTENTION_HLS_H
#define BERT_BLOCK_ATTENTION_HLS_H

#include "gemm_act_act.h"
#include "math_utils_hls.h"

namespace bert {

template <int LANES>
struct BlockAttentionReducer;

template <>
struct BlockAttentionReducer<2> {
    static softmax_accum_t maximum(const softmax_accum_t values[2]) {
#pragma HLS INLINE
        return values[0] > values[1] ? values[0] : values[1];
    }

    static softmax_accum_t sum(const softmax_accum_t values[2]) {
#pragma HLS INLINE
        return values[0] + values[1];
    }
};

template <>
struct BlockAttentionReducer<4> {
    static softmax_accum_t maximum(const softmax_accum_t values[4]) {
#pragma HLS INLINE
        const softmax_accum_t low =
            values[0] > values[1] ? values[0] : values[1];
        const softmax_accum_t high =
            values[2] > values[3] ? values[2] : values[3];
        return low > high ? low : high;
    }

    static softmax_accum_t sum(const softmax_accum_t values[4]) {
#pragma HLS INLINE
        const softmax_accum_t low = values[0] + values[1];
        const softmax_accum_t high = values[2] + values[3];
        return low + high;
    }
};

template <int N, int D>
void block_attention_row(const float query[D],
                         const float keys[N][D],
                         const float values[N][D],
                         const float mask[N],
                         unsigned int active_sequence_length,
                         float scale,
                         float context[D]) {
#pragma HLS INLINE
#pragma HLS ARRAY_PARTITION variable=keys cyclic factor=QK_KEY_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=keys cyclic factor=MAC_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=values cyclic factor=QK_KEY_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=values cyclic factor=ATTENTION_DIM_PAR dim=2

    static_assert(QK_KEY_PAR == 2 || QK_KEY_PAR == 4,
                  "Block attention supports two or four keys");
    softmax_accum_t scores[N];
    softmax_accum_t numerator[D][SV_ACCUM_SLOTS];
#pragma HLS ARRAY_PARTITION variable=scores cyclic factor=QK_KEY_PAR
#pragma HLS ARRAY_PARTITION variable=numerator cyclic factor=ATTENTION_DIM_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=numerator complete dim=2
    softmax_accum_t maximum = -3.402823466e+38F;

score_key_blocks:
    for (int key_base = 0; key_base < N; key_base += QK_KEY_PAR) {
        softmax_accum_t block_scores[QK_KEY_PAR];
#pragma HLS ARRAY_PARTITION variable=block_scores complete

    score_key_lanes:
        for (int key_lane = 0; key_lane < QK_KEY_PAR; ++key_lane) {
#pragma HLS UNROLL
            const int key_index = key_base + key_lane;
            softmax_accum_t score =
                dot_qk<D>(query, keys[key_index]) * scale;
            if (mask[key_index] == 0.0f ||
                key_index >= static_cast<int>(active_sequence_length)) {
                score += ATTENTION_NEGATIVE_MASK;
            }
            block_scores[key_lane] = score;
            scores[key_index] = score;
        }

        const softmax_accum_t block_maximum =
            BlockAttentionReducer<QK_KEY_PAR>::maximum(block_scores);
        maximum = maximum > block_maximum ? maximum : block_maximum;
    }

initialize_block_numerator:
    for (int base = 0; base < D; base += ATTENTION_DIM_PAR) {
#pragma HLS PIPELINE II=1
    initialize_block_numerator_lanes:
        for (int lane = 0; lane < ATTENTION_DIM_PAR; ++lane) {
#pragma HLS UNROLL
        initialize_block_numerator_slots:
            for (int slot = 0; slot < SV_ACCUM_SLOTS; ++slot) {
#pragma HLS UNROLL
                numerator[base + lane][slot] = 0.0f;
            }
        }
    }

    softmax_accum_t sum_lanes[QK_KEY_PAR];
#pragma HLS ARRAY_PARTITION variable=sum_lanes complete
initialize_sum_lanes:
    for (int key_lane = 0; key_lane < QK_KEY_PAR; ++key_lane) {
#pragma HLS UNROLL
        sum_lanes[key_lane] = 0.0f;
    }

value_key_blocks:
    for (int key_base = 0; key_base < N; key_base += QK_KEY_PAR) {
        const int accum_slot =
            (key_base / QK_KEY_PAR) % SV_ACCUM_SLOTS;
        softmax_accum_t exponentials[QK_KEY_PAR];
#pragma HLS ARRAY_PARTITION variable=exponentials complete

    block_exponential_lanes:
        for (int key_lane = 0; key_lane < QK_KEY_PAR; ++key_lane) {
#pragma HLS UNROLL
            const int key_index = key_base + key_lane;
            exponentials[key_lane] =
                exact_exp(scores[key_index] - maximum);
            sum_lanes[key_lane] += exponentials[key_lane];
        }

    block_value_groups:
        for (int base = 0; base < D; base += ATTENTION_DIM_PAR) {
#pragma HLS PIPELINE II=1
        block_value_dimension_lanes:
            for (int dim_lane = 0; dim_lane < ATTENTION_DIM_PAR; ++dim_lane) {
#pragma HLS UNROLL
                const int dim = base + dim_lane;
                softmax_accum_t products[QK_KEY_PAR];
#pragma HLS ARRAY_PARTITION variable=products complete
            block_value_key_lanes:
                for (int key_lane = 0; key_lane < QK_KEY_PAR; ++key_lane) {
#pragma HLS UNROLL
                    products[key_lane] =
                        exponentials[key_lane]
                        * values[key_base + key_lane][dim];
                }
                numerator[dim][accum_slot] +=
                    BlockAttentionReducer<QK_KEY_PAR>::sum(products);
            }
        }
    }

    const softmax_accum_t sum =
        BlockAttentionReducer<QK_KEY_PAR>::sum(sum_lanes);
    const softmax_accum_t reciprocal =
        sum > 0.0f ? 1.0f / sum : 0.0f;
finalize_block_context:
    for (int base = 0; base < D; base += ATTENTION_DIM_PAR) {
#pragma HLS PIPELINE II=1
    finalize_block_context_lanes:
        for (int lane = 0; lane < ATTENTION_DIM_PAR; ++lane) {
#pragma HLS UNROLL
            const int dim = base + lane;
            softmax_accum_t slot_values[SV_ACCUM_SLOTS];
#pragma HLS ARRAY_PARTITION variable=slot_values complete
        finalize_block_context_slots:
            for (int slot = 0; slot < SV_ACCUM_SLOTS; ++slot) {
#pragma HLS UNROLL
                slot_values[slot] = numerator[dim][slot];
            }
            context[dim] =
                BlockAttentionReducer<SV_ACCUM_SLOTS>::sum(slot_values)
                * reciprocal;
        }
    }
}

}  // namespace bert

#endif
