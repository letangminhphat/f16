array set ::bert_source_for {
    bert_qk_persistent             qkv_persistent.cpp
    bert_v_persistent              qkv_persistent.cpp
    bert_attention_persistent      attention_persistent.cpp
    bert_attention_out_persistent  attention_out_persistent.cpp
    bert_ffn_up_persistent         ffn_persistent.cpp
    bert_ffn_down_persistent       ffn_persistent.cpp
    bert_feedback_relay            relay_persistent.cpp
    bert_residual_relay            relay_persistent.cpp
}

set ::bert_persistent_tops [list \
    bert_qk_persistent \
    bert_v_persistent \
    bert_attention_persistent \
    bert_attention_out_persistent \
    bert_ffn_up_persistent \
    bert_ffn_down_persistent \
    bert_feedback_relay \
    bert_residual_relay]
