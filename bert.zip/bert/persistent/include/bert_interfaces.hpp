#ifndef BERT_U250_PERSISTENT_INTERFACES_HPP
#define BERT_U250_PERSISTENT_INTERFACES_HPP

#include "bert_types.hpp"

extern "C" {
void bert_qk_persistent(
    const bus_t *initial_hidden,
    const bus_t *q_weights,
    const bus_t *q_bias,
    const bus_t *k_weights,
    const bus_t *k_bias,
    hidden_stream_t &feedback_stream,
    hidden_stream_t &attention_residual_stream,
    hidden_stream_t &v_hidden_stream,
    hidden_stream_t &q_stream,
    hidden_stream_t &k_stream);

void bert_v_persistent(
    const bus_t *v_weights,
    const bus_t *v_bias,
    hidden_stream_t &v_hidden_stream,
    hidden_stream_t &v_stream);

void bert_attention_persistent(
    hidden_stream_t &q_stream,
    hidden_stream_t &k_stream,
    hidden_stream_t &v_stream,
    const ap_uint<16> *attention_mask,
    hidden_stream_t &context_stream);

void bert_attention_out_persistent(
    hidden_stream_t &context_stream,
    hidden_stream_t &attention_residual_stream,
    const bus_t *out_weights,
    const bus_t *out_bias,
    const bus_t *attention_norm_gamma,
    const bus_t *attention_norm_beta,
    hidden_stream_t &attention_mid_stream,
    hidden_stream_t &ffn_residual_stream);

void bert_ffn_up_persistent(
    hidden_stream_t &attention_mid_stream,
    const bus_t *ffn1_weights,
    const bus_t *ffn1_bias,
    hidden_stream_t &gelu_stream);

void bert_ffn_down_persistent(
    hidden_stream_t &gelu_stream,
    hidden_stream_t &ffn_residual_stream,
    const bus_t *ffn2_weights,
    const bus_t *ffn2_bias,
    const bus_t *ffn_norm_gamma,
    const bus_t *ffn_norm_beta,
    hidden_stream_t &feedback_stream,
    bus_t *last_hidden_state);

void bert_feedback_relay(
    hidden_stream_t &input_stream,
    hidden_stream_t &output_stream);

void bert_residual_relay(
    hidden_stream_t &input_stream,
    hidden_stream_t &output_stream);
}

#endif
