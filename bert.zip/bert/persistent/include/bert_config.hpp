#ifndef BERT_U250_PERSISTENT_CONFIG_HPP
#define BERT_U250_PERSISTENT_CONFIG_HPP

static const int NUM_LAYERS = 12;
static const int SEQ_LEN = 128;
static const int HIDDEN = 768;
static const int NUM_HEADS = 12;
static const int HEAD_DIM = 64;
static const int FFN = 3072;

// A 512-bit AXI word contains 32 Fixed16 values.
static const int PACK = 32;
static const int HIDDEN_PACKS = HIDDEN / PACK;
static const int FFN_PACKS = FFN / PACK;
static const int TOKEN_WORDS = SEQ_LEN * HIDDEN_PACKS;

// Two attention heads are processed as one streamed group.
static const int HEAD_PAR = 2;
static const int HEAD_GROUPS = NUM_HEADS / HEAD_PAR;
static const int GROUP_DIM = HEAD_PAR * HEAD_DIM;
static const int GROUP_PACKS = GROUP_DIM / PACK;

// Route-safe fixed-point compute profiles. The Q/K pair owns 256 MACs,
// V owns 128 MACs, Attention Core owns at most 256 MACs, Attention Output
// owns 256 MACs, and each FFN side owns 512 MACs.
static const int PROJ_TILE_O = 32;
static const int PROJ_O_PAR = 8;
static const int PROJ_K_PAR = 16;
static const int PROJ_O_BLOCKS = PROJ_TILE_O / PROJ_O_PAR;
static const int PROJ_K_CHUNKS = HIDDEN / PROJ_K_PAR;

static const int ATTN_QUERY_PAR = 2;
static const int ATTN_D_PAR = 64;
static const int ATTN_CONTEXT_PAR = 32;

static const int OUT_TILE_O = 32;
static const int OUT_O_PAR = 16;
static const int OUT_K_PAR = 16;

static const int FFN_TILE_O = 32;
static const int FFN_O_PAR = 32;
static const int FFN_K_PAR = 16;
static const int FFN_INPUT_CHUNKS = HIDDEN / FFN_K_PAR;
static const int FFN_TILE_COUNT = FFN / FFN_TILE_O;

static const int ATTN_WEIGHT_WORDS_PER_LAYER =
    HIDDEN * HIDDEN / PACK;
static const int ATTN_BIAS_WORDS_PER_LAYER = HIDDEN / PACK;
static const int FFN1_WEIGHT_WORDS_PER_LAYER =
    FFN * HIDDEN / PACK;
static const int FFN1_BIAS_WORDS_PER_LAYER = FFN / PACK;
static const int FFN2_WEIGHT_WORDS_PER_LAYER =
    HIDDEN * FFN / PACK;
static const int FFN2_BIAS_WORDS_PER_LAYER = HIDDEN / PACK;
static const int NORM_WORDS_PER_LAYER = HIDDEN / PACK;

static const int ALL_ATTN_WEIGHT_WORDS =
    NUM_LAYERS * ATTN_WEIGHT_WORDS_PER_LAYER;
static const int ALL_ATTN_BIAS_WORDS =
    NUM_LAYERS * ATTN_BIAS_WORDS_PER_LAYER;
static const int ALL_FFN1_WEIGHT_WORDS =
    NUM_LAYERS * FFN1_WEIGHT_WORDS_PER_LAYER;
static const int ALL_FFN1_BIAS_WORDS =
    NUM_LAYERS * FFN1_BIAS_WORDS_PER_LAYER;
static const int ALL_FFN2_WEIGHT_WORDS =
    NUM_LAYERS * FFN2_WEIGHT_WORDS_PER_LAYER;
static const int ALL_FFN2_BIAS_WORDS =
    NUM_LAYERS * FFN2_BIAS_WORDS_PER_LAYER;
static const int ALL_NORM_WORDS =
    NUM_LAYERS * NORM_WORDS_PER_LAYER;

static const unsigned long TARGET_CLOCK_HZ = 250000000UL;
static const unsigned long TARGET_LATENCY_CYCLES = 25000000UL;
static const double TARGET_LATENCY_MS = 100.0;

static_assert(HIDDEN == NUM_HEADS * HEAD_DIM,
              "hidden size must equal heads times head dimension");
static_assert(HIDDEN % PACK == 0, "hidden must pack exactly");
static_assert(FFN % PACK == 0, "FFN must pack exactly");
static_assert(GROUP_DIM % PACK == 0, "head group must pack exactly");
static_assert(PROJ_TILE_O % PROJ_O_PAR == 0,
              "projection tile must contain complete output blocks");
static_assert(HIDDEN % PROJ_K_PAR == 0,
              "projection K parallelism must divide hidden");
static_assert(HEAD_DIM == ATTN_D_PAR,
              "score engine computes one complete head per cycle");
static_assert(HEAD_DIM % ATTN_CONTEXT_PAR == 0,
              "context lane count must divide head dimension");
static_assert(OUT_K_PAR == PROJ_K_PAR,
              "shared dot16 helper requires identical output K lanes");
static_assert(FFN_K_PAR == PROJ_K_PAR,
              "shared dot16 helper requires identical FFN K lanes");
static_assert(FFN_TILE_O == FFN_O_PAR,
              "FFN engine emits one complete Fixed16 word");

#endif
