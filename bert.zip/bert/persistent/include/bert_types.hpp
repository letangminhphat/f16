#ifndef BERT_U250_PERSISTENT_TYPES_HPP
#define BERT_U250_PERSISTENT_TYPES_HPP

#include <ap_fixed.h>
#include <ap_int.h>
#include <hls_stream.h>

#include "bert_config.hpp"

typedef ap_fixed<16, 6, AP_RND_CONV, AP_SAT> data_t;
typedef ap_fixed<16, 3, AP_RND_CONV, AP_SAT> weight_t;
typedef ap_fixed<16, 6, AP_RND_CONV, AP_SAT> bias_t;
typedef ap_fixed<16, 5, AP_RND_CONV, AP_SAT> norm_t;
typedef ap_fixed<32, 12, AP_RND_CONV, AP_SAT> acc_t;
typedef ap_uint<512> bus_t;
typedef ap_uint<256> weight_chunk_t;
typedef hls::stream<bus_t> hidden_stream_t;

static inline data_t bus_data_lane(const bus_t &word, int lane) {
#pragma HLS inline
    data_t value;
    value.range(15, 0) = word.range(lane * 16 + 15, lane * 16);
    return value;
}

static inline weight_t bus_weight_lane(const bus_t &word, int lane) {
#pragma HLS inline
    weight_t value;
    value.range(15, 0) = word.range(lane * 16 + 15, lane * 16);
    return value;
}

static inline bias_t bus_bias_lane(const bus_t &word, int lane) {
#pragma HLS inline
    bias_t value;
    value.range(15, 0) = word.range(lane * 16 + 15, lane * 16);
    return value;
}

static inline norm_t bus_norm_lane(const bus_t &word, int lane) {
#pragma HLS inline
    norm_t value;
    value.range(15, 0) = word.range(lane * 16 + 15, lane * 16);
    return value;
}

static inline weight_t chunk_weight_lane(
    const weight_chunk_t &word, int lane) {
#pragma HLS inline
    weight_t value;
    value.range(15, 0) = word.range(lane * 16 + 15, lane * 16);
    return value;
}

static inline bus_t pack_data_lanes(const data_t lane[PACK]) {
#pragma HLS inline
    bus_t word = 0;
pack_data:
    for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
        word.range(i * 16 + 15, i * 16) = lane[i].range(15, 0);
    }
    return word;
}

static inline void unpack_data_lanes(
    const bus_t &word, data_t lane[PACK]) {
#pragma HLS inline
unpack_data:
    for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
        lane[i] = bus_data_lane(word, i);
    }
}

static inline acc_t dot16(
    const data_t lhs[PROJ_K_PAR],
    const weight_chunk_t &rhs) {
#pragma HLS inline
    acc_t partial[PROJ_K_PAR];
#pragma HLS array_partition variable=partial complete
#pragma HLS bind_op variable=partial op=mul impl=dsp
dot16_products:
    for (int lane = 0; lane < PROJ_K_PAR; ++lane) {
#pragma HLS unroll
        partial[lane] =
            acc_t(lhs[lane]) * acc_t(chunk_weight_lane(rhs, lane));
    }
dot16_reduce:
    for (int stride = PROJ_K_PAR / 2; stride > 0; stride >>= 1) {
#pragma HLS unroll
        for (int lane = 0; lane < stride; ++lane) {
#pragma HLS unroll
            partial[lane] += partial[lane + stride];
        }
    }
    return partial[0];
}

static inline data_t fixed_gelu(acc_t x) {
#pragma HLS inline
    // Eight quadratic segments inherited from the validated FP32 reference.
    if (x <= acc_t(-4.0)) {
        return data_t(0);
    }
    if (x >= acc_t(4.0)) {
        return data_t(x);
    }

    acc_t a;
    acc_t b;
    if (x < acc_t(-3.0)) {
        a = acc_t(0.001065739883);
        b = acc_t(0.004102702461);
    } else if (x < acc_t(-2.0)) {
        a = acc_t(0.01860162772);
        b = acc_t(0.05455128354);
    } else if (x < acc_t(-1.0)) {
        a = acc_t(0.1245729792);
        b = acc_t(0.260966163);
    } else if (x < acc_t(0.0)) {
        a = acc_t(0.3164173761);
        b = acc_t(0.4679412082);
    } else if (x < acc_t(1.0)) {
        a = acc_t(0.3164173761);
        b = acc_t(0.5320587918);
    } else if (x < acc_t(2.0)) {
        a = acc_t(0.1245729792);
        b = acc_t(0.739033837);
    } else if (x < acc_t(3.0)) {
        a = acc_t(0.01860162772);
        b = acc_t(0.9454487165);
    } else {
        a = acc_t(0.001065739883);
        b = acc_t(0.9958972975);
    }
    return data_t(x * (a * x + b));
}

#endif
