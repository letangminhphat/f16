#include "bert_interfaces.hpp"

static void relay_forever(
    hidden_stream_t &input_stream,
    hidden_stream_t &output_stream,
    unsigned long long csim_words) {
#ifndef __SYNTHESIS__
    // Finite bounds let C simulation terminate. Hardware uses the
    // free-running loop below for the lifetime of the xclbin.
relay_csim:
    for (unsigned long long word = 0;
         word < csim_words; ++word) {
#pragma HLS pipeline II=1
        output_stream.write(input_stream.read());
    }
#else
relay_hardware:
    while (true) {
#pragma HLS pipeline II=1
        output_stream.write(input_stream.read());
    }
#endif
}

extern "C" void bert_feedback_relay(
    hidden_stream_t &input_stream,
    hidden_stream_t &output_stream) {
#pragma HLS interface axis port=input_stream
#pragma HLS interface axis port=output_stream
#pragma HLS interface ap_ctrl_none port=return
    relay_forever(
        input_stream, output_stream,
        (unsigned long long)(NUM_LAYERS - 1) * TOKEN_WORDS);
}

extern "C" void bert_residual_relay(
    hidden_stream_t &input_stream,
    hidden_stream_t &output_stream) {
#pragma HLS interface axis port=input_stream
#pragma HLS interface axis port=output_stream
#pragma HLS interface ap_ctrl_none port=return
    relay_forever(
        input_stream, output_stream,
        (unsigned long long)NUM_LAYERS * TOKEN_WORDS);
}
