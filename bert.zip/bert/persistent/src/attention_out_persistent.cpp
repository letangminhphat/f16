#include <hls_math.h>

#include "bert_interfaces.hpp"

static void load_attention_residual(
    hidden_stream_t &attention_residual_stream,
    data_t residual[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
load_attention_residual_words:
    for (int word_index = 0; word_index < TOKEN_WORDS; ++word_index) {
#pragma HLS pipeline II=1
        const bus_t word = attention_residual_stream.read();
        const int token = word_index / HIDDEN_PACKS;
        const int pack = word_index % HIDDEN_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(word, lane);
    load_attention_residual_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            residual[token][pack * PACK + i] = lane[i];
        }
    }
}

static void read_context_group(
    hidden_stream_t &context_stream,
    data_t context[SEQ_LEN][GROUP_DIM]) {
#pragma HLS inline off
read_context_words:
    for (int word_index = 0;
         word_index < SEQ_LEN * GROUP_PACKS; ++word_index) {
#pragma HLS pipeline II=1
        const bus_t word = context_stream.read();
        const int token = word_index / GROUP_PACKS;
        const int pack = word_index % GROUP_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(word, lane);
    read_context_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            context[token][pack * PACK + i] = lane[i];
        }
    }
}

static void initialize_output_projection(
    const bus_t *out_bias,
    int layer,
    acc_t projected[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
initialize_out_bias_word:
    for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
        const bus_t word =
            out_bias[layer * ATTN_BIAS_WORDS_PER_LAYER + pack];
        bias_t bias_lane[PACK];
#pragma HLS array_partition variable=bias_lane complete
    initialize_out_bias_lane:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            bias_lane[lane] = bus_bias_lane(word, lane);
        }
    initialize_out_tokens:
        for (int token = 0; token < SEQ_LEN; ++token) {
#pragma HLS pipeline II=1
        initialize_out_token_lanes:
            for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
                projected[token][pack * PACK + lane] =
                    acc_t(bias_lane[lane]);
            }
        }
    }
}

static void load_output_weight_tile(
    const bus_t *out_weights,
    int layer,
    int group,
    int out_tile,
    weight_chunk_t
        weight[OUT_O_PAR][OUT_TILE_O / OUT_O_PAR][GROUP_DIM / OUT_K_PAR]) {
#pragma HLS inline off
load_out_input_pack:
    for (int input_pack = 0; input_pack < GROUP_PACKS; ++input_pack) {
    load_out_local_output:
        for (int local_out = 0; local_out < OUT_TILE_O; ++local_out) {
#pragma HLS pipeline II=1
            const int external_index =
                layer * ATTN_WEIGHT_WORDS_PER_LAYER +
                ((group * (HIDDEN / OUT_TILE_O) + out_tile) *
                     GROUP_PACKS +
                 input_pack) *
                    OUT_TILE_O +
                local_out;
            const bus_t word = out_weights[external_index];
            const int bank = local_out % OUT_O_PAR;
            const int block = local_out / OUT_O_PAR;
            weight[bank][block][2 * input_pack] = word.range(255, 0);
            weight[bank][block][2 * input_pack + 1] =
                word.range(511, 256);
        }
    }
}

static void accumulate_output_projection(
    data_t context[SEQ_LEN][GROUP_DIM],
    const bus_t *out_weights,
    int layer,
    int group,
    acc_t projected[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
    weight_chunk_t
        weight[OUT_O_PAR][OUT_TILE_O / OUT_O_PAR]
              [GROUP_DIM / OUT_K_PAR];
#pragma HLS bind_storage variable=weight type=ram_2p impl=bram
#pragma HLS array_partition variable=weight complete dim=1

out_projection_tile:
    for (int out_tile = 0; out_tile < HIDDEN / OUT_TILE_O;
         ++out_tile) {
        load_output_weight_tile(
            out_weights, layer, group, out_tile, weight);
    out_projection_token:
        for (int token = 0; token < SEQ_LEN; ++token) {
        out_projection_block:
            for (int ob = 0; ob < OUT_TILE_O; ob += OUT_O_PAR) {
                acc_t accumulator[OUT_O_PAR];
#pragma HLS array_partition variable=accumulator complete
            out_load_accumulator:
                for (int out = 0; out < OUT_O_PAR; ++out) {
#pragma HLS unroll
                    accumulator[out] =
                        projected[token]
                                 [out_tile * OUT_TILE_O + ob + out];
                }
            out_projection_chunk:
                for (int chunk = 0; chunk < GROUP_DIM / OUT_K_PAR;
                     ++chunk) {
#pragma HLS pipeline II=1
                    data_t x[OUT_K_PAR];
#pragma HLS array_partition variable=x complete
                out_load_x:
                    for (int lane = 0; lane < OUT_K_PAR; ++lane) {
#pragma HLS unroll
                        x[lane] =
                            context[token][chunk * OUT_K_PAR + lane];
                    }
                out_projection_mac:
                    for (int out = 0; out < OUT_O_PAR; ++out) {
#pragma HLS unroll
                        accumulator[out] +=
                            dot16(
                                x,
                                weight[out][ob / OUT_O_PAR][chunk]);
                    }
                }
            out_store_accumulator:
                for (int out = 0; out < OUT_O_PAR; ++out) {
#pragma HLS unroll
                    projected[token]
                             [out_tile * OUT_TILE_O + ob + out] =
                        accumulator[out];
                }
            }
        }
    }
}

static void attention_residual_norm(
    data_t residual[SEQ_LEN][HIDDEN],
    acc_t projected[SEQ_LEN][HIDDEN],
    const bus_t *gamma,
    const bus_t *beta,
    int layer,
    hidden_stream_t &attention_mid_stream,
    hidden_stream_t &ffn_residual_stream) {
#pragma HLS inline off
    norm_t gamma_cache[HIDDEN];
    norm_t beta_cache[HIDDEN];
#pragma HLS bind_storage variable=gamma_cache type=ram_2p impl=bram
#pragma HLS bind_storage variable=beta_cache type=ram_2p impl=bram
#pragma HLS array_reshape variable=gamma_cache cyclic factor=PACK
#pragma HLS array_reshape variable=beta_cache cyclic factor=PACK

load_attention_norm:
    for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
        const bus_t gamma_word =
            gamma[layer * NORM_WORDS_PER_LAYER + pack];
        const bus_t beta_word =
            beta[layer * NORM_WORDS_PER_LAYER + pack];
    load_attention_norm_lanes:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            gamma_cache[pack * PACK + lane] =
                bus_norm_lane(gamma_word, lane);
            beta_cache[pack * PACK + lane] =
                bus_norm_lane(beta_word, lane);
        }
    }

attention_norm_token:
    for (int token = 0; token < SEQ_LEN; ++token) {
        acc_t sum_bank[PACK];
        acc_t square_bank[PACK];
#pragma HLS array_partition variable=sum_bank complete
#pragma HLS array_partition variable=square_bank complete
    attention_norm_init:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            sum_bank[lane] = 0;
            square_bank[lane] = 0;
        }
        const acc_t inv_hidden = acc_t(1.0 / 768.0);
    attention_norm_reduce_pack:
        for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
        attention_norm_reduce_lane:
            for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
                const int hidden = pack * PACK + lane;
                const acc_t value =
                    acc_t(residual[token][hidden]) +
                    projected[token][hidden];
                sum_bank[lane] += value * inv_hidden;
                square_bank[lane] += value * value * inv_hidden;
            }
        }
        acc_t mean = 0;
        acc_t mean_square = 0;
    attention_norm_bank_reduce:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            mean += sum_bank[lane];
            mean_square += square_bank[lane];
        }
        acc_t variance = mean_square - mean * mean;
        const acc_t epsilon = acc_t(0.00000095367431640625);
        if (variance < epsilon) {
            variance = epsilon;
        }
        const acc_t inverse_stddev =
            acc_t(1) / acc_t(hls::sqrt(variance));

    attention_norm_write_pack:
        for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
            data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        attention_norm_write_lane:
            for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
                const int hidden = pack * PACK + i;
                const acc_t value =
                    acc_t(residual[token][hidden]) +
                    projected[token][hidden];
                lane[i] = data_t(
                    (value - mean) * inverse_stddev *
                        acc_t(gamma_cache[hidden]) +
                    acc_t(beta_cache[hidden]));
            }
            const bus_t word = pack_data_lanes(lane);
            attention_mid_stream.write(word);
            ffn_residual_stream.write(word);
        }
    }
}

extern "C" void bert_attention_out_persistent(
    hidden_stream_t &context_stream,
    hidden_stream_t &attention_residual_stream,
    const bus_t *out_weights,
    const bus_t *out_bias,
    const bus_t *attention_norm_gamma,
    const bus_t *attention_norm_beta,
    hidden_stream_t &attention_mid_stream,
    hidden_stream_t &ffn_residual_stream) {
#pragma HLS interface axis port=context_stream
#pragma HLS interface axis port=attention_residual_stream
#pragma HLS interface axis port=attention_mid_stream
#pragma HLS interface axis port=ffn_residual_stream
#pragma HLS interface m_axi port=out_weights offset=slave bundle=gmem_out_w depth=ALL_ATTN_WEIGHT_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=out_bias offset=slave bundle=gmem_out_w depth=ALL_ATTN_BIAS_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=attention_norm_gamma offset=slave bundle=gmem_attn_norm depth=ALL_NORM_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=attention_norm_beta offset=slave bundle=gmem_attn_norm depth=ALL_NORM_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface s_axilite port=out_weights bundle=control
#pragma HLS interface s_axilite port=out_bias bundle=control
#pragma HLS interface s_axilite port=attention_norm_gamma bundle=control
#pragma HLS interface s_axilite port=attention_norm_beta bundle=control
#pragma HLS interface s_axilite port=return bundle=control

    static data_t context[SEQ_LEN][GROUP_DIM];
    static data_t residual[SEQ_LEN][HIDDEN];
    static acc_t projected[SEQ_LEN][HIDDEN];
#pragma HLS bind_storage variable=context type=ram_2p impl=uram
#pragma HLS bind_storage variable=residual type=ram_2p impl=uram
#pragma HLS bind_storage variable=projected type=ram_2p impl=uram
#pragma HLS array_reshape variable=context cyclic factor=OUT_K_PAR dim=2
#pragma HLS array_reshape variable=residual cyclic factor=PACK dim=2
#pragma HLS array_reshape variable=projected cyclic factor=PACK dim=2

attention_out_layer:
    for (int layer = 0; layer < NUM_LAYERS; ++layer) {
        // Drain the residual first. This ordering is required to break the
        // feedback graph's circular backpressure dependency.
        load_attention_residual(attention_residual_stream, residual);
        initialize_output_projection(out_bias, layer, projected);
    attention_out_group:
        for (int group = 0; group < HEAD_GROUPS; ++group) {
            read_context_group(context_stream, context);
            accumulate_output_projection(
                context, out_weights, layer, group, projected);
        }
        attention_residual_norm(
            residual, projected,
            attention_norm_gamma, attention_norm_beta, layer,
            attention_mid_stream, ffn_residual_stream);
    }
}
