#include "bert_interfaces.hpp"

static void load_initial_hidden(
    const bus_t *initial_hidden,
    data_t hidden[SEQ_LEN][HIDDEN],
    hidden_stream_t &attention_residual_stream,
    hidden_stream_t &v_hidden_stream) {
#pragma HLS inline off
load_initial_words:
    for (int word_index = 0; word_index < TOKEN_WORDS; ++word_index) {
#pragma HLS pipeline II=1
        const bus_t word = initial_hidden[word_index];
        const int token = word_index / HIDDEN_PACKS;
        const int pack = word_index % HIDDEN_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(word, lane);
    load_initial_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            hidden[token][pack * PACK + i] = lane[i];
        }
        attention_residual_stream.write(word);
        v_hidden_stream.write(word);
    }
}

static void load_feedback_hidden(
    hidden_stream_t &feedback_stream,
    data_t hidden[SEQ_LEN][HIDDEN],
    hidden_stream_t &attention_residual_stream,
    hidden_stream_t &v_hidden_stream) {
#pragma HLS inline off
load_feedback_words:
    for (int word_index = 0; word_index < TOKEN_WORDS; ++word_index) {
#pragma HLS pipeline II=1
        const bus_t word = feedback_stream.read();
        const int token = word_index / HIDDEN_PACKS;
        const int pack = word_index % HIDDEN_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(word, lane);
    load_feedback_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            hidden[token][pack * PACK + i] = lane[i];
        }
        attention_residual_stream.write(word);
        v_hidden_stream.write(word);
    }
}

static void load_projection_bias_pair(
    const bus_t *q_bias,
    const bus_t *k_bias,
    int layer,
    int out_base,
    bias_t qb[PROJ_TILE_O],
    bias_t kb[PROJ_TILE_O]) {
#pragma HLS inline off
    const int word_index =
        layer * ATTN_BIAS_WORDS_PER_LAYER + out_base / PACK;
    const bus_t qword = q_bias[word_index];
    const bus_t kword = k_bias[word_index];
load_qk_bias:
    for (int lane = 0; lane < PROJ_TILE_O; ++lane) {
#pragma HLS unroll
        qb[lane] = bus_bias_lane(qword, lane);
        kb[lane] = bus_bias_lane(kword, lane);
    }
}

static void load_projection_bias_single(
    const bus_t *v_bias,
    int layer,
    int out_base,
    bias_t vb[PROJ_TILE_O]) {
#pragma HLS inline off
    const int word_index =
        layer * ATTN_BIAS_WORDS_PER_LAYER + out_base / PACK;
    const bus_t word = v_bias[word_index];
load_v_bias:
    for (int lane = 0; lane < PROJ_TILE_O; ++lane) {
#pragma HLS unroll
        vb[lane] = bus_bias_lane(word, lane);
    }
}

static void load_projection_weight_pair(
    const bus_t *q_weights,
    const bus_t *k_weights,
    int layer,
    int out_tile,
    weight_chunk_t wq[PROJ_O_PAR][PROJ_O_BLOCKS][PROJ_K_CHUNKS],
    weight_chunk_t wk[PROJ_O_PAR][PROJ_O_BLOCKS][PROJ_K_CHUNKS]) {
#pragma HLS inline off
load_qk_input_pack:
    for (int input_pack = 0; input_pack < HIDDEN_PACKS; ++input_pack) {
    load_qk_local_output:
        for (int local_out = 0; local_out < PROJ_TILE_O; ++local_out) {
#pragma HLS pipeline II=2
            const int external_index =
                layer * ATTN_WEIGHT_WORDS_PER_LAYER +
                (out_tile * HIDDEN_PACKS + input_pack) * PROJ_TILE_O +
                local_out;
            const bus_t qword = q_weights[external_index];
            const bus_t kword = k_weights[external_index];
            const int bank = local_out % PROJ_O_PAR;
            const int block = local_out / PROJ_O_PAR;
            wq[bank][block][2 * input_pack] = qword.range(255, 0);
            wq[bank][block][2 * input_pack + 1] = qword.range(511, 256);
            wk[bank][block][2 * input_pack] = kword.range(255, 0);
            wk[bank][block][2 * input_pack + 1] = kword.range(511, 256);
        }
    }
}

static void load_projection_weight_single(
    const bus_t *v_weights,
    int layer,
    int out_tile,
    weight_chunk_t wv[PROJ_O_PAR][PROJ_O_BLOCKS][PROJ_K_CHUNKS]) {
#pragma HLS inline off
load_v_input_pack:
    for (int input_pack = 0; input_pack < HIDDEN_PACKS; ++input_pack) {
    load_v_local_output:
        for (int local_out = 0; local_out < PROJ_TILE_O; ++local_out) {
#pragma HLS pipeline II=1
            const int external_index =
                layer * ATTN_WEIGHT_WORDS_PER_LAYER +
                (out_tile * HIDDEN_PACKS + input_pack) * PROJ_TILE_O +
                local_out;
            const bus_t word = v_weights[external_index];
            const int bank = local_out % PROJ_O_PAR;
            const int block = local_out / PROJ_O_PAR;
            wv[bank][block][2 * input_pack] = word.range(255, 0);
            wv[bank][block][2 * input_pack + 1] = word.range(511, 256);
        }
    }
}

static void project_qk_group(
    data_t hidden[SEQ_LEN][HIDDEN],
    const bus_t *q_weights,
    const bus_t *q_bias,
    const bus_t *k_weights,
    const bus_t *k_bias,
    int layer,
    int group,
    data_t q_group[SEQ_LEN][GROUP_DIM],
    data_t k_group[SEQ_LEN][GROUP_DIM]) {
#pragma HLS inline off
    weight_chunk_t
        wq[PROJ_O_PAR][PROJ_O_BLOCKS][PROJ_K_CHUNKS];
    weight_chunk_t
        wk[PROJ_O_PAR][PROJ_O_BLOCKS][PROJ_K_CHUNKS];
    bias_t qb[PROJ_TILE_O];
    bias_t kb[PROJ_TILE_O];
#pragma HLS bind_storage variable=wq type=ram_2p impl=uram
#pragma HLS bind_storage variable=wk type=ram_2p impl=bram
#pragma HLS array_partition variable=wq complete dim=1
#pragma HLS array_partition variable=wk complete dim=1
#pragma HLS array_partition variable=qb complete
#pragma HLS array_partition variable=kb complete

qk_group_tile:
    for (int local_base = 0; local_base < GROUP_DIM;
         local_base += PROJ_TILE_O) {
        const int out_base = group * GROUP_DIM + local_base;
        const int out_tile = out_base / PROJ_TILE_O;
        load_projection_bias_pair(
            q_bias, k_bias, layer, out_base, qb, kb);
        load_projection_weight_pair(
            q_weights, k_weights, layer, out_tile, wq, wk);

    qk_token:
        for (int token = 0; token < SEQ_LEN; ++token) {
        qk_output_block:
            for (int ob = 0; ob < PROJ_TILE_O; ob += PROJ_O_PAR) {
                acc_t qacc[PROJ_O_PAR];
                acc_t kacc[PROJ_O_PAR];
#pragma HLS array_partition variable=qacc complete
#pragma HLS array_partition variable=kacc complete
            qk_init_acc:
                for (int out = 0; out < PROJ_O_PAR; ++out) {
#pragma HLS unroll
                    qacc[out] = acc_t(qb[ob + out]);
                    kacc[out] = acc_t(kb[ob + out]);
                }

            qk_input_chunk:
                for (int chunk = 0; chunk < PROJ_K_CHUNKS; ++chunk) {
#pragma HLS pipeline II=1
                    data_t x[PROJ_K_PAR];
#pragma HLS array_partition variable=x complete
                qk_load_x:
                    for (int lane = 0; lane < PROJ_K_PAR; ++lane) {
#pragma HLS unroll
                        x[lane] =
                            hidden[token][chunk * PROJ_K_PAR + lane];
                    }
                qk_mac_outputs:
                    for (int out = 0; out < PROJ_O_PAR; ++out) {
#pragma HLS unroll
                        qacc[out] +=
                            dot16(x, wq[out][ob / PROJ_O_PAR][chunk]);
                        kacc[out] +=
                            dot16(x, wk[out][ob / PROJ_O_PAR][chunk]);
                    }
                }

            qk_store_outputs:
                for (int out = 0; out < PROJ_O_PAR; ++out) {
#pragma HLS unroll
                    q_group[token][local_base + ob + out] =
                        data_t(qacc[out]);
                    k_group[token][local_base + ob + out] =
                        data_t(kacc[out]);
                }
            }
        }
    }
}

static void project_v_group(
    data_t hidden[SEQ_LEN][HIDDEN],
    const bus_t *v_weights,
    const bus_t *v_bias,
    int layer,
    int group,
    data_t v_group[SEQ_LEN][GROUP_DIM]) {
#pragma HLS inline off
    weight_chunk_t
        wv[PROJ_O_PAR][PROJ_O_BLOCKS][PROJ_K_CHUNKS];
    bias_t vb[PROJ_TILE_O];
#pragma HLS bind_storage variable=wv type=ram_2p impl=bram
#pragma HLS array_partition variable=wv complete dim=1
#pragma HLS array_partition variable=vb complete

v_group_tile:
    for (int local_base = 0; local_base < GROUP_DIM;
         local_base += PROJ_TILE_O) {
        const int out_base = group * GROUP_DIM + local_base;
        const int out_tile = out_base / PROJ_TILE_O;
        load_projection_bias_single(v_bias, layer, out_base, vb);
        load_projection_weight_single(
            v_weights, layer, out_tile, wv);

    v_token:
        for (int token = 0; token < SEQ_LEN; ++token) {
        v_output_block:
            for (int ob = 0; ob < PROJ_TILE_O; ob += PROJ_O_PAR) {
                acc_t vacc[PROJ_O_PAR];
#pragma HLS array_partition variable=vacc complete
            v_init_acc:
                for (int out = 0; out < PROJ_O_PAR; ++out) {
#pragma HLS unroll
                    vacc[out] = acc_t(vb[ob + out]);
                }
            v_input_chunk:
                for (int chunk = 0; chunk < PROJ_K_CHUNKS; ++chunk) {
#pragma HLS pipeline II=1
                    data_t x[PROJ_K_PAR];
#pragma HLS array_partition variable=x complete
                v_load_x:
                    for (int lane = 0; lane < PROJ_K_PAR; ++lane) {
#pragma HLS unroll
                        x[lane] =
                            hidden[token][chunk * PROJ_K_PAR + lane];
                    }
                v_mac_outputs:
                    for (int out = 0; out < PROJ_O_PAR; ++out) {
#pragma HLS unroll
                        vacc[out] +=
                            dot16(x, wv[out][ob / PROJ_O_PAR][chunk]);
                    }
                }
            v_store_outputs:
                for (int out = 0; out < PROJ_O_PAR; ++out) {
#pragma HLS unroll
                    v_group[token][local_base + ob + out] =
                        data_t(vacc[out]);
                }
            }
        }
    }
}

static void write_qk_group(
    data_t q_group[SEQ_LEN][GROUP_DIM],
    data_t k_group[SEQ_LEN][GROUP_DIM],
    hidden_stream_t &q_stream,
    hidden_stream_t &k_stream) {
#pragma HLS inline off
write_qk_words:
    for (int word_index = 0;
         word_index < SEQ_LEN * GROUP_PACKS; ++word_index) {
#pragma HLS pipeline II=1
        const int token = word_index / GROUP_PACKS;
        const int pack = word_index % GROUP_PACKS;
        data_t qlane[PACK];
        data_t klane[PACK];
#pragma HLS array_partition variable=qlane complete
#pragma HLS array_partition variable=klane complete
    write_qk_lanes:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            qlane[lane] = q_group[token][pack * PACK + lane];
            klane[lane] = k_group[token][pack * PACK + lane];
        }
        q_stream.write(pack_data_lanes(qlane));
        k_stream.write(pack_data_lanes(klane));
    }
}

static void write_v_group(
    data_t v_group[SEQ_LEN][GROUP_DIM],
    hidden_stream_t &v_stream) {
#pragma HLS inline off
write_v_words:
    for (int word_index = 0;
         word_index < SEQ_LEN * GROUP_PACKS; ++word_index) {
#pragma HLS pipeline II=1
        const int token = word_index / GROUP_PACKS;
        const int pack = word_index % GROUP_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
    write_v_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            lane[i] = v_group[token][pack * PACK + i];
        }
        v_stream.write(pack_data_lanes(lane));
    }
}

static void read_v_hidden(
    hidden_stream_t &v_hidden_stream,
    data_t hidden[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
read_v_hidden_words:
    for (int word_index = 0; word_index < TOKEN_WORDS; ++word_index) {
#pragma HLS pipeline II=1
        const bus_t word = v_hidden_stream.read();
        const int token = word_index / HIDDEN_PACKS;
        const int pack = word_index % HIDDEN_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(word, lane);
    read_v_hidden_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            hidden[token][pack * PACK + i] = lane[i];
        }
    }
}

extern "C" void bert_qk_persistent(
    const bus_t *initial_hidden,
    const bus_t *q_weights,
    const bus_t *q_bias,
    const bus_t *k_weights,
    const bus_t *k_bias,
    hidden_stream_t &feedback_stream,
    hidden_stream_t &attention_residual_stream,
    hidden_stream_t &v_hidden_stream,
    hidden_stream_t &q_stream,
    hidden_stream_t &k_stream) {
#pragma HLS interface m_axi port=initial_hidden offset=slave bundle=gmem_input depth=TOKEN_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=q_weights offset=slave bundle=gmem_q depth=ALL_ATTN_WEIGHT_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=q_bias offset=slave bundle=gmem_q depth=ALL_ATTN_BIAS_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=k_weights offset=slave bundle=gmem_k depth=ALL_ATTN_WEIGHT_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=k_bias offset=slave bundle=gmem_k depth=ALL_ATTN_BIAS_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface axis port=feedback_stream
#pragma HLS interface axis port=attention_residual_stream
#pragma HLS interface axis port=v_hidden_stream
#pragma HLS interface axis port=q_stream
#pragma HLS interface axis port=k_stream
#pragma HLS interface s_axilite port=initial_hidden bundle=control
#pragma HLS interface s_axilite port=q_weights bundle=control
#pragma HLS interface s_axilite port=q_bias bundle=control
#pragma HLS interface s_axilite port=k_weights bundle=control
#pragma HLS interface s_axilite port=k_bias bundle=control
#pragma HLS interface s_axilite port=return bundle=control

    static data_t hidden[SEQ_LEN][HIDDEN];
    static data_t q_group[SEQ_LEN][GROUP_DIM];
    static data_t k_group[SEQ_LEN][GROUP_DIM];
#pragma HLS bind_storage variable=hidden type=ram_2p impl=uram
#pragma HLS bind_storage variable=q_group type=ram_2p impl=uram
#pragma HLS bind_storage variable=k_group type=ram_2p impl=uram
#pragma HLS array_reshape variable=hidden cyclic factor=PROJ_K_PAR dim=2
#pragma HLS array_reshape variable=q_group cyclic factor=PACK dim=2
#pragma HLS array_reshape variable=k_group cyclic factor=PACK dim=2

qk_layer:
    for (int layer = 0; layer < NUM_LAYERS; ++layer) {
        if (layer == 0) {
            load_initial_hidden(
                initial_hidden, hidden,
                attention_residual_stream, v_hidden_stream);
        } else {
            load_feedback_hidden(
                feedback_stream, hidden,
                attention_residual_stream, v_hidden_stream);
        }
    qk_head_group:
        for (int group = 0; group < HEAD_GROUPS; ++group) {
            project_qk_group(
                hidden, q_weights, q_bias, k_weights, k_bias,
                layer, group, q_group, k_group);
            write_qk_group(q_group, k_group, q_stream, k_stream);
        }
    }
}

extern "C" void bert_v_persistent(
    const bus_t *v_weights,
    const bus_t *v_bias,
    hidden_stream_t &v_hidden_stream,
    hidden_stream_t &v_stream) {
#pragma HLS interface m_axi port=v_weights offset=slave bundle=gmem_v depth=ALL_ATTN_WEIGHT_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=v_bias offset=slave bundle=gmem_v depth=ALL_ATTN_BIAS_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface axis port=v_hidden_stream
#pragma HLS interface axis port=v_stream
#pragma HLS interface s_axilite port=v_weights bundle=control
#pragma HLS interface s_axilite port=v_bias bundle=control
#pragma HLS interface s_axilite port=return bundle=control

    static data_t hidden[SEQ_LEN][HIDDEN];
    static data_t v_group[SEQ_LEN][GROUP_DIM];
#pragma HLS bind_storage variable=hidden type=ram_2p impl=uram
#pragma HLS bind_storage variable=v_group type=ram_2p impl=uram
#pragma HLS array_reshape variable=hidden cyclic factor=PROJ_K_PAR dim=2
#pragma HLS array_reshape variable=v_group cyclic factor=PACK dim=2

v_layer:
    for (int layer = 0; layer < NUM_LAYERS; ++layer) {
        read_v_hidden(v_hidden_stream, hidden);
    v_head_group:
        for (int group = 0; group < HEAD_GROUPS; ++group) {
            project_v_group(
                hidden, v_weights, v_bias,
                layer, group, v_group);
            write_v_group(v_group, v_stream);
        }
    }
}
