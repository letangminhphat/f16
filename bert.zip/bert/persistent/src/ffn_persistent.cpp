#include <hls_math.h>

#include "bert_interfaces.hpp"

static void read_attention_mid(
    hidden_stream_t &attention_mid_stream,
    data_t input[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
read_attention_mid_words:
    for (int word_index = 0; word_index < TOKEN_WORDS; ++word_index) {
#pragma HLS pipeline II=1
        const bus_t word = attention_mid_stream.read();
        const int token = word_index / HIDDEN_PACKS;
        const int pack = word_index % HIDDEN_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(word, lane);
    read_attention_mid_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            input[token][pack * PACK + i] = lane[i];
        }
    }
}

static void load_ffn1_weight_tile(
    const bus_t *ffn1_weights,
    int layer,
    int out_tile,
    weight_chunk_t weight[FFN_O_PAR][FFN_INPUT_CHUNKS]) {
#pragma HLS inline off
load_ffn1_input_pack:
    for (int input_pack = 0; input_pack < HIDDEN_PACKS; ++input_pack) {
    load_ffn1_output:
        for (int out = 0; out < FFN_TILE_O; ++out) {
#pragma HLS pipeline II=1
            const int external_index =
                layer * FFN1_WEIGHT_WORDS_PER_LAYER +
                (out_tile * HIDDEN_PACKS + input_pack) * FFN_TILE_O +
                out;
            const bus_t word = ffn1_weights[external_index];
            weight[out][2 * input_pack] = word.range(255, 0);
            weight[out][2 * input_pack + 1] = word.range(511, 256);
        }
    }
}

static void ffn_up_layer(
    data_t input[SEQ_LEN][HIDDEN],
    const bus_t *ffn1_weights,
    const bus_t *ffn1_bias,
    int layer,
    hidden_stream_t &gelu_stream) {
#pragma HLS inline off
    weight_chunk_t weight[FFN_O_PAR][FFN_INPUT_CHUNKS];
    acc_t accumulator[SEQ_LEN][FFN_TILE_O];
#pragma HLS bind_storage variable=weight type=ram_2p impl=bram
#pragma HLS bind_storage variable=accumulator type=ram_2p impl=bram
#pragma HLS array_partition variable=weight complete dim=1
#pragma HLS array_partition variable=accumulator complete dim=2

ffn_up_output_tile:
    for (int out_tile = 0; out_tile < FFN_TILE_COUNT; ++out_tile) {
        const bus_t bias_word =
            ffn1_bias[layer * FFN1_BIAS_WORDS_PER_LAYER + out_tile];
        bias_t bias_lane[FFN_TILE_O];
#pragma HLS array_partition variable=bias_lane complete
    ffn_up_load_bias:
        for (int out = 0; out < FFN_TILE_O; ++out) {
#pragma HLS unroll
            bias_lane[out] = bus_bias_lane(bias_word, out);
        }
    ffn_up_init_tokens:
        for (int token = 0; token < SEQ_LEN; ++token) {
#pragma HLS pipeline II=1
        ffn_up_init_outputs:
            for (int out = 0; out < FFN_TILE_O; ++out) {
#pragma HLS unroll
                accumulator[token][out] = acc_t(bias_lane[out]);
            }
        }

        load_ffn1_weight_tile(
            ffn1_weights, layer, out_tile, weight);

    ffn_up_input_chunk:
        for (int chunk = 0; chunk < FFN_INPUT_CHUNKS; ++chunk) {
        ffn_up_token:
            for (int token = 0; token < SEQ_LEN; ++token) {
#pragma HLS pipeline II=1
                data_t x[FFN_K_PAR];
#pragma HLS array_partition variable=x complete
            ffn_up_load_x:
                for (int lane = 0; lane < FFN_K_PAR; ++lane) {
#pragma HLS unroll
                    x[lane] =
                        input[token][chunk * FFN_K_PAR + lane];
                }
            ffn_up_mac:
                for (int out = 0; out < FFN_O_PAR; ++out) {
#pragma HLS unroll
                    accumulator[token][out] +=
                        dot16(x, weight[out][chunk]);
                }
            }
        }

    ffn_up_write_tokens:
        for (int token = 0; token < SEQ_LEN; ++token) {
#pragma HLS pipeline II=1
            data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        ffn_up_gelu_lanes:
            for (int out = 0; out < FFN_TILE_O; ++out) {
#pragma HLS unroll
                lane[out] = fixed_gelu(accumulator[token][out]);
            }
            gelu_stream.write(pack_data_lanes(lane));
        }
    }
}

static void initialize_ffn_down_residual(
    hidden_stream_t &ffn_residual_stream,
    const bus_t *ffn2_bias,
    int layer,
    acc_t output[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
ffn_down_residual_token:
    for (int token = 0; token < SEQ_LEN; ++token) {
    ffn_down_residual_pack:
        for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
            const bus_t bias_word =
                ffn2_bias[layer * FFN2_BIAS_WORDS_PER_LAYER + pack];
            bias_t bias_lane[PACK];
            data_t residual_lane[PACK];
#pragma HLS array_partition variable=bias_lane complete
#pragma HLS array_partition variable=residual_lane complete
            unpack_data_lanes(ffn_residual_stream.read(), residual_lane);
        ffn_down_bias_lanes:
            for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
                bias_lane[lane] = bus_bias_lane(bias_word, lane);
            }
        ffn_down_residual_lanes:
            for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
                output[token][pack * PACK + lane] =
                    acc_t(bias_lane[lane]) + acc_t(residual_lane[lane]);
            }
        }
    }
}

static void read_gelu_tile(
    hidden_stream_t &gelu_stream,
    data_t activation[SEQ_LEN][FFN_TILE_O]) {
#pragma HLS inline off
read_gelu_tokens:
    for (int token = 0; token < SEQ_LEN; ++token) {
#pragma HLS pipeline II=1
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        unpack_data_lanes(gelu_stream.read(), lane);
    read_gelu_lanes:
        for (int i = 0; i < FFN_TILE_O; ++i) {
#pragma HLS unroll
            activation[token][i] = lane[i];
        }
    }
}

static void load_ffn2_weight_tile(
    const bus_t *ffn2_weights,
    int layer,
    int input_tile,
    int output_tile,
    weight_t weight[FFN_TILE_O][FFN_TILE_O]) {
#pragma HLS inline off
load_ffn2_input:
    for (int input = 0; input < FFN_TILE_O; ++input) {
#pragma HLS pipeline II=1
        const int external_index =
            layer * FFN2_WEIGHT_WORDS_PER_LAYER +
            (input_tile * (HIDDEN / FFN_TILE_O) + output_tile) *
                FFN_TILE_O +
            input;
        const bus_t word = ffn2_weights[external_index];
    load_ffn2_outputs:
        for (int output_lane = 0; output_lane < FFN_TILE_O;
             ++output_lane) {
#pragma HLS unroll
            weight[output_lane][input] =
                bus_weight_lane(word, output_lane);
        }
    }
}

static acc_t ffn_down_dot16(
    const data_t input[FFN_K_PAR],
    const weight_t weight[FFN_K_PAR]) {
#pragma HLS inline
    acc_t partial[FFN_K_PAR];
#pragma HLS array_partition variable=partial complete
#pragma HLS bind_op variable=partial op=mul impl=dsp
ffn_down_products:
    for (int lane = 0; lane < FFN_K_PAR; ++lane) {
#pragma HLS unroll
        partial[lane] =
            acc_t(input[lane]) * acc_t(weight[lane]);
    }
ffn_down_reduce:
    for (int stride = FFN_K_PAR / 2; stride > 0; stride >>= 1) {
#pragma HLS unroll
        for (int lane = 0; lane < stride; ++lane) {
#pragma HLS unroll
            partial[lane] += partial[lane + stride];
        }
    }
    return partial[0];
}

static void ffn_down_layer(
    hidden_stream_t &gelu_stream,
    const bus_t *ffn2_weights,
    int layer,
    acc_t output[SEQ_LEN][HIDDEN]) {
#pragma HLS inline off
    data_t activation[SEQ_LEN][FFN_TILE_O];
    weight_t weight[FFN_TILE_O][FFN_TILE_O];
#pragma HLS bind_storage variable=activation type=ram_2p impl=bram
#pragma HLS array_partition variable=activation complete dim=2
#pragma HLS array_partition variable=weight complete dim=1
#pragma HLS array_partition variable=weight cyclic factor=FFN_K_PAR dim=2

ffn_down_input_tile:
    for (int input_tile = 0; input_tile < FFN_TILE_COUNT;
         ++input_tile) {
        read_gelu_tile(gelu_stream, activation);
    ffn_down_output_tile:
        for (int output_tile = 0;
             output_tile < HIDDEN / FFN_TILE_O; ++output_tile) {
            load_ffn2_weight_tile(
                ffn2_weights, layer,
                input_tile, output_tile, weight);
        ffn_down_token:
            for (int token = 0; token < SEQ_LEN; ++token) {
            ffn_down_input_chunk:
                for (int chunk = 0; chunk < FFN_TILE_O / FFN_K_PAR;
                     ++chunk) {
#pragma HLS pipeline II=1
                    data_t x[FFN_K_PAR];
#pragma HLS array_partition variable=x complete
                ffn_down_load_x:
                    for (int lane = 0; lane < FFN_K_PAR; ++lane) {
#pragma HLS unroll
                        x[lane] =
                            activation[token][chunk * FFN_K_PAR + lane];
                    }
                ffn_down_mac_output:
                    for (int out = 0; out < FFN_O_PAR; ++out) {
#pragma HLS unroll
                        weight_t weight_lane[FFN_K_PAR];
#pragma HLS array_partition variable=weight_lane complete
                    ffn_down_load_weight_lane:
                        for (int lane = 0; lane < FFN_K_PAR; ++lane) {
#pragma HLS unroll
                            weight_lane[lane] =
                                weight[out]
                                      [chunk * FFN_K_PAR + lane];
                        }
                        output[token]
                              [output_tile * FFN_TILE_O + out] +=
                            ffn_down_dot16(x, weight_lane);
                    }
                }
            }
        }
    }
}

static void ffn_norm_and_route(
    acc_t output[SEQ_LEN][HIDDEN],
    const bus_t *gamma,
    const bus_t *beta,
    int layer,
    hidden_stream_t &feedback_stream,
    bus_t *last_hidden_state) {
#pragma HLS inline off
    norm_t gamma_cache[HIDDEN];
    norm_t beta_cache[HIDDEN];
#pragma HLS bind_storage variable=gamma_cache type=ram_2p impl=bram
#pragma HLS bind_storage variable=beta_cache type=ram_2p impl=bram
#pragma HLS array_reshape variable=gamma_cache cyclic factor=PACK
#pragma HLS array_reshape variable=beta_cache cyclic factor=PACK

load_ffn_norm:
    for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
        const bus_t gamma_word =
            gamma[layer * NORM_WORDS_PER_LAYER + pack];
        const bus_t beta_word =
            beta[layer * NORM_WORDS_PER_LAYER + pack];
    load_ffn_norm_lanes:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            gamma_cache[pack * PACK + lane] =
                bus_norm_lane(gamma_word, lane);
            beta_cache[pack * PACK + lane] =
                bus_norm_lane(beta_word, lane);
        }
    }

ffn_norm_token:
    for (int token = 0; token < SEQ_LEN; ++token) {
        acc_t sum_bank[PACK];
        acc_t square_bank[PACK];
#pragma HLS array_partition variable=sum_bank complete
#pragma HLS array_partition variable=square_bank complete
    ffn_norm_init:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            sum_bank[lane] = 0;
            square_bank[lane] = 0;
        }
        const acc_t inv_hidden = acc_t(1.0 / 768.0);
    ffn_norm_reduce_pack:
        for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
        ffn_norm_reduce_lanes:
            for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
                const acc_t value =
                    output[token][pack * PACK + lane];
                sum_bank[lane] += value * inv_hidden;
                square_bank[lane] +=
                    value * value * inv_hidden;
            }
        }
        acc_t mean = 0;
        acc_t mean_square = 0;
    ffn_norm_bank_reduce:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            mean += sum_bank[lane];
            mean_square += square_bank[lane];
        }
        acc_t variance = mean_square - mean * mean;
        const acc_t epsilon = acc_t(0.00000095367431640625);
        if (variance < epsilon) {
            variance = epsilon;
        }
        const acc_t inverse_stddev =
            acc_t(1) / acc_t(hls::sqrt(variance));

    ffn_norm_write_pack:
        for (int pack = 0; pack < HIDDEN_PACKS; ++pack) {
#pragma HLS pipeline II=1
            data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
        ffn_norm_write_lanes:
            for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
                const int hidden = pack * PACK + i;
                lane[i] = data_t(
                    (output[token][hidden] - mean) * inverse_stddev *
                        acc_t(gamma_cache[hidden]) +
                    acc_t(beta_cache[hidden]));
            }
            const bus_t word = pack_data_lanes(lane);
            if (layer != NUM_LAYERS - 1) {
                feedback_stream.write(word);
            } else {
                last_hidden_state[token * HIDDEN_PACKS + pack] = word;
            }
        }
    }
}

extern "C" void bert_ffn_up_persistent(
    hidden_stream_t &attention_mid_stream,
    const bus_t *ffn1_weights,
    const bus_t *ffn1_bias,
    hidden_stream_t &gelu_stream) {
#pragma HLS interface axis port=attention_mid_stream
#pragma HLS interface axis port=gelu_stream
#pragma HLS interface m_axi port=ffn1_weights offset=slave bundle=gmem_ffn1 depth=ALL_FFN1_WEIGHT_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=ffn1_bias offset=slave bundle=gmem_ffn1 depth=ALL_FFN1_BIAS_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface s_axilite port=ffn1_weights bundle=control
#pragma HLS interface s_axilite port=ffn1_bias bundle=control
#pragma HLS interface s_axilite port=return bundle=control

    static data_t input[SEQ_LEN][HIDDEN];
#pragma HLS bind_storage variable=input type=ram_2p impl=uram
#pragma HLS array_reshape variable=input cyclic factor=FFN_K_PAR dim=2

ffn_up_layers:
    for (int layer = 0; layer < NUM_LAYERS; ++layer) {
        read_attention_mid(attention_mid_stream, input);
        ffn_up_layer(
            input, ffn1_weights, ffn1_bias, layer, gelu_stream);
    }
}

extern "C" void bert_ffn_down_persistent(
    hidden_stream_t &gelu_stream,
    hidden_stream_t &ffn_residual_stream,
    const bus_t *ffn2_weights,
    const bus_t *ffn2_bias,
    const bus_t *ffn_norm_gamma,
    const bus_t *ffn_norm_beta,
    hidden_stream_t &feedback_stream,
    bus_t *last_hidden_state) {
#pragma HLS interface axis port=gelu_stream
#pragma HLS interface axis port=ffn_residual_stream
#pragma HLS interface axis port=feedback_stream
#pragma HLS interface m_axi port=ffn2_weights offset=slave bundle=gmem_ffn2 depth=ALL_FFN2_WEIGHT_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=ffn2_bias offset=slave bundle=gmem_ffn2 depth=ALL_FFN2_BIAS_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=ffn_norm_gamma offset=slave bundle=gmem_ffn_norm depth=ALL_NORM_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=ffn_norm_beta offset=slave bundle=gmem_ffn_norm depth=ALL_NORM_WORDS max_read_burst_length=64 num_read_outstanding=16
#pragma HLS interface m_axi port=last_hidden_state offset=slave bundle=gmem_output depth=TOKEN_WORDS max_write_burst_length=64 num_write_outstanding=16
#pragma HLS interface s_axilite port=ffn2_weights bundle=control
#pragma HLS interface s_axilite port=ffn2_bias bundle=control
#pragma HLS interface s_axilite port=ffn_norm_gamma bundle=control
#pragma HLS interface s_axilite port=ffn_norm_beta bundle=control
#pragma HLS interface s_axilite port=last_hidden_state bundle=control
#pragma HLS interface s_axilite port=return bundle=control

    static acc_t output[SEQ_LEN][HIDDEN];
#pragma HLS bind_storage variable=output type=ram_2p impl=uram
#pragma HLS array_reshape variable=output cyclic factor=PACK dim=2

ffn_down_layers:
    for (int layer = 0; layer < NUM_LAYERS; ++layer) {
        // Drain residual before waiting for GELU to prevent cyclic
        // backpressure in the persistent feedback graph.
        initialize_ffn_down_residual(
            ffn_residual_stream, ffn2_bias, layer, output);
        ffn_down_layer(gelu_stream, ffn2_weights, layer, output);
        ffn_norm_and_route(
            output, ffn_norm_gamma, ffn_norm_beta, layer,
            feedback_stream, last_hidden_state);
    }
}
