#include <hls_math.h>

#include "bert_interfaces.hpp"

static void read_qkv_group(
    hidden_stream_t &q_stream,
    hidden_stream_t &k_stream,
    hidden_stream_t &v_stream,
    data_t q[SEQ_LEN][GROUP_DIM],
    data_t k[SEQ_LEN][GROUP_DIM],
    data_t v[SEQ_LEN][GROUP_DIM]) {
#pragma HLS inline off
read_qkv_words:
    for (int word_index = 0;
         word_index < SEQ_LEN * GROUP_PACKS; ++word_index) {
#pragma HLS pipeline II=1
        const int token = word_index / GROUP_PACKS;
        const int pack = word_index % GROUP_PACKS;
        data_t qlane[PACK];
        data_t klane[PACK];
        data_t vlane[PACK];
#pragma HLS array_partition variable=qlane complete
#pragma HLS array_partition variable=klane complete
#pragma HLS array_partition variable=vlane complete
        unpack_data_lanes(q_stream.read(), qlane);
        unpack_data_lanes(k_stream.read(), klane);
        unpack_data_lanes(v_stream.read(), vlane);
    read_qkv_lanes:
        for (int lane = 0; lane < PACK; ++lane) {
#pragma HLS unroll
            const int index = pack * PACK + lane;
            q[token][index] = qlane[lane];
            k[token][index] = klane[lane];
            v[token][index] = vlane[lane];
        }
    }
}

static void attention_dot_pair(
    data_t q[SEQ_LEN][GROUP_DIM],
    data_t k[SEQ_LEN][GROUP_DIM],
    int query0,
    int query1,
    int key,
    int head_base,
    acc_t &dot0,
    acc_t &dot1) {
#pragma HLS inline
    acc_t product0[HEAD_DIM];
    acc_t product1[HEAD_DIM];
#pragma HLS array_partition variable=product0 complete
#pragma HLS array_partition variable=product1 complete
#pragma HLS bind_op variable=product0 op=mul impl=dsp
#pragma HLS bind_op variable=product1 op=mul impl=dsp
attention_dot_products:
    for (int dim = 0; dim < HEAD_DIM; ++dim) {
#pragma HLS unroll
        const acc_t kval = acc_t(k[key][head_base + dim]);
        product0[dim] = acc_t(q[query0][head_base + dim]) * kval;
        product1[dim] = acc_t(q[query1][head_base + dim]) * kval;
    }
attention_dot_reduce:
    for (int stride = HEAD_DIM / 2; stride > 0; stride >>= 1) {
#pragma HLS unroll
        for (int dim = 0; dim < stride; ++dim) {
#pragma HLS unroll
            product0[dim] += product0[dim + stride];
            product1[dim] += product1[dim + stride];
        }
    }
    dot0 = product0[0];
    dot1 = product1[0];
}

static void attention_group(
    data_t q[SEQ_LEN][GROUP_DIM],
    data_t k[SEQ_LEN][GROUP_DIM],
    data_t v[SEQ_LEN][GROUP_DIM],
    const ap_uint<8> active_indices[SEQ_LEN],
    int active_count,
    data_t context[SEQ_LEN][GROUP_DIM]) {
#pragma HLS inline off
head_loop:
    for (int head = 0; head < HEAD_PAR; ++head) {
        const int head_base = head * HEAD_DIM;
    query_pair_loop:
        for (int query = 0; query < SEQ_LEN; query += ATTN_QUERY_PAR) {
            acc_t probability0[SEQ_LEN];
            acc_t probability1[SEQ_LEN];
#pragma HLS bind_storage variable=probability0 type=ram_2p impl=bram
#pragma HLS bind_storage variable=probability1 type=ram_2p impl=bram
            acc_t maximum0 = acc_t(-1024.0);
            acc_t maximum1 = acc_t(-1024.0);

        score_keys:
            for (int n = 0; n < active_count; ++n) {
#pragma HLS loop_tripcount min=1 max=128
#pragma HLS pipeline II=1
                const int key = active_indices[n];
                acc_t dot0;
                acc_t dot1;
                attention_dot_pair(
                    q, k, query, query + 1, key, head_base, dot0, dot1);
                const acc_t score0 = dot0 * acc_t(0.125);
                const acc_t score1 = dot1 * acc_t(0.125);
                probability0[n] = score0;
                probability1[n] = score1;
                if (score0 > maximum0) {
                    maximum0 = score0;
                }
                if (score1 > maximum1) {
                    maximum1 = score1;
                }
            }

            acc_t sum0 = 0;
            acc_t sum1 = 0;
        exponentiate_keys:
            for (int n = 0; n < active_count; ++n) {
#pragma HLS loop_tripcount min=1 max=128
#pragma HLS pipeline II=1
                const acc_t exp0 =
                    acc_t(hls::exp(probability0[n] - maximum0));
                const acc_t exp1 =
                    acc_t(hls::exp(probability1[n] - maximum1));
                probability0[n] = exp0;
                probability1[n] = exp1;
                sum0 += exp0;
                sum1 += exp1;
            }

            const acc_t inverse0 =
                (sum0 > acc_t(0)) ? acc_t(1) / sum0 : acc_t(0);
            const acc_t inverse1 =
                (sum1 > acc_t(0)) ? acc_t(1) / sum1 : acc_t(0);

        context_chunk:
            for (int dim_base = 0; dim_base < HEAD_DIM;
                 dim_base += ATTN_CONTEXT_PAR) {
                acc_t context0[ATTN_CONTEXT_PAR];
                acc_t context1[ATTN_CONTEXT_PAR];
                acc_t context_product0[ATTN_CONTEXT_PAR];
                acc_t context_product1[ATTN_CONTEXT_PAR];
#pragma HLS array_partition variable=context0 complete
#pragma HLS array_partition variable=context1 complete
#pragma HLS array_partition variable=context_product0 complete
#pragma HLS array_partition variable=context_product1 complete
#pragma HLS bind_op variable=context_product0 op=mul impl=dsp
#pragma HLS bind_op variable=context_product1 op=mul impl=dsp
            context_init:
                for (int lane = 0; lane < ATTN_CONTEXT_PAR; ++lane) {
#pragma HLS unroll
                    context0[lane] = 0;
                    context1[lane] = 0;
                }
            context_keys:
                for (int n = 0; n < active_count; ++n) {
#pragma HLS loop_tripcount min=1 max=128
#pragma HLS pipeline II=1
                    const int key = active_indices[n];
                    const acc_t p0 = probability0[n] * inverse0;
                    const acc_t p1 = probability1[n] * inverse1;
                context_lanes:
                    for (int lane = 0; lane < ATTN_CONTEXT_PAR; ++lane) {
#pragma HLS unroll
                        const acc_t value =
                            acc_t(v[key][head_base + dim_base + lane]);
                        context_product0[lane] = p0 * value;
                        context_product1[lane] = p1 * value;
                        context0[lane] += context_product0[lane];
                        context1[lane] += context_product1[lane];
                    }
                }
            context_store:
                for (int lane = 0; lane < ATTN_CONTEXT_PAR; ++lane) {
#pragma HLS unroll
                    const int dim = head_base + dim_base + lane;
                    context[query][dim] = data_t(context0[lane]);
                    context[query + 1][dim] = data_t(context1[lane]);
                }
            }
        }
    }
}

static void write_context_group(
    data_t context[SEQ_LEN][GROUP_DIM],
    hidden_stream_t &context_stream) {
#pragma HLS inline off
write_context_words:
    for (int word_index = 0;
         word_index < SEQ_LEN * GROUP_PACKS; ++word_index) {
#pragma HLS pipeline II=1
        const int token = word_index / GROUP_PACKS;
        const int pack = word_index % GROUP_PACKS;
        data_t lane[PACK];
#pragma HLS array_partition variable=lane complete
    write_context_lanes:
        for (int i = 0; i < PACK; ++i) {
#pragma HLS unroll
            lane[i] = context[token][pack * PACK + i];
        }
        context_stream.write(pack_data_lanes(lane));
    }
}

extern "C" void bert_attention_persistent(
    hidden_stream_t &q_stream,
    hidden_stream_t &k_stream,
    hidden_stream_t &v_stream,
    const ap_uint<16> *attention_mask,
    hidden_stream_t &context_stream) {
#pragma HLS interface axis port=q_stream
#pragma HLS interface axis port=k_stream
#pragma HLS interface axis port=v_stream
#pragma HLS interface axis port=context_stream
#pragma HLS interface m_axi port=attention_mask offset=slave bundle=gmem_mask depth=SEQ_LEN max_widen_bitwidth=32
#pragma HLS interface s_axilite port=attention_mask bundle=control
#pragma HLS interface s_axilite port=return bundle=control

    ap_uint<8> active_indices[SEQ_LEN];
    static data_t q[SEQ_LEN][GROUP_DIM];
    static data_t k[SEQ_LEN][GROUP_DIM];
    static data_t v[SEQ_LEN][GROUP_DIM];
    static data_t context[SEQ_LEN][GROUP_DIM];
#pragma HLS bind_storage variable=active_indices type=ram_s2p impl=lutram
#pragma HLS bind_storage variable=q type=ram_2p impl=uram
#pragma HLS bind_storage variable=k type=ram_2p impl=uram
#pragma HLS bind_storage variable=v type=ram_2p impl=uram
#pragma HLS bind_storage variable=context type=ram_2p impl=uram
#pragma HLS array_reshape variable=q cyclic factor=ATTN_D_PAR dim=2
#pragma HLS array_reshape variable=k cyclic factor=ATTN_D_PAR dim=2
#pragma HLS array_reshape variable=v cyclic factor=ATTN_CONTEXT_PAR dim=2
#pragma HLS array_reshape variable=context cyclic factor=ATTN_CONTEXT_PAR dim=2

    int active_count = 0;
load_active_mask:
    for (int token = 0; token < SEQ_LEN; ++token) {
#pragma HLS pipeline II=1
        if (attention_mask[token] != 0) {
            active_indices[active_count] = ap_uint<8>(token);
            ++active_count;
        }
    }

attention_layer:
    for (int layer = 0; layer < NUM_LAYERS; ++layer) {
    attention_head_group:
        for (int group = 0; group < HEAD_GROUPS; ++group) {
            read_qkv_group(q_stream, k_stream, v_stream, q, k, v);
            attention_group(
                q, k, v, active_indices, active_count, context);
            write_context_group(context, context_stream);
        }
    }
}
