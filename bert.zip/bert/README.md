# BERT-base Fixed16 persistent encoder for Alveo U250

This directory contains the 12-layer BERT-base encoder compute graph for
Vitis HLS 2022.1. Embedding, pooler, classifier, tokenizer and host code are
outside the current hardware scope.

## Fixed contract

- Sequence length: 128
- Hidden size: 768
- Attention heads: 12
- Head dimension: 64
- FFN dimension: 3072
- Encoder layers: 12
- Topology: BERT Post-LayerNorm
- Target clock: 250 MHz
- Target persistent latency: 100 ms
- Stored activations and parameters: Fixed16
- Accumulations, softmax and LayerNorm reductions: Fixed32
- External memory and streams: 512 bits, 32 Fixed16 values per word

## Persistent graph

All controlled compute units are started once. Each compute unit contains the
same fixed 12-layer loop. The output of layer N is fed back entirely on the
device as the input of layer N+1.

```text
SLR0                    SLR1                      SLR2                 SLR3
qk12 ── Q,K ─────────> attention12 ─ context ─> out12 ─ mid ──────> up12
 │                        ▲                         │                   │
 └─ hidden broadcast ──> v12                       └─ FFN residual ───┼─> down12
 │                                                                    │
 └─ attention residual ─ relay SLR1 ─────────────────────────────────>│
                                                                      │
 qk12 <──── relay SLR1 <──── relay SLR2 <──── next hidden ────────────┘
```

Physical placement:

| SLR | Compute units |
|---|---|
| SLR0 | `bert_qk_persistent` |
| SLR1 | `bert_v_persistent`, `bert_attention_persistent`, residual relay, feedback relay |
| SLR2 | `bert_attention_out_persistent`, `bert_ffn_up_persistent`, feedback relay |
| SLR3 | `bert_ffn_down_persistent` |

The relays are free-running `ap_ctrl_none` kernels with II=1. They break the
long SLR0↔SLR3 feedback and SLR0→SLR2 residual paths into adjacent crossings.

## Compute profile

| Block | Parallel Fixed16 MACs | Main tiling |
|---|---:|---|
| Q+K | 256 | 8 outputs × 16 inputs × 2 projections |
| V | 128 | 8 outputs × 16 inputs |
| Attention score | 128 | two queries × 64 head dimensions |
| Attention context | 64 | two queries × 32 output dimensions |
| Attention output | 256 | 16 outputs × 16 inputs |
| FFN UP | 512 | 32 outputs × 16 inputs |
| FFN DOWN | 512 | 32 outputs × 16 inputs |

Q/K/V and Attention Output weights use tile-major layout:

```text
[layer][output_tile32][input_pack32][local_output]
```

FFN1 weights use:

```text
[layer][output_tile32][input_pack32][local_output]
```

FFN2 weights use:

```text
[layer][input_tile32][output_tile32][local_input]
```

Each FFN2 word contains 32 output weights for one local input.

## HLS, XO and budget report

Run from this directory:

```bash
make
```

The default target synthesizes and exports:

```text
bert_qk_persistent.xo
bert_v_persistent.xo
bert_attention_persistent.xo
bert_attention_out_persistent.xo
bert_ffn_up_persistent.xo
bert_ffn_down_persistent.xo
bert_feedback_relay.xo
bert_residual_relay.xo
```

After all reports exist, Tcl creates:

```text
build/hls/reports/bert_base_persistent_budget.txt
```

The report:

- reads actual csynth latency and resources for every top;
- estimates streamed QKV/Core/Output and FFN UP/DOWN overlap;
- checks the 25,000,000-cycle/100 ms limit at 250 MHz;
- aggregates resources according to the real SLR placement;
- applies 65% LUT/BRAM and 70% FF/URAM/DSP per-SLR routing guards.

The build stops if either latency or per-SLR budget fails. Set
`BERT_ENFORCE_BUDGET=0` only to inspect a failing report.

Final acceptance still requires full link with non-negative WNS and device
profiling because HLS cannot include stream stalls, DDR arbitration and host
scheduling.

Connectivity:

```text
link/bert_u250_persistent_4slr.cfg
link/vivado_route_balanced.cfg
```
