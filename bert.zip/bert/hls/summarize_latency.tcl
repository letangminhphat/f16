proc env_default {name default_value} {
    if {[info exists ::env($name)] && $::env($name) ne ""} {
        return $::env($name)
    }
    return $default_value
}

proc read_file {path} {
    set channel [open $path r]
    set data [read $channel]
    close $channel
    return $data
}

proc xml_value {xml tag} {
    set pattern [format {<%s>[[:space:]]*([^<]+)[[:space:]]*</%s>} \
                     $tag $tag]
    if {![regexp -nocase -- $pattern $xml -> value]} {
        return "N/A"
    }
    set value [string trim [string map {"," ""} $value]]
    if {![string is integer -strict $value] &&
        ![string is double -strict $value]} {
        return "N/A"
    }
    return $value
}

proc maximum {values} {
    set result [lindex $values 0]
    foreach value [lrange $values 1 end] {
        if {$value > $result} {
            set result $value
        }
    }
    return $result
}

proc metric_row {xml_path} {
    if {![file exists $xml_path]} {
        error "Missing csynth XML: $xml_path"
    }
    set xml [read_file $xml_path]
    set worst [xml_value $xml "Worst-caseLatency"]
    if {$worst eq "N/A"} {
        set worst [xml_value $xml "Best-caseLatency"]
    }
    return [dict create \
        cycles $worst \
        bram18 [xml_value $xml "BRAM_18K"] \
        dsp [xml_value $xml "DSP"] \
        ff [xml_value $xml "FF"] \
        lut [xml_value $xml "LUT"] \
        uram [xml_value $xml "URAM"]]
}

proc add_metrics {rows} {
    set result [dict create bram18 0 dsp 0 ff 0 lut 0 uram 0]
    foreach row $rows {
        foreach key {bram18 dsp ff lut uram} {
            set value [dict get $row $key]
            if {$value eq "N/A"} {
                error "Missing resource '$key' in csynth XML"
            }
            dict set result $key \
                [expr {[dict get $result $key] + $value}]
        }
    }
    return $result
}

proc utilization_pass {name used capacity limit output} {
    set percent [expr {100.0 * double($used) / double($capacity)}]
    set pass [expr {$percent <= $limit}]
    puts $output [format "  %-6s %10.1f / %-10.1f %7.2f%%  limit=%5.1f%%  %s" \
        $name $used $capacity $percent $limit \
        [expr {$pass ? "PASS" : "FAIL"}]]
    return $pass
}

set hls_dir [file dirname [file normalize [info script]]]
set root [file dirname $hls_dir]
set default_build [file normalize [file join $root build hls]]
set build_dir \
    [file normalize [env_default BERT_HLS_BUILD_DIR $default_build]]
set report_dir [file join $build_dir reports]
set period_value [env_default BERT_HLS_CLOCK_PERIOD_NS "4.0"]
set target_value [env_default BERT_TARGET_LATENCY_MS "100.0"]
set period_ns [expr {double($period_value)}]
set target_ms [expr {double($target_value)}]
set target_cycles [expr {$target_ms * 1.0e6 / $period_ns}]

set compute_tops [list \
    bert_qk_persistent \
    bert_v_persistent \
    bert_attention_persistent \
    bert_attention_out_persistent \
    bert_ffn_up_persistent \
    bert_ffn_down_persistent]
set all_tops [concat $compute_tops \
    [list bert_feedback_relay bert_residual_relay]]

array set metric {}
foreach top $all_tops {
    set metric($top) \
        [metric_row [file join $report_dir "${top}_csynth.xml"]]
}

foreach top $compute_tops {
    if {[dict get $metric($top) cycles] eq "N/A"} {
        error "No fixed latency estimate for $top"
    }
}

set qk_cycles [dict get $metric(bert_qk_persistent) cycles]
set v_cycles [dict get $metric(bert_v_persistent) cycles]
set core_cycles [dict get $metric(bert_attention_persistent) cycles]
set out_cycles [dict get $metric(bert_attention_out_persistent) cycles]
set up_cycles [dict get $metric(bert_ffn_up_persistent) cycles]
set down_cycles [dict get $metric(bert_ffn_down_persistent) cycles]

# The six head groups are streamed QK/V -> Core -> Output. The 96 FFN tiles
# are streamed UP -> DOWN. This is the same conservative stage-fill formula
# used by the validated FP32 persistent reference, scaled from the actual
# csynth top latencies of this Fixed16 implementation.
set qkv_group \
    [expr {double([maximum [list $qk_cycles $v_cycles]]) / (12.0 * 6.0)}]
set core_group [expr {double($core_cycles) / (12.0 * 6.0)}]
set out_group [expr {double($out_cycles) / (12.0 * 6.0)}]
set attention_group_limit \
    [maximum [list $qkv_group $core_group $out_group]]
set attention_cycles [expr {
    12.0 * ($qkv_group + $core_group + $out_group +
            5.0 * $attention_group_limit)}]

set up_tile [expr {double($up_cycles) / (12.0 * 96.0)}]
set down_tile [expr {double($down_cycles) / (12.0 * 96.0)}]
set ffn_tile_limit [maximum [list $up_tile $down_tile]]
set ffn_cycles [expr {
    12.0 * ($up_tile + $down_tile + 95.0 * $ffn_tile_limit)}]

set state_guard [expr {12.0 * 3072.0 + 11.0 * 3072.0}]
set estimated_cycles \
    [expr {$attention_cycles + $ffn_cycles + $state_guard}]
set estimated_ms [expr {$estimated_cycles * $period_ns / 1.0e6}]
set latency_pass [expr {$estimated_cycles <= $target_cycles}]

# A deliberately pessimistic bound with no overlap is also reported. It is
# diagnostic only; the linked graph intentionally overlaps streamed groups.
set no_overlap_cycles [expr {
    [maximum [list $qk_cycles $v_cycles]] +
    $core_cycles + $out_cycles +
    [maximum [list $up_cycles $down_cycles]] + $state_guard}]
set no_overlap_ms [expr {$no_overlap_cycles * $period_ns / 1.0e6}]

set feedback $metric(bert_feedback_relay)
set residual $metric(bert_residual_relay)
set slr0 [add_metrics [list $metric(bert_qk_persistent)]]
set slr1 [add_metrics [list \
    $metric(bert_v_persistent) \
    $metric(bert_attention_persistent) \
    $feedback $residual]]
set slr2 [add_metrics [list \
    $metric(bert_attention_out_persistent) \
    $metric(bert_ffn_up_persistent) \
    $feedback]]
set slr3 [add_metrics [list $metric(bert_ffn_down_persistent)]]

array set capacity {
    SLR0,lut 420000  SLR0,ff 840000  SLR0,bram 668
    SLR0,uram 312    SLR0,dsp 3032
    SLR1,lut 205000  SLR1,ff 411000  SLR1,bram 384
    SLR1,uram 128    SLR1,dsp 1536
    SLR2,lut 407000  SLR2,ff 815000  SLR2,bram 660
    SLR2,uram 308    SLR2,dsp 2994
    SLR3,lut 424000  SLR3,ff 849000  SLR3,bram 672
    SLR3,uram 320    SLR3,dsp 3072
}

set summary_path \
    [file join $report_dir bert_base_persistent_budget.txt]
set output [open $summary_path w]
puts $output "BERT-base Fixed16 persistent U250 budget"
puts $output "========================================"
puts $output "Geometry: 12 layers, seq=128, hidden=768, heads=12, FFN=3072"
puts $output "Clock target: $period_ns ns"
puts $output "Latency target: $target_ms ms / [format %.0f $target_cycles] cycles"
puts $output ""
puts $output [format "%-34s %14s %12s" "compute top" "worst cycles" "ms standalone"]
foreach top $compute_tops {
    set cycles [dict get $metric($top) cycles]
    puts $output [format "%-34s %14.0f %12.3f" \
        $top $cycles [expr {$cycles * $period_ns / 1.0e6}]]
}
puts $output ""
puts $output [format "Streamed attention estimate: %12.0f cycles" $attention_cycles]
puts $output [format "Streamed FFN estimate:       %12.0f cycles" $ffn_cycles]
puts $output [format "State/relay guard:           %12.0f cycles" $state_guard]
puts $output [format "Persistent model estimate:   %12.0f cycles = %.3f ms  %s" \
    $estimated_cycles $estimated_ms [expr {$latency_pass ? "PASS" : "FAIL"}]]
puts $output [format "No-overlap diagnostic bound: %12.0f cycles = %.3f ms" \
    $no_overlap_cycles $no_overlap_ms]
puts $output ""
puts $output "Projected per-SLR HLS resources"
puts $output "--------------------------------"

set resource_pass 1
foreach slr {SLR0 SLR1 SLR2 SLR3} row [list $slr0 $slr1 $slr2 $slr3] {
    puts $output "$slr"
    set check [utilization_pass \
        LUT [dict get $row lut] $capacity($slr,lut) 65.0 $output]
    set resource_pass [expr {$resource_pass && $check}]
    set check [utilization_pass \
        FF [dict get $row ff] $capacity($slr,ff) 70.0 $output]
    set resource_pass [expr {$resource_pass && $check}]
    set bram_tiles [expr {double([dict get $row bram18]) / 2.0}]
    set check [utilization_pass \
        BRAM $bram_tiles $capacity($slr,bram) 65.0 $output]
    set resource_pass [expr {$resource_pass && $check}]
    set check [utilization_pass \
        URAM [dict get $row uram] $capacity($slr,uram) 70.0 $output]
    set resource_pass [expr {$resource_pass && $check}]
    set check [utilization_pass \
        DSP [dict get $row dsp] $capacity($slr,dsp) 70.0 $output]
    set resource_pass [expr {$resource_pass && $check}]
}

puts $output ""
puts $output "Acceptance"
puts $output "----------"
puts $output "Latency <= target: [expr {$latency_pass ? "PASS" : "FAIL"}]"
puts $output "Per-SLR csynth budget: [expr {$resource_pass ? "PASS" : "FAIL"}]"
puts $output "OVERALL: [expr {$latency_pass && $resource_pass ? "PASS" : "FAIL"}]"
puts $output ""
puts $output "This estimate excludes host scheduling and post-link stream stalls."
puts $output "Final acceptance requires WNS >= 0 and XRT device profiling."
close $output

puts [read_file $summary_path]
puts "Budget report: $summary_path"

if {[env_default BERT_ENFORCE_BUDGET "1"] eq "1" &&
    (!$latency_pass || !$resource_pass)} {
    error "BERT persistent 100 ms / per-SLR budget failed"
}
