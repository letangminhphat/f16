set hls_dir [file dirname [file normalize [info script]]]
set project_root [file dirname $hls_dir]
source [file join $hls_dir persistent_common.tcl]
source [file join $project_root persistent source_sets.tcl]

foreach top $::bert_persistent_tops {
    bert_persistent_hls $top
}
source [file join $hls_dir summarize_latency.tcl]
