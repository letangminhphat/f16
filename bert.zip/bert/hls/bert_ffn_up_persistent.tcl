source [file join [file dirname [file normalize [info script]]] persistent_common.tcl]
bert_persistent_hls bert_ffn_up_persistent
