set ::bert_hls_dir [file dirname [file normalize [info script]]]

proc bert_env_default {name default_value} {
    if {[info exists ::env($name)] && $::env($name) ne ""} {
        return $::env($name)
    }
    return $default_value
}

proc bert_persistent_hls {top_name} {
    set hls_dir $::bert_hls_dir
    set project_root [file dirname $hls_dir]
    set persistent_root [file join $project_root persistent]
    set source_dir [file join $persistent_root src]
    set include_dir [file join $persistent_root include]
    source [file join $persistent_root source_sets.tcl]

    if {![info exists ::bert_source_for($top_name)]} {
        error "Unknown persistent BERT top: $top_name"
    }
    set source_path \
        [file normalize [file join $source_dir $::bert_source_for($top_name)]]
    if {![file exists $source_path]} {
        error "Missing source for $top_name: $source_path"
    }

    set part [bert_env_default BERT_HLS_PART "xcu250-figd2104-2L-e"]
    set period [bert_env_default BERT_HLS_CLOCK_PERIOD_NS "4.0"]
    set default_build [file normalize [file join $project_root build hls]]
    set build_dir \
        [file normalize [bert_env_default BERT_HLS_BUILD_DIR $default_build]]
    set project_dir [file join $build_dir projects $top_name]
    set xo_dir [file join $build_dir xo]
    set report_dir [file join $build_dir reports]
    set detail_dir [file join $report_dir details $top_name]

    file mkdir [file dirname $project_dir]
    file mkdir $xo_dir
    file mkdir $report_dir
    file delete -force $detail_dir
    file mkdir $detail_dir

    # Vitis HLS 2022.1 accepts a project name, not an absolute project path.
    set launch_dir [pwd]
    cd [file dirname $project_dir]
    open_project -reset [file tail $project_dir]
    set_top $top_name
    add_files -cflags "-std=c++14 -I$include_dir" $source_path
    open_solution -reset solution1 -flow_target vitis
    set_part $part
    create_clock -period $period -name default
    csynth_design

    set generated_dir [file join $project_dir solution1 syn report]
    set report_path [file join $generated_dir "${top_name}_csynth.rpt"]
    set xml_path [file join $generated_dir "${top_name}_csynth.xml"]
    if {![file exists $report_path]} {
        set report_path [file join $generated_dir csynth.rpt]
    }
    if {![file exists $xml_path]} {
        set xml_path [file join $generated_dir csynth.xml]
    }
    if {![file exists $report_path] || ![file exists $xml_path]} {
        error "Missing csynth report/XML for $top_name in $generated_dir"
    }

    file copy -force $report_path \
        [file join $report_dir "${top_name}_csynth.rpt"]
    file copy -force $xml_path \
        [file join $report_dir "${top_name}_csynth.xml"]
    foreach generated [glob -nocomplain [file join $generated_dir *]] {
        if {[file isfile $generated] && [file size $generated] > 0} {
            file copy -force $generated $detail_dir
        }
    }

    set xo_path [file join $xo_dir "${top_name}.xo"]
    export_design -rtl verilog -format xo -output $xo_path
    if {![file exists $xo_path]} {
        error "XO export failed for $top_name: $xo_path"
    }

    close_solution
    close_project
    cd $launch_dir
    puts "BERT persistent top: $top_name"
    puts "Target:              $part at $period ns"
    puts "XO:                  $xo_path"
}
