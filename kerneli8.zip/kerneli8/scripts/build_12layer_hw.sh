#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: bash scripts/build_12layer_hw.sh /path/to/u250_platform.xpfm" >&2
  exit 2
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

PLATFORM="$(readlink -f "$1")"
if [[ ! -f "$PLATFORM" ]]; then
  echo "Platform does not exist: $PLATFORM" >&2
  exit 2
fi
command -v v++ >/dev/null || {
  echo "v++ is not on PATH" >&2
  exit 2
}

BUILD_DIR="$ROOT_DIR/build/full_12layer_hw"
XO_DIR="$BUILD_DIR/xo"
REPORT_DIR="$ROOT_DIR/reports/full_12layer_hw"
LOG_DIR="$REPORT_DIR/logs"
LINK_MHZ="${LINK_MHZ:-300}"
HLS_HZ="${HLS_HZ:-$((LINK_MHZ * 1000000))}"
JOBS="${JOBS:-16}"
PREFLIGHT="${PREFLIGHT:-1}"
SKIP_COMPILE="${SKIP_COMPILE:-0}"

if [[ ! "$LINK_MHZ" =~ ^[0-9]+$ ]] || (( LINK_MHZ <= 0 )); then
  echo "LINK_MHZ must be a positive integer (current: $LINK_MHZ)" >&2
  exit 2
fi
if [[ ! "$HLS_HZ" =~ ^[0-9]+$ ]] || (( HLS_HZ <= 0 )); then
  echo "HLS_HZ must be a positive integer (current: $HLS_HZ)" >&2
  exit 2
fi
if [[ ! "$JOBS" =~ ^[0-9]+$ ]] || (( JOBS <= 0 )); then
  echo "JOBS must be a positive integer (current: $JOBS)" >&2
  exit 2
fi

mkdir -p "$XO_DIR" "$REPORT_DIR" "$LOG_DIR"

if [[ "$PREFLIGHT" == "1" ]]; then
  command -v vitis_hls >/dev/null || {
    echo "vitis_hls is required for the latency preflight" >&2
    exit 2
  }

  echo "============================================================"
  echo "Preflight: INT8 packing, accuracy and 50 ms latency gates"
  echo "============================================================"

  DATA_DIR="${BERT_INT8_DATA:-$ROOT_DIR/validation/data/bert_base_uncased_seq128_int8}"
  META="$DATA_DIR/metadata.json"
  ACCURACY="$ROOT_DIR/reports/csim/persistent_12layer/accuracy_report.md"

  if [[ ! -f "$META" ]] || \
     ! grep -Fq \
       '"format": "bert-u250-int8-integer-only-v2-tile64"' \
       "$META"; then
    echo "Missing optimized tile-64 INT8 metadata: $META" >&2
    echo "Run validation/export_hf_bert_int8.py with --force." >&2
    exit 2
  fi

  if [[ ! -f "$ACCURACY" ]] || \
     ! grep -Fq '**Overall: PASS**' "$ACCURACY"; then
    echo "Missing passing persistent INT8 accuracy report: $ACCURACY" >&2
    echo "Run: vitis_hls -f scripts/run_bert_int8_12layer_persistent_csim.tcl" >&2
    exit 2
  fi

  for dependency in \
      "$META" \
      "$ROOT_DIR/include/bert_int8_config.h" \
      "$ROOT_DIR/include/bert_int8_math.h" \
      "$ROOT_DIR/include/bert_int8_norm.h" \
      "$ROOT_DIR/kernels/bert_int8_qkv_kernels.cpp" \
      "$ROOT_DIR/kernels/bert_int8_attn_core_kernel.cpp" \
      "$ROOT_DIR/kernels/bert_int8_attn_out_norm_kernel.cpp" \
      "$ROOT_DIR/kernels/bert_int8_ffn_kernels.cpp" \
      "$ROOT_DIR/kernels/bert_int8_stream_relay_kernels.cpp" \
      "$ROOT_DIR/config/system_12layer_route_balanced.cfg" \
      "$ROOT_DIR/validation/tb_bert_int8_12layer_persistent_csim.cpp"; do
    if [[ "$dependency" -nt "$ACCURACY" ]]; then
      echo "Persistent INT8 accuracy report is stale: $dependency is newer." >&2
      echo "Run: vitis_hls -f scripts/run_bert_int8_12layer_persistent_csim.tcl" >&2
      exit 2
    fi
  done

  vitis_hls -f "$ROOT_DIR/scripts/check_int8_50ms_budget.tcl"
fi

compile_kernel() {
  local top="$1"
  local source="$2"

  echo "============================================================"
  echo "Compiling $top"
  echo "============================================================"

  v++ -c -t hw \
    --platform "$PLATFORM" \
    -k "$top" \
    --hls.clock "$HLS_HZ:$top" \
    --include "$ROOT_DIR/include" \
    --optimize 3 \
    --jobs "$JOBS" \
    --save-temps \
    --temp_dir "$BUILD_DIR/tmp_compile_$top" \
    --report_dir "$REPORT_DIR/compile_$top" \
    --log_dir "$LOG_DIR/compile_$top" \
    "$ROOT_DIR/kernels/$source" \
    -o "$XO_DIR/$top.xo"
}

if [[ "$SKIP_COMPILE" == "1" ]]; then
  for top in \
      bert_int8_qk_12layer_kernel \
      bert_int8_v_12layer_kernel \
      bert_int8_attn_core_12layer_kernel \
      bert_int8_attn_out_norm_12layer_kernel \
      bert_int8_ffn_up_gelu_12layer_kernel \
      bert_int8_ffn_down_norm_feedback_12layer_kernel \
      bert_int8_feedback_relay_kernel \
      bert_int8_residual_relay_kernel; do
    if [[ ! -f "$XO_DIR/$top.xo" ]]; then
      echo "Missing existing XO: $XO_DIR/$top.xo" >&2
      echo "Run: vitis_hls -f scripts/export_existing_int8_xo.tcl" >&2
      exit 2
    fi
  done
  echo "Using existing XO files in: $XO_DIR"
else
  compile_kernel \
    bert_int8_qk_12layer_kernel \
    bert_int8_qkv_kernels.cpp
  compile_kernel \
    bert_int8_v_12layer_kernel \
    bert_int8_qkv_kernels.cpp
  compile_kernel \
    bert_int8_attn_core_12layer_kernel \
    bert_int8_attn_core_kernel.cpp
  compile_kernel \
    bert_int8_attn_out_norm_12layer_kernel \
    bert_int8_attn_out_norm_kernel.cpp
  compile_kernel \
    bert_int8_ffn_up_gelu_12layer_kernel \
    bert_int8_ffn_kernels.cpp
  compile_kernel \
    bert_int8_ffn_down_norm_feedback_12layer_kernel \
    bert_int8_ffn_kernels.cpp
  compile_kernel \
    bert_int8_feedback_relay_kernel \
    bert_int8_stream_relay_kernels.cpp
  compile_kernel \
    bert_int8_residual_relay_kernel \
    bert_int8_stream_relay_kernels.cpp
fi

echo "============================================================"
echo "Linking persistent INT8 encoder at $LINK_MHZ MHz"
echo "============================================================"

export CONGESTION_OUT="$REPORT_DIR/link/congestion_debug"
v++ -l -t hw \
  --platform "$PLATFORM" \
  --kernel_frequency "$LINK_MHZ" \
  --config "$ROOT_DIR/config/system_12layer_route_balanced.cfg" \
  --config "$ROOT_DIR/config/vivado_route_balanced.cfg" \
  --jobs "$JOBS" \
  --save-temps \
  --temp_dir "$BUILD_DIR/tmp_link" \
  --report_dir "$REPORT_DIR/link" \
  --log_dir "$LOG_DIR/link" \
  "$XO_DIR/bert_int8_qk_12layer_kernel.xo" \
  "$XO_DIR/bert_int8_v_12layer_kernel.xo" \
  "$XO_DIR/bert_int8_attn_core_12layer_kernel.xo" \
  "$XO_DIR/bert_int8_attn_out_norm_12layer_kernel.xo" \
  "$XO_DIR/bert_int8_ffn_up_gelu_12layer_kernel.xo" \
  "$XO_DIR/bert_int8_ffn_down_norm_feedback_12layer_kernel.xo" \
  "$XO_DIR/bert_int8_feedback_relay_kernel.xo" \
  "$XO_DIR/bert_int8_residual_relay_kernel.xo" \
  -o "$BUILD_DIR/bert_int8_12layer_u250.xclbin"

echo "XCLBIN: $BUILD_DIR/bert_int8_12layer_u250.xclbin"
echo "Reports: $REPORT_DIR"
