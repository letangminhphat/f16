#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

DEFAULT_PLATFORM="/opt/xilinx/platforms/xilinx_u250_gen3x16_xdma_4_1_202210_1/xilinx_u250_gen3x16_xdma_4_1_202210_1.xpfm"
PLATFORM="${1:-$DEFAULT_PLATFORM}"
PLATFORM="$(readlink -f "$PLATFORM")"
LINK_MHZ="${LINK_MHZ:-275}"
JOBS="${JOBS:-16}"

XO_DIR="$ROOT_DIR/build/full_12layer_hw/xo"
BUILD_DIR="$ROOT_DIR/build/full_12layer_hw"
REPORT_DIR="$ROOT_DIR/reports/full_12layer_hw/link"
LOG_DIR="$ROOT_DIR/reports/full_12layer_hw/logs/link"
SYSTEM_CFG="$ROOT_DIR/config/system_12layer_route_balanced.cfg"
VIVADO_CFG="$ROOT_DIR/config/vivado_route_balanced.cfg"
XCLBIN="$BUILD_DIR/bert_int8_12layer_u250.xclbin"

if [[ ! -f "$PLATFORM" ]]; then
  echo "Missing U250 platform: $PLATFORM" >&2
  exit 2
fi
if [[ ! "$LINK_MHZ" =~ ^[0-9]+$ ]] || (( LINK_MHZ <= 0 )); then
  echo "LINK_MHZ must be a positive integer: $LINK_MHZ" >&2
  exit 2
fi
if [[ ! "$JOBS" =~ ^[0-9]+$ ]] || (( JOBS <= 0 )); then
  echo "JOBS must be a positive integer: $JOBS" >&2
  exit 2
fi
command -v v++ >/dev/null || {
  echo "v++ is not on PATH" >&2
  exit 2
}

TOPS=(
  bert_int8_qk_12layer_kernel
  bert_int8_v_12layer_kernel
  bert_int8_attn_core_12layer_kernel
  bert_int8_attn_out_norm_12layer_kernel
  bert_int8_ffn_up_gelu_12layer_kernel
  bert_int8_ffn_down_norm_feedback_12layer_kernel
  bert_int8_feedback_relay_kernel
  bert_int8_residual_relay_kernel
)

XO_FILES=()
for top in "${TOPS[@]}"; do
  xo="$XO_DIR/$top.xo"
  if [[ ! -f "$xo" ]]; then
    echo "Missing XO: $xo" >&2
    exit 2
  fi
  XO_FILES+=("$xo")
done

if [[ ! -f "$SYSTEM_CFG" ]]; then
  echo "Missing connectivity configuration: $SYSTEM_CFG" >&2
  exit 2
fi
if [[ ! -f "$VIVADO_CFG" ]]; then
  echo "Missing Vivado route configuration: $VIVADO_CFG" >&2
  exit 2
fi

mkdir -p "$BUILD_DIR" "$REPORT_DIR" "$LOG_DIR"
export CONGESTION_OUT="$REPORT_DIR/congestion_debug"

echo "============================================================"
echo "Linking INT8 U250 XCLBIN"
echo "Platform: $PLATFORM"
echo "Frequency: $LINK_MHZ MHz"
echo "XO directory: $XO_DIR"
echo "============================================================"

v++ -l -t hw \
  --platform "$PLATFORM" \
  --kernel_frequency "$LINK_MHZ" \
  --config "$SYSTEM_CFG" \
  --config "$VIVADO_CFG" \
  --jobs "$JOBS" \
  --save-temps \
  --temp_dir "$BUILD_DIR/tmp_link_${LINK_MHZ}mhz" \
  --report_dir "$REPORT_DIR" \
  --log_dir "$LOG_DIR" \
  "${XO_FILES[@]}" \
  -o "$XCLBIN"

echo "XCLBIN: $XCLBIN"
echo "Reports: $REPORT_DIR"
