set script_dir [file dirname [file normalize [info script]]]
set root_dir [file normalize [file join $script_dir ..]]

set hls_build_dir [file join $root_dir build hls]
if {[info exists ::env(INT8_HLS_BUILD)] &&
    $::env(INT8_HLS_BUILD) ne ""} {
    set hls_build_dir [file normalize $::env(INT8_HLS_BUILD)]
}

set xo_dir [file join $root_dir build full_12layer_hw xo]
if {[info exists ::env(INT8_XO_DIR)] &&
    $::env(INT8_XO_DIR) ne ""} {
    set xo_dir [file normalize $::env(INT8_XO_DIR)]
}
file mkdir $xo_dir

set tops [list \
    bert_int8_qk_12layer_kernel \
    bert_int8_v_12layer_kernel \
    bert_int8_attn_core_12layer_kernel \
    bert_int8_attn_out_norm_12layer_kernel \
    bert_int8_ffn_up_gelu_12layer_kernel \
    bert_int8_ffn_down_norm_feedback_12layer_kernel \
    bert_int8_feedback_relay_kernel \
    bert_int8_residual_relay_kernel]

set failed {}
set exported {}
set launch_dir [pwd]

if {![file isdirectory $hls_build_dir]} {
    error "Missing HLS build directory: $hls_build_dir"
}
cd $hls_build_dir

foreach top $tops {
    set project_name "proj_${top}"
    set project_dir [file join $hls_build_dir $project_name]
    set solution_dir [file join $project_dir solution1]
    set report_a [file join \
        $solution_dir syn report "${top}_csynth.rpt"]
    set report_b [file join \
        $solution_dir syn report csynth.rpt]
    set output [file join $xo_dir "${top}.xo"]

    puts "============================================================"
    puts "Exporting existing CSYNTH project: $top"
    puts "============================================================"

    if {![file isdirectory $project_dir]} {
        puts stderr "Missing HLS project: $project_dir"
        lappend failed $top
        continue
    }
    if {![file exists $report_a] &&
        ![file exists $report_b]} {
        puts stderr "Missing CSYNTH result: $solution_dir"
        lappend failed $top
        continue
    }

    catch {close_project}
    if {[catch {
        open_project $project_name
        open_solution solution1
        file delete -force $output
        export_design \
            -rtl verilog \
            -format xo \
            -output $output
    } message options]} {
        puts stderr "FAILED $top: $message"
        lappend failed $top
    } elseif {![file exists $output]} {
        puts stderr "FAILED $top: export produced no XO"
        lappend failed $top
    } else {
        puts "XO: $output"
        lappend exported $output
    }
    catch {close_project}
}

cd $launch_dir

if {[llength $failed] != 0} {
    error "INT8 XO export failed: [join $failed {, }]"
}

puts "============================================================"
puts "ALL INT8 XO EXPORTS PASSED"
puts "XO directory: $xo_dir"
puts "Exported [llength $exported] kernels"
puts "============================================================"
