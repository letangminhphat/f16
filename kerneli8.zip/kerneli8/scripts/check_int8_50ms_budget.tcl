if {![info exists root_dir]} {
    set script_dir [file dirname [file normalize [info script]]]
    set root_dir [file normalize [file join $script_dir ..]]
}
if {![info exists report_dir]} {
    set report_dir [file join $root_dir reports current]
}
if {![info exists clock_ns]} {
    set clock_ns 3.333
}

set latency_budget_ms 50.0
if {[info exists ::env(INT8_LATENCY_BUDGET_MS)] &&
    $::env(INT8_LATENCY_BUDGET_MS) ne ""} {
    set latency_budget_ms [expr {double($::env(INT8_LATENCY_BUDGET_MS))}]
}

proc int8_read_max_latency_cycles {path} {
    set handle [open $path r]
    set text [read $handle]
    close $handle
    set latency_section 0
    foreach line [split $text "\n"] {
        if {[string first "Latency (cycles)" $line] >= 0} {
            set latency_section 1
            continue
        }
        if {$latency_section &&
            [regexp {^\s*\|\s*([0-9]+)\s*\|\s*([0-9]+)\s*\|} \
                $line match minimum maximum]} {
            return [expr {wide($maximum)}]
        }
    }
    error "Cannot parse maximum latency from $path"
}

set controlled_tops [list \
    bert_int8_qk_12layer_kernel \
    bert_int8_v_12layer_kernel \
    bert_int8_attn_core_12layer_kernel \
    bert_int8_attn_out_norm_12layer_kernel \
    bert_int8_ffn_up_gelu_12layer_kernel \
    bert_int8_ffn_down_norm_feedback_12layer_kernel]

array set latency {}
foreach top $controlled_tops {
    set path [file join $report_dir "csynth_${top}.rpt"]
    if {![file exists $path]} {
        error "Missing CSYNTH report required by 50 ms gate: $path"
    }
    set latency($top) [int8_read_max_latency_cycles $path]
}

set qk_top [lindex $controlled_tops 0]
set v_top [lindex $controlled_tops 1]
set core_top [lindex $controlled_tops 2]
set out_top [lindex $controlled_tops 3]
set up_top [lindex $controlled_tops 4]
set down_top [lindex $controlled_tops 5]

# QK and V are independent producers. Core and output projection are kept
# serial here, even though their six head groups overlap in the linked graph.
set qkv_cycles [expr {
    max($latency($qk_top), $latency($v_top))
}]
set attention_cycles [expr {
    $qkv_cycles + $latency($core_top) + $latency($out_top)
}]
# UP emits tile-major words while DOWN consumes them, so the slower stage
# bounds the steady-state FFN.
set ffn_cycles [expr {
    max($latency($up_top), $latency($down_top))
}]
# Preserve the FP32 graph's conservative residual, feedback and transition
# serialization guards, scaled to twelve 512-bit INT8 words per token row.
set residual_guard [expr {12 * 1536}]
set feedback_guard [expr {11 * 1536}]
set transition_guard [expr {12 * 128}]
set serialization_guard [expr {
    $residual_guard + $feedback_guard + $transition_guard
}]

set graph_cycles [expr {
    $attention_cycles + $ffn_cycles + $serialization_guard
}]
set graph_ms [expr {$graph_cycles * $clock_ns / 1000000.0}]
set budget_cycles [expr {
    wide(floor($latency_budget_ms * 1000000.0 / $clock_ns))
}]

set summary_path [file join $report_dir latency_50ms_budget.tsv]
set summary [open $summary_path w]
puts $summary "kernel\tmax_latency_cycles\tlatency_ms"
foreach top $controlled_tops {
    puts $summary [format "%s\t%d\t%.6f" \
        $top $latency($top) \
        [expr {$latency($top) * $clock_ns / 1000000.0}]]
}
puts $summary [format "attention_pipeline\t%d\t%.6f" \
    $attention_cycles \
    [expr {$attention_cycles * $clock_ns / 1000000.0}]]
puts $summary [format "ffn_pipeline\t%d\t%.6f" \
    $ffn_cycles \
    [expr {$ffn_cycles * $clock_ns / 1000000.0}]]
puts $summary [format "serialization_guard\t%d\t%.6f" \
    $serialization_guard \
    [expr {$serialization_guard * $clock_ns / 1000000.0}]]
puts $summary [format "persistent_graph\t%d\t%.6f" \
    $graph_cycles $graph_ms]
puts $summary [format "budget\t%d\t%.6f" \
    $budget_cycles $latency_budget_ms]
close $summary

if {$graph_cycles > $budget_cycles} {
    error [format \
        "INT8 persistent graph misses %.3f ms budget: %.3f ms" \
        $latency_budget_ms $graph_ms]
}
puts [format "INT8 50 MS LATENCY GATE PASSED: %.3f ms" $graph_ms]
