set script_dir [file dirname [file normalize [info script]]]
set root_dir [file normalize [file join $script_dir ..]]
set build_dir [file join $root_dir build hls]
set project_name proj_bert_int8_12layer_persistent_csim
set data_dir [file join $root_dir validation data bert_base_uncased_seq128_int8]
set output_dir [file join $root_dir validation outputs persistent_12layer]
set report_dir [file join $root_dir reports csim persistent_12layer]

if {[info exists ::env(BERT_INT8_DATA)] && $::env(BERT_INT8_DATA) ne ""} {
    set data_dir [file normalize $::env(BERT_INT8_DATA)]
}
if {[info exists ::env(BERT_INT8_OUTPUT)] && $::env(BERT_INT8_OUTPUT) ne ""} {
    set output_dir [file normalize $::env(BERT_INT8_OUTPUT)]
}
if {![file exists [file join $data_dir metadata.json]]} {
    error "Missing INT8 data. Run validation/export_hf_bert_int8.py first."
}
file delete -force $output_dir
file mkdir $output_dir
file mkdir $report_dir
file mkdir $build_dir

set cflags "-std=c++14 -O2 -pthread -DBERT_INT8_CSIM_THREAD_SAFE_STREAM -I[file join $root_dir include] -I[file join $root_dir validation]"
set old_dir [pwd]
cd $build_dir
open_project -reset $project_name
add_files -cflags $cflags [file join $root_dir kernels bert_int8_qkv_kernels.cpp]
add_files -cflags $cflags [file join $root_dir kernels bert_int8_attn_core_kernel.cpp]
add_files -cflags $cflags [file join $root_dir kernels bert_int8_attn_out_norm_kernel.cpp]
add_files -cflags $cflags [file join $root_dir kernels bert_int8_ffn_kernels.cpp]
add_files -cflags $cflags [file join $root_dir kernels bert_int8_stream_relay_kernels.cpp]
add_files -tb -cflags $cflags \
    [file join $root_dir validation tb_bert_int8_12layer_persistent_csim.cpp]
set_top bert_int8_qk_12layer_kernel
open_solution -reset solution1 -flow_target vivado
set_part xcu250-figd2104-2L-e
create_clock -period 3.333 -name default
csim_design -O -clean -ldflags "-pthread" \
    -argv [join [list $data_dir $output_dir] " "]
close_project
cd $old_dir

set python_bin python3
if {[info exists ::env(PYTHON_BIN)] && $::env(PYTHON_BIN) ne ""} {
    set python_bin $::env(PYTHON_BIN)
}
set command [list \
    $python_bin [file join $root_dir validation verify_hf_int8_accuracy.py] \
    --data-dir $data_dir \
    --output-dir $output_dir \
    --report-dir $report_dir \
    --mode persistent]
if {[catch {exec {*}$command 2>@1} result]} {
    puts stderr $result
    error "INT8 persistent accuracy gate failed"
}
puts $result
