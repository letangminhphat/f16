# Vitis/Vivado post-place hook. The design is already open when this file is
# sourced, so no project or checkpoint discovery is required.
if {[info exists ::env(CONGESTION_OUT)] &&
    $::env(CONGESTION_OUT) ne ""} {
    set out_dir [file normalize $::env(CONGESTION_OUT)]
} else {
    set out_dir [file normalize \
        [file join [pwd] post_place_congestion]]
}
file mkdir $out_dir

puts "Saving post-place congestion diagnostics in $out_dir"
if {[catch {
    report_design_analysis -congestion \
        -file [file join $out_dir congestion_post_place.rpt]
} message]} {
    puts "WARNING: post-place congestion report failed: $message"
}
if {[catch {
    report_utilization -slr \
        -file [file join $out_dir slr_utilization_post_place.rpt]
} message]} {
    puts "WARNING: post-place SLR utilization report failed: $message"
}
if {[catch {
    report_utilization -hierarchical \
        -file [file join $out_dir hierarchical_utilization_post_place.rpt]
} message]} {
    puts "WARNING: hierarchical utilization report failed: $message"
}
if {[catch {
    report_timing_summary -delay_type max -max_paths 50 \
        -file [file join $out_dir timing_post_place.rpt]
} message]} {
    puts "WARNING: post-place timing report failed: $message"
}
if {[catch {
    report_methodology \
        -file [file join $out_dir methodology_post_place.rpt]
} message]} {
    puts "WARNING: post-place methodology report failed: $message"
}
if {[catch {
    write_checkpoint -force \
        [file join $out_dir post_place.dcp]
} message]} {
    puts "WARNING: post-place checkpoint write failed: $message"
}
