set script_dir [file dirname [file normalize [info script]]]
set root_dir [file normalize [file join $script_dir ..]]
set build_dir [file join $root_dir build hls]
set report_dir [file join $root_dir reports current]
set xo_dir [file join $root_dir build full_12layer_hw xo]
file mkdir $build_dir
file mkdir $report_dir
file mkdir $xo_dir

set part_name "xcu250-figd2104-2L-e"
if {[info exists ::env(HLS_PART)] && $::env(HLS_PART) ne ""} {
    set part_name $::env(HLS_PART)
}
set clock_ns 3.333
if {[info exists ::env(HLS_CLOCK_NS)] && $::env(HLS_CLOCK_NS) ne ""} {
    set clock_ns [expr {double($::env(HLS_CLOCK_NS))}]
}

array set source_for {
    bert_int8_qkv_kernel bert_int8_qkv_kernels.cpp
    bert_int8_attn_core_kernel bert_int8_attn_core_kernel.cpp
    bert_int8_attn_out_norm_residual_kernel bert_int8_attn_out_norm_kernel.cpp
    bert_int8_ffn_up_gelu_kernel bert_int8_ffn_kernels.cpp
    bert_int8_ffn_down_residual_norm_kernel bert_int8_ffn_kernels.cpp
    bert_int8_qk_12layer_kernel bert_int8_qkv_kernels.cpp
    bert_int8_v_12layer_kernel bert_int8_qkv_kernels.cpp
    bert_int8_attn_core_12layer_kernel bert_int8_attn_core_kernel.cpp
    bert_int8_attn_out_norm_12layer_kernel bert_int8_attn_out_norm_kernel.cpp
    bert_int8_ffn_up_gelu_12layer_kernel bert_int8_ffn_kernels.cpp
    bert_int8_ffn_down_norm_feedback_12layer_kernel bert_int8_ffn_kernels.cpp
    bert_int8_feedback_relay_kernel bert_int8_stream_relay_kernels.cpp
    bert_int8_residual_relay_kernel bert_int8_stream_relay_kernels.cpp
}

set one_layer [list \
    bert_int8_qkv_kernel \
    bert_int8_attn_core_kernel \
    bert_int8_attn_out_norm_residual_kernel \
    bert_int8_ffn_up_gelu_kernel \
    bert_int8_ffn_down_residual_norm_kernel]
set full [list \
    bert_int8_qk_12layer_kernel \
    bert_int8_v_12layer_kernel \
    bert_int8_attn_core_12layer_kernel \
    bert_int8_attn_out_norm_12layer_kernel \
    bert_int8_ffn_up_gelu_12layer_kernel \
    bert_int8_ffn_down_norm_feedback_12layer_kernel \
    bert_int8_feedback_relay_kernel \
    bert_int8_residual_relay_kernel]

set selected {}
if {[info exists ::env(INT8_KERNELS)] && $::env(INT8_KERNELS) ne ""} {
    set requested [split $::env(INT8_KERNELS) ","]
} else {
    set requested [list full]
}
foreach item $requested {
    set item [string trim $item]
    if {$item eq "full"} {
        set selected $full
        break
    } elseif {$item eq "one"} {
        set selected $one_layer
        break
    } elseif {[info exists source_for($item)]} {
        lappend selected $item
    } elseif {$item ne ""} {
        error "Unknown INT8 kernel: $item"
    }
}

set failed {}
foreach top $selected {
    set project_name "proj_${top}"
    set destination [file join $report_dir "csynth_${top}.rpt"]
    set xo_destination [file join $xo_dir "${top}.xo"]
    file delete -force $destination
    file delete -force $xo_destination
    set old_dir [pwd]
    if {[catch {
        cd $build_dir
        open_project -reset $project_name
        add_files -cflags "-std=c++14 -I[file join $root_dir include]" \
            [file join $root_dir kernels $source_for($top)]
        set_top $top
        open_solution -reset solution1 -flow_target vitis
        set_part $part_name
        create_clock -period $clock_ns -name default
        config_export -format xo
        csynth_design
        set source [file join $build_dir $project_name solution1 syn report "${top}_csynth.rpt"]
        if {![file exists $source]} {
            set source [file join $build_dir $project_name solution1 syn report csynth.rpt]
        }
        file copy -force $source $destination
        export_design \
            -rtl verilog \
            -format xo \
            -output $xo_destination
        if {![file exists $xo_destination]} {
            error "XO export produced no file: $xo_destination"
        }
    } message options]} {
        puts stderr "FAILED $top: $message"
        lappend failed $top
    }
    catch {close_project}
    cd $old_dir
}
if {[llength $failed] != 0} {
    error "INT8 CSYNTH failed: [join $failed {, }]"
}
set full_gate_ready 1
foreach top [lrange $full 0 5] {
    if {[lsearch -exact $selected $top] < 0} {
        set full_gate_ready 0
    }
}
if {$full_gate_ready} {
    source [file join $script_dir check_int8_50ms_budget.tcl]
}
puts "ALL INT8 CSYNTH/XO TOPS PASSED"
puts "XO directory: $xo_dir"
