#ifndef BERT_MODEL_U250_300MHZ_H
#define BERT_MODEL_U250_300MHZ_H

#include <ap_int.h>
#include <hls_math.h>
#include <hls_stream.h>
#include <stdint.h>

typedef ap_uint<512> bus_t;
typedef hls::stream<bus_t> hidden_stream_t;

// BERT-Base, sequence length <= 128.
static const int NUM_LAYERS       = 12;
static const int MAX_SEQ_LEN      = 128;
static const int HIDDEN           = 768;
static const int NUM_HEADS        = 12;
static const int HEAD_DIM         = 64;
static const int FFN_DIM          = 3072;

static const int PACK_SIZE        = 16;
static const int PACKS            = HIDDEN / PACK_SIZE;
static const int FFN_PACKS        = FFN_DIM / PACK_SIZE;
static const int MAX_TOKEN_WORDS  = MAX_SEQ_LEN * PACKS;
static const int MAX_FFN_WORDS    = MAX_SEQ_LEN * FFN_PACKS;

// Timing-oriented parallelism.  The inner MAC loops are the only pipelined
// loops; no pipeline pragma is placed on a loop which still contains another
// variable-latency loop.
static const int HEAD_PAR              = 2;
static const int HEAD_GROUPS           = NUM_HEADS / HEAD_PAR;
static const int GROUP_DIM             = HEAD_PAR * HEAD_DIM;

static const int QKV_TILE_O            = 64;
static const int QKV_TILE_K            = 32;
static const int QKV_OUT_PAR           = 8;
static const int QKV_IN_PAR            = 16;

// Routeable 120 ms profile. Two heads run in parallel on the small SLR1;
// score/context consume 32 dimensions per cycle and O projection uses three
// FP32 dot engines with direct accumulation into the output buffer.
static const int SCORE_D_PAR            = 32;
static const int CONTEXT_D_PAR          = 32;
static const int SOFTMAX_REDUCE_BANKS  = 16;
static const int CONTEXT_ACC_BANKS     = 16;
static const int ATTN_BUFFER_FACTOR    = PACK_SIZE;
static const int DENSE_TILE_O          = 32;
static const int DENSE_TILE_K          = 32;
static const int DENSE_OUT_PAR         = 3;
static const int DENSE_IN_PAR          = 32;
static const int CONTEXT_STORAGE_FACTOR = PACK_SIZE;

// FFN Up and Down each use 32 dot engines and overlap through AXI stream.
// The external weight layout remains the legacy 64 x 32 tile size.
static const int FFN_WEIGHT_TILE_OUT   = 64;
static const int FFN_TILE_OUT          = 64;
static const int FFN_TILE_K            = 32;
static const int FFN_MAC_GROUP         = 32;
static const int FFN_K_PAR             = 16;
static const int GELU_PAR              = 16;

// Per-layer packed footprints.  Tiling changes ordering, not byte count.
static const int ATTN_W_FLOATS         = HIDDEN * HIDDEN;
static const int ATTN_B_FLOATS         = HIDDEN;
static const int ATTN_W_PACKS          = ATTN_W_FLOATS / PACK_SIZE;
static const int ATTN_B_PACKS          = ATTN_B_FLOATS / PACK_SIZE;

static const int FFN_UP_W_FLOATS       = HIDDEN * FFN_DIM;
static const int FFN_UP_B_FLOATS       = FFN_DIM;
static const int FFN_DN_W_FLOATS       = FFN_DIM * HIDDEN;
static const int FFN_DN_B_FLOATS       = HIDDEN;
static const int FFN_UP_W_PACKS        = FFN_UP_W_FLOATS / PACK_SIZE;
static const int FFN_UP_B_PACKS        = FFN_UP_B_FLOATS / PACK_SIZE;
static const int FFN_DN_W_PACKS        = FFN_DN_W_FLOATS / PACK_SIZE;
static const int FFN_DN_B_PACKS        = FFN_DN_B_FLOATS / PACK_SIZE;

static_assert(HIDDEN == NUM_HEADS * HEAD_DIM, "invalid BERT dimensions");
static_assert((NUM_HEADS % HEAD_PAR) == 0, "HEAD_PAR must divide NUM_HEADS");
static_assert((HIDDEN % PACK_SIZE) == 0, "hidden pack alignment");
static_assert((FFN_DIM % PACK_SIZE) == 0, "ffn pack alignment");
static_assert((GROUP_DIM % QKV_TILE_O) == 0, "group/qkv tile mismatch");
static_assert((QKV_TILE_K % QKV_IN_PAR) == 0, "qkv input parallelism");
static_assert((QKV_TILE_O % QKV_OUT_PAR) == 0, "qkv output parallelism");
static_assert((HEAD_DIM % SCORE_D_PAR) == 0, "score parallelism");
static_assert((HEAD_DIM % CONTEXT_D_PAR) == 0, "context parallelism");
static_assert((DENSE_TILE_K % DENSE_IN_PAR) == 0, "dense input parallelism");
static_assert(DENSE_OUT_PAR > 0 && DENSE_OUT_PAR <= DENSE_TILE_O,
              "dense output parallelism");
static_assert((FFN_DIM % FFN_TILE_OUT) == 0, "ffn up output tiling");
static_assert((HIDDEN % FFN_TILE_OUT) == 0, "ffn down output tiling");
static_assert((FFN_TILE_OUT % PACK_SIZE) == 0, "ffn output pack alignment");
static_assert((FFN_WEIGHT_TILE_OUT % PACK_SIZE) == 0, "ffn weight tile alignment");
static_assert((FFN_TILE_K % FFN_K_PAR) == 0, "ffn input parallelism");
static_assert((FFN_TILE_OUT % FFN_MAC_GROUP) == 0, "ffn output parallelism");
static_assert((PACK_SIZE % GELU_PAR) == 0, "gelu lane alignment");
static_assert((SOFTMAX_REDUCE_BANKS & (SOFTMAX_REDUCE_BANKS - 1)) == 0,
              "softmax banks must be a power of two");
static_assert((CONTEXT_ACC_BANKS & (CONTEXT_ACC_BANKS - 1)) == 0,
              "context banks must be a power of two");

static inline int sanitize_seq_len(int seq_len) {
#pragma HLS INLINE
    if (seq_len < 1) return 1;
    if (seq_len > MAX_SEQ_LEN) return MAX_SEQ_LEN;
    return seq_len;
}

static inline int sanitize_layer(int layer) {
#pragma HLS INLINE
    if (layer < 0) return 0;
    if (layer >= NUM_LAYERS) return NUM_LAYERS - 1;
    return layer;
}

static inline uint32_t float_to_uint32(float x) {
#pragma HLS INLINE
    union { float f; uint32_t u; } cvt;
    cvt.f = x;
    return cvt.u;
}

static inline float uint32_to_float(uint32_t x) {
#pragma HLS INLINE
    union { float f; uint32_t u; } cvt;
    cvt.u = x;
    return cvt.f;
}

static inline void unpack_bus16(const bus_t &word, float lane[PACK_SIZE]) {
#pragma HLS INLINE
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
UNPACK_BUS:
    for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
        lane[i] = uint32_to_float((uint32_t)word.range(i * 32 + 31, i * 32));
    }
}

static inline bus_t pack_bus16(const float lane[PACK_SIZE]) {
#pragma HLS INLINE
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
    bus_t word = 0;
PACK_BUS:
    for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
        word.range(i * 32 + 31, i * 32) = float_to_uint32(lane[i]);
    }
    return word;
}

// Packed tile layout used by the original project:
// [out_tile][in_tile][out_lane][in_pack], where one in_pack is 16 FP32 values.
static inline int tiled_matrix_word_index(
    int out_base,
    int in_base,
    int out_lane,
    int in_pack,
    int in_dim,
    int tile_out,
    int tile_in)
{
#pragma HLS INLINE
    const int in_tiles = in_dim / tile_in;
    const int tile_words = tile_out * (tile_in / PACK_SIZE);
    const int tile_index = (out_base / tile_out) * in_tiles + (in_base / tile_in);
    return tile_index * tile_words + out_lane * (tile_in / PACK_SIZE) + in_pack;
}

static inline float reduce4(const float x[4]) {
#pragma HLS INLINE
    return (x[0] + x[1]) + (x[2] + x[3]);
}

static inline float reduce8(const float x[8]) {
#pragma HLS INLINE
    float a[4];
#pragma HLS ARRAY_PARTITION variable=a complete dim=1
    for (int i = 0; i < 4; ++i) {
#pragma HLS UNROLL
        a[i] = x[2 * i] + x[2 * i + 1];
    }
    return (a[0] + a[1]) + (a[2] + a[3]);
}

static inline float reduce16(const float x[16]) {
#pragma HLS INLINE
    float a[8];
    float b[4];
#pragma HLS ARRAY_PARTITION variable=a complete dim=1
#pragma HLS ARRAY_PARTITION variable=b complete dim=1
    for (int i = 0; i < 8; ++i) {
#pragma HLS UNROLL
        a[i] = x[2 * i] + x[2 * i + 1];
    }
    for (int i = 0; i < 4; ++i) {
#pragma HLS UNROLL
        b[i] = a[2 * i] + a[2 * i + 1];
    }
    return (b[0] + b[1]) + (b[2] + b[3]);
}

static inline float reduce32(const float x[32]) {
#pragma HLS INLINE
    float a[16];
#pragma HLS ARRAY_PARTITION variable=a complete dim=1
    for (int i = 0; i < 16; ++i) {
#pragma HLS UNROLL
        a[i] = x[2 * i] + x[2 * i + 1];
    }
    return reduce16(a);
}

// Route-friendly FP32 dot product. Explicit DSP bindings and pipeline margins
// avoid the larger generic reduction implementation selected by Vitis 2022.1.
static float dot16_300mhz(const float lhs[16], const float rhs[16]) {
#pragma HLS INLINE off
#pragma HLS PIPELINE II=1
#pragma HLS ARRAY_PARTITION variable=lhs complete dim=1
#pragma HLS ARRAY_PARTITION variable=rhs complete dim=1
    float p[16];
    float s8[8];
    float s4[4];
    float s2[2];
    float sum;
#pragma HLS ARRAY_PARTITION variable=p complete dim=1
#pragma HLS ARRAY_PARTITION variable=s8 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s4 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s2 complete dim=1
#pragma HLS BIND_OP variable=p op=fmul impl=fulldsp latency=7
#pragma HLS BIND_OP variable=s8 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=s4 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=s2 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=sum op=fadd impl=fulldsp latency=6
DOT16_MUL:
    for (int i = 0; i < 16; ++i) {
#pragma HLS UNROLL
        p[i] = lhs[i] * rhs[i];
    }
DOT16_L1:
    for (int i = 0; i < 8; ++i) {
#pragma HLS UNROLL
        s8[i] = p[2 * i] + p[2 * i + 1];
    }
DOT16_L2:
    for (int i = 0; i < 4; ++i) {
#pragma HLS UNROLL
        s4[i] = s8[2 * i] + s8[2 * i + 1];
    }
DOT16_L3:
    for (int i = 0; i < 2; ++i) {
#pragma HLS UNROLL
        s2[i] = s4[2 * i] + s4[2 * i + 1];
    }
    sum = s2[0] + s2[1];
    return sum;
}

static float dot32_300mhz(const float lhs[32], const float rhs[32]) {
#pragma HLS INLINE
#pragma HLS ARRAY_PARTITION variable=lhs complete dim=1
#pragma HLS ARRAY_PARTITION variable=rhs complete dim=1
    float p[32];
    float s16[16];
    float s8[8];
    float s4[4];
    float s2[2];
    float sum;
#pragma HLS ARRAY_PARTITION variable=p complete dim=1
#pragma HLS ARRAY_PARTITION variable=s16 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s8 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s4 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s2 complete dim=1
#pragma HLS BIND_OP variable=p op=fmul impl=fulldsp latency=7
#pragma HLS BIND_OP variable=s16 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=s8 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=s4 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=s2 op=fadd impl=fulldsp latency=6
#pragma HLS BIND_OP variable=sum op=fadd impl=fulldsp latency=6
DOT32_MUL:
    for (int i = 0; i < 32; ++i) {
#pragma HLS UNROLL
        p[i] = lhs[i] * rhs[i];
    }
DOT32_L1:
    for (int i = 0; i < 16; ++i) {
#pragma HLS UNROLL
        s16[i] = p[2 * i] + p[2 * i + 1];
    }
DOT32_L2:
    for (int i = 0; i < 8; ++i) {
#pragma HLS UNROLL
        s8[i] = s16[2 * i] + s16[2 * i + 1];
    }
DOT32_L3:
    for (int i = 0; i < 4; ++i) {
#pragma HLS UNROLL
        s4[i] = s8[2 * i] + s8[2 * i + 1];
    }
DOT32_L4:
    for (int i = 0; i < 2; ++i) {
#pragma HLS UNROLL
        s2[i] = s4[2 * i] + s4[2 * i + 1];
    }
    sum = s2[0] + s2[1];
    return sum;
}

#endif
