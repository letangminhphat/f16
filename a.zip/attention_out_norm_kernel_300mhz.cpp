#include "bert_model_300mhz.h"
#include "layernorm_utils_300mhz.h"
#include <cfloat>

static const float ATTN_SCALE = 0.125f;

static inline float reduce_max16_300mhz(const float x[16]) {
#pragma HLS INLINE
    float s8[8];
    float s4[4];
    float s2[2];
#pragma HLS ARRAY_PARTITION variable=s8 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s4 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s2 complete dim=1
    for (int i = 0; i < 8; ++i) {
#pragma HLS UNROLL
        s8[i] = hls::fmaxf(x[2 * i], x[2 * i + 1]);
    }
    for (int i = 0; i < 4; ++i) {
#pragma HLS UNROLL
        s4[i] = hls::fmaxf(s8[2 * i], s8[2 * i + 1]);
    }
    for (int i = 0; i < 2; ++i) {
#pragma HLS UNROLL
        s2[i] = hls::fmaxf(s4[2 * i], s4[2 * i + 1]);
    }
    return hls::fmaxf(s2[0], s2[1]);
}

static int load_active_indices(
    const int *attention_mask,
    int seq_len,
    int active_indices[MAX_SEQ_LEN])
{
#pragma HLS INLINE off
    int active_count = 0;
LOAD_MASK:
    for (int i = 0; i < seq_len; ++i) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        if (attention_mask[i] != 0) {
            active_indices[active_count] = i;
            ++active_count;
        }
    }
    return active_count;
}

static void load_qkv_group(
    const bus_t *q_in,
    const bus_t *k_in,
    const bus_t *v_in,
    int head_group,
    int seq_len,
    float q_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    float k_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    float v_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM])
{
#pragma HLS INLINE off
    const int pack_base = (head_group * GROUP_DIM) / PACK_SIZE;
LOAD_QKV_HEADS:
    for (int h = 0; h < HEAD_PAR; ++h) {
        for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            for (int p = 0; p < HEAD_DIM / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
                float q_lane[PACK_SIZE];
                float k_lane[PACK_SIZE];
                float v_lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=q_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=v_lane complete dim=1
                const int src = s * PACKS + pack_base
                              + h * (HEAD_DIM / PACK_SIZE) + p;
                unpack_bus16(q_in[src], q_lane);
                unpack_bus16(k_in[src], k_lane);
                unpack_bus16(v_in[src], v_lane);
                for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                    const int dim = p * PACK_SIZE + i;
                    q_group[h][s][dim] = q_lane[i];
                    k_group[h][s][dim] = k_lane[i];
                    v_group[h][s][dim] = v_lane[i];
                }
            }
        }
    }
}

static void compute_scores_head_chunked(
    float q_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    float k_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    const int active_indices[MAX_SEQ_LEN],
    int active_count,
    int head,
    int query,
    float score_buf[MAX_SEQ_LEN])
{
#pragma HLS INLINE
#pragma HLS ARRAY_PARTITION variable=q_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=q_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=k_group cyclic factor=ATTN_BUFFER_FACTOR dim=3

    float partial[MAX_SEQ_LEN];
#pragma HLS BIND_STORAGE variable=partial type=RAM_2P impl=BRAM
SCORE_PHASES:
    for (int phase = 0; phase < HEAD_DIM / SCORE_D_PAR; ++phase) {
    SCORE_KEYS:
        for (int n = 0; n < active_count; ++n) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=0 max=128
            const int key = active_indices[n];
            float q_vec[SCORE_D_PAR];
            float k_vec[SCORE_D_PAR];
#pragma HLS ARRAY_PARTITION variable=q_vec complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_vec complete dim=1
            for (int d = 0; d < SCORE_D_PAR; ++d) {
#pragma HLS UNROLL
                q_vec[d] = q_group[head][query][phase * SCORE_D_PAR + d];
                k_vec[d] = k_group[head][key][phase * SCORE_D_PAR + d];
            }
            const float chunk = dot32_300mhz(q_vec, k_vec);
            if (phase == 0) {
                partial[n] = chunk;
            } else {
                score_buf[n] = (partial[n] + chunk) * ATTN_SCALE;
            }
        }
    }
}

static float softmax_scores(
    float score_buf[MAX_SEQ_LEN],
    int active_count,
    float prob_buf[MAX_SEQ_LEN])
{
#pragma HLS INLINE
    float max_banks[SOFTMAX_REDUCE_BANKS];
    float sum_banks[SOFTMAX_REDUCE_BANKS];
#pragma HLS ARRAY_PARTITION variable=max_banks complete dim=1
#pragma HLS ARRAY_PARTITION variable=sum_banks complete dim=1
#pragma HLS DEPENDENCE variable=max_banks inter false
#pragma HLS DEPENDENCE variable=sum_banks inter false

    for (int b = 0; b < SOFTMAX_REDUCE_BANKS; ++b) {
#pragma HLS UNROLL
        max_banks[b] = -FLT_MAX;
        sum_banks[b] = 0.0f;
    }

SOFTMAX_MAX:
    for (int n = 0; n < active_count; ++n) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=0 max=128
        const int bank = n & (SOFTMAX_REDUCE_BANKS - 1);
        max_banks[bank] = hls::fmaxf(max_banks[bank], score_buf[n]);
    }

    const float max_score = reduce_max16_300mhz(max_banks);

SOFTMAX_EXP:
    for (int n = 0; n < active_count; ++n) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=0 max=128
        const float e = hls::expf(score_buf[n] - max_score);
        const int bank = n & (SOFTMAX_REDUCE_BANKS - 1);
        prob_buf[n] = e;
        sum_banks[bank] += e;
    }

    float sum_lane[SOFTMAX_REDUCE_BANKS];
#pragma HLS ARRAY_PARTITION variable=sum_lane complete dim=1
    for (int b = 0; b < SOFTMAX_REDUCE_BANKS; ++b) {
#pragma HLS UNROLL
        sum_lane[b] = sum_banks[b];
    }
    const float sum = reduce16(sum_lane);
    const float inv_sum = sum > 0.0f ? 1.0f / sum : 0.0f;
    return inv_sum;
}

static void apply_context_head_chunked(
    float prob_buf[MAX_SEQ_LEN],
    const int active_indices[MAX_SEQ_LEN],
    int active_count,
    float v_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    int head,
    int query,
    float inv_sum,
    float context_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM])
{
#pragma HLS INLINE
#pragma HLS ARRAY_PARTITION variable=v_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=context_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=v_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=context_group cyclic factor=CONTEXT_STORAGE_FACTOR dim=3

CONTEXT_DIM_CHUNKS:
    for (int db = 0; db < HEAD_DIM; db += CONTEXT_D_PAR) {
        float acc[CONTEXT_ACC_BANKS][CONTEXT_D_PAR];
#pragma HLS ARRAY_PARTITION variable=acc complete dim=1
#pragma HLS ARRAY_PARTITION variable=acc complete dim=2
#pragma HLS DEPENDENCE variable=acc inter false

        for (int b = 0; b < CONTEXT_ACC_BANKS; ++b) {
#pragma HLS UNROLL
            for (int d = 0; d < CONTEXT_D_PAR; ++d) {
#pragma HLS UNROLL
                acc[b][d] = 0.0f;
            }
        }

    CONTEXT_KEYS:
        for (int n = 0; n < active_count; ++n) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=0 max=128
            const int key = active_indices[n];
            const int bank = n & (CONTEXT_ACC_BANKS - 1);
            const float p = prob_buf[n];
            for (int d = 0; d < CONTEXT_D_PAR; ++d) {
#pragma HLS UNROLL
                acc[bank][d] += p * v_group[head][key][db + d];
            }
        }

    WRITE_CONTEXT_CHUNK:
        for (int d = 0; d < CONTEXT_D_PAR; ++d) {
#pragma HLS PIPELINE II=1
            float lane[CONTEXT_ACC_BANKS];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
            for (int b = 0; b < CONTEXT_ACC_BANKS; ++b) {
#pragma HLS UNROLL
                lane[b] = acc[b][d];
            }
            context_group[head][query][db + d] = reduce16(lane) * inv_sum;
        }
    }
}

static void attention_group(
    float q_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    float k_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    float v_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    const int active_indices[MAX_SEQ_LEN],
    int active_count,
    int seq_len,
    float context_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM])
{
#pragma HLS INLINE off
#pragma HLS ARRAY_PARTITION variable=q_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=v_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=context_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=q_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=k_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=v_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=context_group cyclic factor=CONTEXT_STORAGE_FACTOR dim=3

    float score_buf[HEAD_PAR][MAX_SEQ_LEN];
    float prob_buf[HEAD_PAR][MAX_SEQ_LEN];
#pragma HLS ARRAY_PARTITION variable=score_buf complete dim=1
#pragma HLS ARRAY_PARTITION variable=prob_buf complete dim=1
#pragma HLS BIND_STORAGE variable=score_buf type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=prob_buf type=RAM_2P impl=BRAM

HEADS:
    for (int h = 0; h < HEAD_PAR; ++h) {
#pragma HLS UNROLL
    QUERIES:
        for (int q = 0; q < seq_len; ++q) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            compute_scores_head_chunked(
                q_group, k_group, active_indices, active_count, h, q, score_buf[h]);
            const float inv_sum =
                softmax_scores(score_buf[h], active_count, prob_buf[h]);
            apply_context_head_chunked(
                prob_buf[h], active_indices, active_count,
                v_group, h, q, inv_sum, context_group);
        }
    }
}

static void init_dense_output(
    const bus_t *dense_b,
    int seq_len,
    float output_buf[MAX_SEQ_LEN][HIDDEN])
{
#pragma HLS INLINE off
    bus_t bias_cache[PACKS];
#pragma HLS BIND_STORAGE variable=bias_cache type=RAM_2P impl=BRAM
LOAD_DENSE_BIAS:
    for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
        bias_cache[p] = dense_b[p];
    }
INIT_DENSE_OUTPUT:
    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
            unpack_bus16(bias_cache[p], lane);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                output_buf[s][p * PACK_SIZE + i] = lane[i];
            }
        }
    }
}

static void load_dense_weight_tile(
    const bus_t *dense_w,
    int out_base,
    int in_base,
    bus_t weight[DENSE_TILE_O][DENSE_TILE_K / PACK_SIZE])
{
#pragma HLS INLINE off
    const int tile_base = tiled_matrix_word_index(
        out_base, in_base, 0, 0, HIDDEN, DENSE_TILE_O, DENSE_TILE_K);
LOAD_DENSE_WEIGHT:
    for (int oo = 0; oo < DENSE_TILE_O; ++oo) {
        for (int p = 0; p < DENSE_TILE_K / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
            weight[oo][p] =
                dense_w[tile_base + oo * (DENSE_TILE_K / PACK_SIZE) + p];
        }
    }
}

static void project_dense_group(
    float context_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM],
    const bus_t *dense_w,
    int head_group,
    int seq_len,
    float output_buf[MAX_SEQ_LEN][HIDDEN])
{
#pragma HLS INLINE off
#pragma HLS ARRAY_PARTITION variable=context_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=context_group cyclic factor=CONTEXT_STORAGE_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=output_buf cyclic factor=PACK_SIZE dim=2

    bus_t weight[DENSE_TILE_O][DENSE_TILE_K / PACK_SIZE];
#pragma HLS BIND_STORAGE variable=weight type=RAM_2P impl=BRAM
#pragma HLS ARRAY_PARTITION variable=weight cyclic factor=DENSE_OUT_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=weight complete dim=2
#pragma HLS DEPENDENCE variable=output_buf inter false

    const int group_base = head_group * GROUP_DIM;

OUTPUT_TILES:
    for (int ob = 0; ob < HIDDEN; ob += DENSE_TILE_O) {
    INPUT_TILES:
        for (int ib = 0; ib < GROUP_DIM; ib += DENSE_TILE_K) {
            load_dense_weight_tile(dense_w, ob, group_base + ib, weight);

        K_CHUNKS:
            for (int ii = 0; ii < DENSE_TILE_K; ii += DENSE_IN_PAR) {
            TOKENS:
                for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
                OUTPUT_GROUPS:
                    for (int oo = 0; oo < DENSE_TILE_O; oo += DENSE_OUT_PAR) {
#pragma HLS PIPELINE II=1
                        float x[DENSE_IN_PAR];
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
                        for (int d = 0; d < DENSE_IN_PAR; ++d) {
#pragma HLS UNROLL
                            const int flat = ib + ii + d;
                            const int head = flat / HEAD_DIM;
                            const int dim = flat - head * HEAD_DIM;
                            x[d] = context_group[head][s][dim];
                        }
                        for (int j = 0; j < DENSE_OUT_PAR; ++j) {
#pragma HLS UNROLL
                            const int out_lane = oo + j;
                            if (out_lane < DENSE_TILE_O) {
                                float w[DENSE_IN_PAR];
#pragma HLS ARRAY_PARTITION variable=w complete dim=1
                                float w0[PACK_SIZE], w1[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=w0 complete dim=1
#pragma HLS ARRAY_PARTITION variable=w1 complete dim=1
                                unpack_bus16(weight[out_lane][0], w0);
                                unpack_bus16(weight[out_lane][1], w1);
                                for (int d = 0; d < PACK_SIZE; ++d) {
#pragma HLS UNROLL
                                    w[d] = w0[d];
                                    w[d + PACK_SIZE] = w1[d];
                                }
                                output_buf[s][ob + out_lane] +=
                                    dot32_300mhz(x, w);
                            }
                        }
                    }
                }
            }
        }
    }
}

static void fused_residual_layernorm_write(
    const bus_t *residual,
    float sublayer[MAX_SEQ_LEN][HIDDEN],
    const bus_t *gamma,
    const bus_t *beta,
    int seq_len,
    bus_t *output)
{
#pragma HLS INLINE off
    bus_t gamma_cache[PACKS];
    bus_t beta_cache[PACKS];
    bus_t local_x[PACKS];
#pragma HLS BIND_STORAGE variable=gamma_cache type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=beta_cache type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=local_x type=RAM_2P impl=BRAM
#pragma HLS ARRAY_PARTITION variable=sublayer cyclic factor=PACK_SIZE dim=2

LOAD_NORM_PARAMS:
    for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
        gamma_cache[p] = gamma[p];
        beta_cache[p] = beta[p];
    }

TOKEN_NORM:
    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        float sum_banks[LN_REDUCE_BANKS];
        float sumsq_banks[LN_REDUCE_BANKS];
#pragma HLS ARRAY_PARTITION variable=sum_banks complete dim=1
#pragma HLS ARRAY_PARTITION variable=sumsq_banks complete dim=1
#pragma HLS DEPENDENCE variable=sum_banks inter false
#pragma HLS DEPENDENCE variable=sumsq_banks inter false
        for (int b = 0; b < LN_REDUCE_BANKS; ++b) {
#pragma HLS UNROLL
            sum_banks[b] = 0.0f;
            sumsq_banks[b] = 0.0f;
        }

    ADD_ACCUMULATE:
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float r[PACK_SIZE];
            float x[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=r complete dim=1
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
            unpack_bus16(residual[s * PACKS + p], r);
            const int bank_group = p & (LN_REDUCE_GROUPS - 1);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                const float v = r[i] + sublayer[s][p * PACK_SIZE + i];
                const int bank = bank_group * PACK_SIZE + i;
                x[i] = v;
                sum_banks[bank] += v;
                sumsq_banks[bank] += v * v;
            }
            local_x[p] = pack_bus16(x);
        }

        float mean;
        float inv_stddev;
        layernorm_statistics_300mhz(sum_banks, sumsq_banks, mean, inv_stddev);

    NORMALIZE_WRITE:
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float x[PACK_SIZE];
            float g[PACK_SIZE];
            float b[PACK_SIZE];
            float y[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
#pragma HLS ARRAY_PARTITION variable=g complete dim=1
#pragma HLS ARRAY_PARTITION variable=b complete dim=1
#pragma HLS ARRAY_PARTITION variable=y complete dim=1
            unpack_bus16(local_x[p], x);
            unpack_bus16(gamma_cache[p], g);
            unpack_bus16(beta_cache[p], b);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                y[i] = g[i] * ((x[i] - mean) * inv_stddev) + b[i];
            }
            output[s * PACKS + p] = pack_bus16(y);
        }
    }
}

extern "C" {
void bert_attention_out_norm_kernel(
    const bus_t *residual_hidden,
    const bus_t *q_in,
    const bus_t *k_in,
    const bus_t *v_in,
    const int *attention_mask,
    const bus_t *o_w_all,
    const bus_t *o_b_all,
    const bus_t *norm_gamma_all,
    const bus_t *norm_beta_all,
    int layer_index,
    int valid_seq_len,
    bus_t *output_hidden)
{
#pragma HLS INLINE off
#pragma HLS INTERFACE m_axi port=residual_hidden offset=slave bundle=gmem_residual depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=output_hidden offset=slave bundle=gmem_output depth=6144 max_write_burst_length=64 num_write_outstanding=16
#pragma HLS INTERFACE m_axi port=attention_mask offset=slave bundle=gmem_mask depth=128 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=q_in offset=slave bundle=gmem_qin depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=k_in offset=slave bundle=gmem_kin depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=v_in offset=slave bundle=gmem_vin depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=o_w_all offset=slave bundle=gmem_o depth=442368 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=o_b_all offset=slave bundle=gmem_o depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=norm_gamma_all offset=slave bundle=gmem_o depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=norm_beta_all offset=slave bundle=gmem_o depth=576 max_read_burst_length=128 num_read_outstanding=32

#pragma HLS INTERFACE s_axilite port=residual_hidden
#pragma HLS INTERFACE s_axilite port=q_in
#pragma HLS INTERFACE s_axilite port=k_in
#pragma HLS INTERFACE s_axilite port=v_in
#pragma HLS INTERFACE s_axilite port=attention_mask
#pragma HLS INTERFACE s_axilite port=o_w_all
#pragma HLS INTERFACE s_axilite port=o_b_all
#pragma HLS INTERFACE s_axilite port=norm_gamma_all
#pragma HLS INTERFACE s_axilite port=norm_beta_all
#pragma HLS INTERFACE s_axilite port=layer_index
#pragma HLS INTERFACE s_axilite port=valid_seq_len
#pragma HLS INTERFACE s_axilite port=output_hidden
#pragma HLS INTERFACE s_axilite port=return

    const int seq_len = sanitize_seq_len(valid_seq_len);
    const int layer = sanitize_layer(layer_index);
    const int w_off = layer * ATTN_W_PACKS;
    const int b_off = layer * ATTN_B_PACKS;
    const int norm_off = layer * PACKS;

    static float q_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM];
    static float k_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM];
    static float v_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM];
    static float context_group[HEAD_PAR][MAX_SEQ_LEN][HEAD_DIM];
    static float output_buf[MAX_SEQ_LEN][HIDDEN];
    int active_indices[MAX_SEQ_LEN];
#pragma HLS BIND_STORAGE variable=q_group type=RAM_2P impl=BRAM latency=2
#pragma HLS BIND_STORAGE variable=k_group type=RAM_2P impl=BRAM latency=2
#pragma HLS BIND_STORAGE variable=v_group type=RAM_2P impl=BRAM latency=2
#pragma HLS BIND_STORAGE variable=context_group type=RAM_2P impl=BRAM latency=2
#pragma HLS BIND_STORAGE variable=output_buf type=RAM_2P impl=URAM latency=3
#pragma HLS BIND_STORAGE variable=active_indices type=RAM_S2P impl=LUTRAM
#pragma HLS ARRAY_PARTITION variable=q_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=v_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=context_group complete dim=1
#pragma HLS ARRAY_PARTITION variable=q_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=k_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=v_group cyclic factor=ATTN_BUFFER_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=context_group cyclic factor=CONTEXT_STORAGE_FACTOR dim=3
#pragma HLS ARRAY_PARTITION variable=output_buf cyclic factor=PACK_SIZE dim=2

    const int active_count = load_active_indices(attention_mask, seq_len, active_indices);
    init_dense_output(o_b_all + b_off, seq_len, output_buf);

HEAD_GROUPS_LOOP:
    for (int hg = 0; hg < HEAD_GROUPS; ++hg) {
        load_qkv_group(q_in, k_in, v_in, hg, seq_len, q_group, k_group, v_group);
        attention_group(
            q_group, k_group, v_group,
            active_indices, active_count, seq_len, context_group);
        project_dense_group(context_group, o_w_all + w_off, hg, seq_len, output_buf);
    }

    fused_residual_layernorm_write(
        residual_hidden, output_buf,
        norm_gamma_all + norm_off,
        norm_beta_all + norm_off,
        seq_len, output_hidden);
}
}
