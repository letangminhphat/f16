# Cycle budget at sequence length 128

This is a structural estimate assuming the marked MAC/load loops achieve II=1.
The post-synthesis and post-route reports remain the source of truth.

| Stage | Approx. cycles per layer |
|---|---:|
| QKV projection, 8 outputs x 16 inputs x Q/K/V | 0.66 M |
| Scores, softmax, context, O projection, first AddNorm | 1.00 M |
| FFN up, 32 outputs x 16 inputs, 4-lane GELU | 0.89 M |
| FFN down, 32 outputs x 16 inputs, second AddNorm | 0.79 M |
| **Total per encoder layer** | **3.34 M** |
| **12 encoder layers** | **40.1 M** |
| **Compute time at 300 MHz** | **about 133.7 ms** |

The remaining approximately 16.3 ms before the 150 ms limit is reserved for
AXI stalls, kernel launch overhead, pipeline fill/drain and embedding.
