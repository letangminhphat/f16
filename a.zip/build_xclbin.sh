#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${ROOT}/build_vitis"
TARGET="${TARGET:-hw}"
CLOCK_MHZ="${BERT_CLOCK_MHZ:-300}"
PLATFORM="${PLATFORM:-/opt/xilinx/platforms/xilinx_u250_gen3x16_xdma_4_1_202210_1/xilinx_u250_gen3x16_xdma_4_1_202210_1.xpfm}"

mkdir -p "${BUILD_DIR}"

if [[ ! -f "${PLATFORM}" ]]; then
    echo "Platform not found: ${PLATFORM}" >&2
    echo "Set PLATFORM=/absolute/path/to/*.xpfm" >&2
    exit 1
fi

compile_kernel() {
    local kernel="$1"
    local source="$2"
    v++ -c -t "${TARGET}" \
        --platform "${PLATFORM}" \
        --kernel_frequency "${CLOCK_MHZ}" \
        -k "${kernel}" \
        -I"${ROOT}" \
        --save-temps \
        -o "${BUILD_DIR}/${kernel}.xo" \
        "${ROOT}/${source}"
}

compile_kernel bert_qkv_kernel qkv_kernel_300mhz.cpp
compile_kernel bert_attention_out_norm_kernel attention_out_norm_kernel_300mhz.cpp
compile_kernel bert_ffn_up_kernel ffn_up_kernel_300mhz.cpp
compile_kernel bert_ffn_down_norm_kernel ffn_down_norm_kernel_300mhz.cpp

v++ -l -t "${TARGET}" \
    --platform "${PLATFORM}" \
    --kernel_frequency "${CLOCK_MHZ}" \
    --config "${ROOT}/link_u250_300mhz.cfg" \
    --save-temps \
    -o "${BUILD_DIR}/bert_base_split_u250_300mhz.xclbin" \
    "${BUILD_DIR}/bert_qkv_kernel.xo" \
    "${BUILD_DIR}/bert_attention_out_norm_kernel.xo" \
    "${BUILD_DIR}/bert_ffn_up_kernel.xo" \
    "${BUILD_DIR}/bert_ffn_down_norm_kernel.xo"

echo "Generated: ${BUILD_DIR}/bert_base_split_u250_300mhz.xclbin"
