# BERT-Base U250 split-kernel implementation for 300 MHz

This directory is a replacement architecture for the original monolithic
`bert_base_top`.  It targets BERT-Base, sequence length up to 128, FP32 packed as
16 values per 512-bit word.

## Why the top was split

The original top instantiated Attention, two AddNorm blocks and both FFN
projections in one compute unit.  Large fully-unrolled FP32 reductions and two
wide FFN engines therefore competed for placement and routing inside one design.
The new version places one timing-critical engine in each SLR and fuses each
residual + LayerNorm into its producer/consumer kernel.

## Kernels

1. `bert_embedding_kernel`
2. `bert_qkv_kernel`
3. `bert_attention_out_norm_kernel`
4. `bert_ffn_up_kernel`
5. `bert_ffn_down_norm_kernel`

For every encoder layer, enqueue kernels 2 -> 3 -> 4 -> 5.  The supplied OpenCL
fragment uses `hidden_a` and `hidden_b` as ping-pong buffers.

## Main timing changes

- QKV: 8 output lanes x 16 input lanes, with Q/K/V evaluated together.
- Attention score/context: 16 dimensions per cycle and four heads in parallel.
- O projection: 8 output lanes x 32 input lanes.
- FFN: 32 output lanes x 16 input lanes in separate Up and Down kernels.
- GELU: four `tanhf` lanes instead of sixteen.
- LayerNorm: eight recurrence groups instead of four.
- QKV, O and FFN weight tiles remain packed as 512-bit words; the code no longer
  partitions a complete tile into hundreds of scalar RAM banks.
- HLS automatic loop pipelining is disabled by `config_compile -pipeline_loops 1`.
  Only explicitly selected load/MAC loops are pipelined.

## Weight compatibility

The existing tiled weight order is retained:

- Q/K/V: tile 64 outputs x 32 inputs.
- O projection: tile 32 outputs x 32 inputs.
- FFN Up and Down: tile 64 outputs x 32 inputs.

Therefore existing packed weight files generated for those tile dimensions can
be reused.  Q, K, V and hidden/intermediate activations use normal token-major
packed order.

## Required device buffers at sequence length 128

| Buffer | 512-bit words | Bytes |
|---|---:|---:|
| `hidden_a` | 6,144 | 393,216 |
| `hidden_b` | 6,144 | 393,216 |
| `q_buf` | 6,144 | 393,216 |
| `k_buf` | 6,144 | 393,216 |
| `v_buf` | 6,144 | 393,216 |
| `intermediate` | 24,576 | 1,572,864 |

Allocate buffers in banks compatible with `link_u250_300mhz.cfg`.  In particular,
all ports sharing `hidden_a` or `hidden_b` must remain connected to DDR3.

## HLS synthesis

```bash
source /home/s23521141_truongnh/Xilinx/Vitis/2022.1/settings64.sh
cd bert_u250_300mhz_v9
vitis_hls -f csynth_split_300mhz.tcl
```

The HLS solution uses a 3.333 ns clock and 0.250 ns uncertainty.  Check every
report for:

- achieved II=1 on the labeled MAC loops;
- no memory-port-limited II;
- estimated clock below 3.333 ns;
- resource use that fits the assigned SLR.

## Build the xclbin

```bash
source /home/s23521141_truongnh/Xilinx/Vitis/2022.1/settings64.sh
export PLATFORM=/opt/xilinx/platforms/xilinx_u250_gen3x16_xdma_4_1_202210_1/xilinx_u250_gen3x16_xdma_4_1_202210_1.xpfm
./build_xclbin.sh
```

The output is:

```text
build_vitis/bert_base_split_u250_300mhz.xclbin
```

## Host execution order

```text
embedding -> hidden_a

for layer = 0..11:
    qkv(hidden_a) -> q_buf, k_buf, v_buf
    attention + O + AddNorm(hidden_a, q/k/v) -> hidden_b
    ffn_up + GELU(hidden_b) -> intermediate
    ffn_down + AddNorm(hidden_b, intermediate) -> hidden_a

final output = hidden_a
```

See `host_schedule_opencl_snippet.cpp` for argument order and event dependencies.

## Expected latency

The structural budget is approximately 40.1 million cycles for 12 layers,
about 133.7 ms at 300 MHz before runtime overhead.  See `CYCLE_BUDGET.md`.
This is a design target, not a post-route guarantee.  Acceptance still requires:
- post-route WNS >= 0 ns at 300 MHz;
- measured end-to-end latency <= 150 ms;
- numerical comparison against the original FP32 implementation.

## Validation status

All kernel source files were checked for C++ syntax using local stubs for
`ap_uint`, `hls::stream` and `hls_math`. Two software C-simulation smoke tests
also passed under AddressSanitizer/UndefinedBehaviorSanitizer:

- an all-zero end-to-end pass through all five kernels;
- a two-token nonzero residual test comparing both fused LayerNorm outputs
  against a software reference (maximum absolute error below 2.4e-7).

Vitis HLS and Vivado implementation were not available in the generation
environment, so C synthesis, RTL co-simulation and post-route timing must still
be run on the Vitis 2022.1 server.
