#include "bert_model_300mhz.h"

// Symmetric 16-segment PWL approximation of the tanh-based BERT GELU.
// Maximum absolute interpolation error on [-4, 4] is about 6.2e-3.
static inline float gelu_pwl_300mhz(float x) {
#pragma HLS INLINE
    const float a = x < 0.0f ? -x : x;
    if (a >= 4.0f) return x < 0.0f ? 0.0f : x;

    float m, b;
    if (a < 2.0f) {
        if (a < 1.0f) {
            if (a < 0.5f) {
                if (a < 0.25f) { m = 0.5987014028f; b = 0.0f; }
                else           { m = 0.7841546365f; b = -0.0463633084f; }
            } else {
                if (a < 0.75f) { m = 0.9369861814f; b = -0.1227790809f; }
                else           { m = 1.0449257418f; b = -0.2037337512f; }
            }
        } else {
            if (a < 1.5f) {
                if (a < 1.25f) { m = 1.1060888494f; b = -0.2648968588f; }
                else           { m = 1.1274294960f; b = -0.2915726671f; }
            } else {
                if (a < 1.75f) { m = 1.1208952214f; b = -0.2817712552f; }
                else           { m = 1.0992092470f; b = -0.2438207999f; }
            }
        }
    } else {
        if (a < 3.0f) {
            if (a < 2.5f) {
                if (a < 2.25f) { m = 1.0728039041f; b = -0.1910101140f; }
                else           { m = 1.0484682552f; b = -0.1362549042f; }
            } else {
                if (a < 2.75f) { m = 1.0294444881f; b = -0.0886954863f; }
                else           { m = 1.0163430080f; b = -0.0526664160f; }
            }
        } else {
            if (a < 3.5f) {
                if (a < 3.25f) { m = 1.0082750597f; b = -0.0284625713f; }
                else           { m = 1.0038097180f; b = -0.0139502105f; }
            } else {
                if (a < 3.75f) { m = 1.0015877823f; b = -0.0061734358f; }
                else           { m = 1.0005960245f; b = -0.0024543439f; }
            }
        }
    }
    const float positive = m * a + b;
    return x < 0.0f ? positive - a : positive;
}

static void load_hidden_for_ffn(
    const bus_t *input_hidden,
    int seq_len,
    float input_buf[MAX_SEQ_LEN][HIDDEN])
{
#pragma HLS INLINE off
LOAD_FFN_INPUT:
    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
            unpack_bus16(input_hidden[s * PACKS + p], lane);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                input_buf[s][p * PACK_SIZE + i] = lane[i];
            }
        }
    }
}

static void load_ffn_weight_tile_packed(
    const bus_t *weights,
    int out_base,
    int in_base,
    int in_dim,
    bus_t weight_tile[FFN_TILE_OUT][FFN_TILE_K / PACK_SIZE])
{
#pragma HLS INLINE off
LOAD_FFN_TILE:
    for (int oo = 0; oo < FFN_TILE_OUT; ++oo) {
        for (int p = 0; p < FFN_TILE_K / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
            const int global_out = out_base + oo;
            const int weight_out_base =
                (global_out / FFN_WEIGHT_TILE_OUT) * FFN_WEIGHT_TILE_OUT;
            const int weight_out_lane = global_out % FFN_WEIGHT_TILE_OUT;
            const int word = tiled_matrix_word_index(
                weight_out_base, in_base, weight_out_lane, p,
                in_dim, FFN_WEIGHT_TILE_OUT, FFN_TILE_K);
            weight_tile[oo][p] = weights[word];
        }
    }
}

static void compute_up_projection_to_stream(
    float input_buf[MAX_SEQ_LEN][HIDDEN],
    const bus_t *weights,
    const bus_t *bias,
    int seq_len,
    hidden_stream_t &intermediate_out)
{
#pragma HLS INLINE off
#pragma HLS ARRAY_RESHAPE variable=input_buf cyclic factor=FFN_K_PAR dim=2

    bus_t weight_tile[FFN_TILE_OUT][FFN_TILE_K / PACK_SIZE];
    float acc[MAX_SEQ_LEN][FFN_TILE_OUT];
#pragma HLS BIND_STORAGE variable=weight_tile type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=acc type=RAM_2P impl=BRAM
#pragma HLS ARRAY_PARTITION variable=weight_tile cyclic factor=FFN_MAC_GROUP dim=1
#pragma HLS ARRAY_PARTITION variable=acc cyclic factor=FFN_MAC_GROUP dim=2
#pragma HLS DEPENDENCE variable=acc inter false

UP_OUTPUT_TILES:
    for (int out_base = 0; out_base < FFN_DIM; out_base += FFN_TILE_OUT) {
        bus_t bias_cache[FFN_TILE_OUT / PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=bias_cache complete dim=1
    LOAD_UP_BIAS:
        for (int p = 0; p < FFN_TILE_OUT / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
            bias_cache[p] = bias[out_base / PACK_SIZE + p];
        }

    INIT_UP_ACC:
        for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            for (int p = 0; p < FFN_TILE_OUT / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
                float lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
                unpack_bus16(bias_cache[p], lane);
                for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                    acc[s][p * PACK_SIZE + i] = lane[i];
                }
            }
        }

    UP_INPUT_TILES:
        for (int in_base = 0; in_base < HIDDEN; in_base += FFN_TILE_K) {
            load_ffn_weight_tile_packed(
                weights, out_base, in_base, HIDDEN, weight_tile);

        UP_K_PACKS:
            for (int kp = 0; kp < FFN_TILE_K / FFN_K_PAR; ++kp) {
            UP_TOKENS:
                for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
                UP_OUTPUT_GROUPS:
                    for (int j = 0; j < FFN_TILE_OUT; j += FFN_MAC_GROUP) {
#pragma HLS PIPELINE II=1
                        float x[FFN_K_PAR];
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
                        for (int d = 0; d < FFN_K_PAR; ++d) {
#pragma HLS UNROLL
                            x[d] = input_buf[s][in_base + kp * FFN_K_PAR + d];
                        }

                        for (int jj = 0; jj < FFN_MAC_GROUP; ++jj) {
#pragma HLS UNROLL
                            float w_lane[FFN_K_PAR];
#pragma HLS ARRAY_PARTITION variable=w_lane complete dim=1
                            unpack_bus16(weight_tile[j + jj][kp], w_lane);
                            acc[s][j + jj] += dot16_300mhz(x, w_lane);
                        }
                    }
                }
            }
        }

    GELU_AND_WRITE:
        for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            for (int p = 0; p < FFN_TILE_OUT / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
                float lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
            GELU_LANES:
                for (int d = 0; d < PACK_SIZE; ++d) {
#pragma HLS UNROLL
                    lane[d] = gelu_pwl_300mhz(acc[s][p * PACK_SIZE + d]);
                }
                intermediate_out.write(pack_bus16(lane));
            }
        }
    }
}

extern "C" {
void bert_ffn_up_kernel(
    const bus_t *input_hidden,
    const bus_t *up_w_all,
    const bus_t *up_b_all,
    int layer_index,
    int valid_seq_len,
    hidden_stream_t &intermediate_out)
{
#pragma HLS INLINE off
#pragma HLS INTERFACE m_axi port=input_hidden offset=slave bundle=gmem_hidden depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=up_w_all offset=slave bundle=gmem_up depth=1769472 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=up_b_all offset=slave bundle=gmem_up depth=2304 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE axis port=intermediate_out

#pragma HLS INTERFACE s_axilite port=input_hidden
#pragma HLS INTERFACE s_axilite port=up_w_all
#pragma HLS INTERFACE s_axilite port=up_b_all
#pragma HLS INTERFACE s_axilite port=layer_index
#pragma HLS INTERFACE s_axilite port=valid_seq_len
#pragma HLS INTERFACE s_axilite port=return

    const int seq_len = sanitize_seq_len(valid_seq_len);
    const int layer = sanitize_layer(layer_index);
    const int w_off = layer * FFN_UP_W_PACKS;
    const int b_off = layer * FFN_UP_B_PACKS;

    static float input_buf[MAX_SEQ_LEN][HIDDEN];
#pragma HLS BIND_STORAGE variable=input_buf type=RAM_2P impl=URAM latency=3
#pragma HLS ARRAY_RESHAPE variable=input_buf cyclic factor=FFN_K_PAR dim=2

    load_hidden_for_ffn(input_hidden, seq_len, input_buf);
    compute_up_projection_to_stream(
        input_buf, up_w_all + w_off, up_b_all + b_off,
        seq_len, intermediate_out);
}
}
