#include "bert_model_300mhz.h"

static void load_hidden_matrix(
    const bus_t *input_hidden,
    int seq_len,
    float input_buf[MAX_SEQ_LEN][HIDDEN])
{
#pragma HLS INLINE off
LOAD_HIDDEN:
    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
            unpack_bus16(input_hidden[s * PACKS + p], lane);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                input_buf[s][p * PACK_SIZE + i] = lane[i];
            }
        }
    }
}

static void load_qkv_bias_tile(
    const bus_t *q_b,
    const bus_t *k_b,
    const bus_t *v_b,
    int out_base,
    float q_bias[QKV_TILE_O],
    float k_bias[QKV_TILE_O],
    float v_bias[QKV_TILE_O])
{
#pragma HLS INLINE off
#pragma HLS ARRAY_PARTITION variable=q_bias cyclic factor=QKV_OUT_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=k_bias cyclic factor=QKV_OUT_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=v_bias cyclic factor=QKV_OUT_PAR dim=1
LOAD_QKV_BIAS:
    for (int p = 0; p < QKV_TILE_O / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
        float q_lane[PACK_SIZE];
        float k_lane[PACK_SIZE];
        float v_lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=q_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=v_lane complete dim=1
        const int word = out_base / PACK_SIZE + p;
        unpack_bus16(q_b[word], q_lane);
        unpack_bus16(k_b[word], k_lane);
        unpack_bus16(v_b[word], v_lane);
        for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
            q_bias[p * PACK_SIZE + i] = q_lane[i];
            k_bias[p * PACK_SIZE + i] = k_lane[i];
            v_bias[p * PACK_SIZE + i] = v_lane[i];
        }
    }
}

static void load_qkv_weight_tile(
    const bus_t *q_w,
    const bus_t *k_w,
    const bus_t *v_w,
    int out_base,
    int in_base,
    bus_t wq[QKV_TILE_O][QKV_TILE_K / PACK_SIZE],
    bus_t wk[QKV_TILE_O][QKV_TILE_K / PACK_SIZE],
    bus_t wv[QKV_TILE_O][QKV_TILE_K / PACK_SIZE])
{
#pragma HLS INLINE off
    const int tile_base = tiled_matrix_word_index(
        out_base, in_base, 0, 0, HIDDEN, QKV_TILE_O, QKV_TILE_K);
LOAD_QKV_WEIGHT:
    for (int oo = 0; oo < QKV_TILE_O; ++oo) {
        for (int pk = 0; pk < QKV_TILE_K / PACK_SIZE; ++pk) {
#pragma HLS PIPELINE II=1
            const int word = tile_base + oo * (QKV_TILE_K / PACK_SIZE) + pk;
            wq[oo][pk] = q_w[word];
            wk[oo][pk] = k_w[word];
            wv[oo][pk] = v_w[word];
        }
    }
}

static void project_qkv_group(
    float input_buf[MAX_SEQ_LEN][HIDDEN],
    const bus_t *q_w,
    const bus_t *q_b,
    const bus_t *k_w,
    const bus_t *k_b,
    const bus_t *v_w,
    const bus_t *v_b,
    int head_group,
    int seq_len,
    bus_t *q_out,
    bus_t *k_out,
    bus_t *v_out)
{
#pragma HLS INLINE off
#pragma HLS ARRAY_RESHAPE variable=input_buf cyclic factor=QKV_IN_PAR dim=2

    bus_t wq[QKV_TILE_O][QKV_TILE_K / PACK_SIZE];
    bus_t wk[QKV_TILE_O][QKV_TILE_K / PACK_SIZE];
    bus_t wv[QKV_TILE_O][QKV_TILE_K / PACK_SIZE];
    float q_acc[MAX_SEQ_LEN][QKV_TILE_O];
    float k_acc[MAX_SEQ_LEN][QKV_TILE_O];
    float v_acc[MAX_SEQ_LEN][QKV_TILE_O];
    float q_bias[QKV_TILE_O];
    float k_bias[QKV_TILE_O];
    float v_bias[QKV_TILE_O];
#pragma HLS BIND_STORAGE variable=wq type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=wk type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=wv type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=q_acc type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=k_acc type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=v_acc type=RAM_2P impl=BRAM
#pragma HLS ARRAY_PARTITION variable=wq cyclic factor=QKV_OUT_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=wk cyclic factor=QKV_OUT_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=wv cyclic factor=QKV_OUT_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=q_acc cyclic factor=PACK_SIZE dim=2
#pragma HLS ARRAY_PARTITION variable=k_acc cyclic factor=PACK_SIZE dim=2
#pragma HLS ARRAY_PARTITION variable=v_acc cyclic factor=PACK_SIZE dim=2
#pragma HLS DEPENDENCE variable=q_acc inter false
#pragma HLS DEPENDENCE variable=k_acc inter false
#pragma HLS DEPENDENCE variable=v_acc inter false

    const int group_base = head_group * GROUP_DIM;

GROUP_OUTPUT_TILES:
    for (int ob = 0; ob < GROUP_DIM; ob += QKV_TILE_O) {
        const int out_base = group_base + ob;
        load_qkv_bias_tile(q_b, k_b, v_b, out_base, q_bias, k_bias, v_bias);

    INIT_ACC:
        for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            for (int oo = 0; oo < QKV_TILE_O; oo += QKV_OUT_PAR) {
#pragma HLS PIPELINE II=1
                for (int j = 0; j < QKV_OUT_PAR; ++j) {
#pragma HLS UNROLL
                    q_acc[s][oo + j] = q_bias[oo + j];
                    k_acc[s][oo + j] = k_bias[oo + j];
                    v_acc[s][oo + j] = v_bias[oo + j];
                }
            }
        }

    INPUT_TILES:
        for (int kb = 0; kb < HIDDEN; kb += QKV_TILE_K) {
            load_qkv_weight_tile(q_w, k_w, v_w, out_base, kb, wq, wk, wv);

        K_CHUNKS:
            for (int ii = 0; ii < QKV_TILE_K; ii += QKV_IN_PAR) {
            TOKENS:
                for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
                OUTPUT_GROUPS:
                    for (int oo = 0; oo < QKV_TILE_O; oo += QKV_OUT_PAR) {
#pragma HLS PIPELINE II=1
                        float x[QKV_IN_PAR];
                        float qv[QKV_OUT_PAR];
                        float kv[QKV_OUT_PAR];
                        float vv[QKV_OUT_PAR];
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
#pragma HLS ARRAY_PARTITION variable=qv complete dim=1
#pragma HLS ARRAY_PARTITION variable=kv complete dim=1
#pragma HLS ARRAY_PARTITION variable=vv complete dim=1
                        for (int d = 0; d < QKV_IN_PAR; ++d) {
#pragma HLS UNROLL
                            x[d] = input_buf[s][kb + ii + d];
                        }
                        for (int j = 0; j < QKV_OUT_PAR; ++j) {
#pragma HLS UNROLL
                            float wq_lane[QKV_IN_PAR];
                            float wk_lane[QKV_IN_PAR];
                            float wv_lane[QKV_IN_PAR];
#pragma HLS ARRAY_PARTITION variable=wq_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=wk_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=wv_lane complete dim=1
                            const int pack = ii / PACK_SIZE;
                            unpack_bus16(wq[oo + j][pack], wq_lane);
                            unpack_bus16(wk[oo + j][pack], wk_lane);
                            unpack_bus16(wv[oo + j][pack], wv_lane);
                            qv[j] = q_acc[s][oo + j] + dot16_300mhz(x, wq_lane);
                            kv[j] = k_acc[s][oo + j] + dot16_300mhz(x, wk_lane);
                            vv[j] = v_acc[s][oo + j] + dot16_300mhz(x, wv_lane);
                        }
                        for (int j = 0; j < QKV_OUT_PAR; ++j) {
#pragma HLS UNROLL
                            q_acc[s][oo + j] = qv[j];
                            k_acc[s][oo + j] = kv[j];
                            v_acc[s][oo + j] = vv[j];
                        }
                    }
                }
            }
        }

    PACK_TILE_TO_AXI:
        for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            for (int p = 0; p < QKV_TILE_O / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
                float q_lane[PACK_SIZE];
                float k_lane[PACK_SIZE];
                float v_lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=q_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=k_lane complete dim=1
#pragma HLS ARRAY_PARTITION variable=v_lane complete dim=1
                for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                    q_lane[i] = q_acc[s][p * PACK_SIZE + i];
                    k_lane[i] = k_acc[s][p * PACK_SIZE + i];
                    v_lane[i] = v_acc[s][p * PACK_SIZE + i];
                }
                const int dst = s * PACKS + out_base / PACK_SIZE + p;
                q_out[dst] = pack_bus16(q_lane);
                k_out[dst] = pack_bus16(k_lane);
                v_out[dst] = pack_bus16(v_lane);
            }
        }
    }
}

extern "C" {
void bert_qkv_kernel(
    const bus_t *input_hidden,
    const bus_t *q_w_all,
    const bus_t *q_b_all,
    const bus_t *k_w_all,
    const bus_t *k_b_all,
    const bus_t *v_w_all,
    const bus_t *v_b_all,
    int layer_index,
    int valid_seq_len,
    bus_t *q_out,
    bus_t *k_out,
    bus_t *v_out)
{
#pragma HLS INLINE off
#pragma HLS INTERFACE m_axi port=input_hidden offset=slave bundle=gmem_hidden depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=q_w_all offset=slave bundle=gmem_qw depth=442368 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=q_b_all offset=slave bundle=gmem_qw depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=k_w_all offset=slave bundle=gmem_kw depth=442368 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=k_b_all offset=slave bundle=gmem_kw depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=v_w_all offset=slave bundle=gmem_vw depth=442368 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=v_b_all offset=slave bundle=gmem_vw depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=q_out offset=slave bundle=gmem_qout depth=6144 max_write_burst_length=64 num_write_outstanding=16
#pragma HLS INTERFACE m_axi port=k_out offset=slave bundle=gmem_kout depth=6144 max_write_burst_length=64 num_write_outstanding=16
#pragma HLS INTERFACE m_axi port=v_out offset=slave bundle=gmem_vout depth=6144 max_write_burst_length=64 num_write_outstanding=16

#pragma HLS INTERFACE s_axilite port=input_hidden
#pragma HLS INTERFACE s_axilite port=q_w_all
#pragma HLS INTERFACE s_axilite port=q_b_all
#pragma HLS INTERFACE s_axilite port=k_w_all
#pragma HLS INTERFACE s_axilite port=k_b_all
#pragma HLS INTERFACE s_axilite port=v_w_all
#pragma HLS INTERFACE s_axilite port=v_b_all
#pragma HLS INTERFACE s_axilite port=layer_index
#pragma HLS INTERFACE s_axilite port=valid_seq_len
#pragma HLS INTERFACE s_axilite port=q_out
#pragma HLS INTERFACE s_axilite port=k_out
#pragma HLS INTERFACE s_axilite port=v_out
#pragma HLS INTERFACE s_axilite port=return

    const int seq_len = sanitize_seq_len(valid_seq_len);
    const int layer = sanitize_layer(layer_index);
    const int w_off = layer * ATTN_W_PACKS;
    const int b_off = layer * ATTN_B_PACKS;

    static float input_buf[MAX_SEQ_LEN][HIDDEN];
#pragma HLS BIND_STORAGE variable=input_buf type=RAM_2P impl=URAM latency=3
#pragma HLS ARRAY_RESHAPE variable=input_buf cyclic factor=QKV_IN_PAR dim=2

    load_hidden_matrix(input_hidden, seq_len, input_buf);

HEAD_GROUP_LOOP:
    for (int hg = 0; hg < HEAD_GROUPS; ++hg) {
        project_qkv_group(
            input_buf,
            q_w_all + w_off, q_b_all + b_off,
            k_w_all + w_off, k_b_all + b_off,
            v_w_all + w_off, v_b_all + b_off,
            hg, seq_len, q_out, k_out, v_out);
    }
}
}
