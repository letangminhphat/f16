#include "bert_model_300mhz.h"
#include "layernorm_utils_300mhz.h"

static void load_down_weight_tile(
    const bus_t *weights,
    int out_base,
    int in_base,
    bus_t weight_tile[FFN_TILE_OUT][FFN_TILE_K / PACK_SIZE])
{
#pragma HLS INLINE off
LOAD_DOWN_TILE:
    for (int oo = 0; oo < FFN_TILE_OUT; ++oo) {
        for (int p = 0; p < FFN_TILE_K / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
            const int global_out = out_base + oo;
            const int weight_out_base =
                (global_out / FFN_WEIGHT_TILE_OUT) * FFN_WEIGHT_TILE_OUT;
            const int weight_out_lane = global_out % FFN_WEIGHT_TILE_OUT;
            const int word = tiled_matrix_word_index(
                weight_out_base, in_base, weight_out_lane, p,
                FFN_DIM, FFN_WEIGHT_TILE_OUT, FFN_TILE_K);
            weight_tile[oo][p] = weights[word];
        }
    }
}

static void compute_down_projection_stream(
    hidden_stream_t &intermediate_in,
    const bus_t *weights,
    const bus_t *bias,
    int seq_len,
    float output_buf[MAX_SEQ_LEN][HIDDEN])
{
#pragma HLS INLINE off
#pragma HLS ARRAY_RESHAPE variable=output_buf cyclic factor=FFN_MAC_GROUP dim=2

    float activation_tile[MAX_SEQ_LEN][FFN_TILE_OUT];
    bus_t weight_tile[FFN_TILE_OUT][FFN_TILE_K / PACK_SIZE];
    bus_t bias_cache[PACKS];
#pragma HLS BIND_STORAGE variable=activation_tile type=RAM_2P impl=BRAM latency=2
#pragma HLS BIND_STORAGE variable=weight_tile type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=bias_cache type=RAM_2P impl=BRAM
#pragma HLS ARRAY_RESHAPE variable=activation_tile cyclic factor=FFN_K_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=weight_tile cyclic factor=FFN_MAC_GROUP dim=1
#pragma HLS DEPENDENCE variable=output_buf inter false

LOAD_DOWN_BIAS:
    for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
        bias_cache[p] = bias[p];
    }

INIT_DOWN_OUTPUT:
    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        for (int p = 0; p < PACKS; p += 2) {
#pragma HLS PIPELINE II=1
            float lane0[PACK_SIZE];
            float lane1[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane0 complete dim=1
#pragma HLS ARRAY_PARTITION variable=lane1 complete dim=1
            unpack_bus16(bias_cache[p], lane0);
            unpack_bus16(bias_cache[p + 1], lane1);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                output_buf[s][p * PACK_SIZE + i] = lane0[i];
                output_buf[s][(p + 1) * PACK_SIZE + i] = lane1[i];
            }
        }
    }

DOWN_STREAM_BLOCKS:
    for (int stream_base = 0; stream_base < FFN_DIM; stream_base += FFN_TILE_OUT) {
    READ_ACTIVATION_TILE:
        for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
            for (int p = 0; p < FFN_TILE_OUT / PACK_SIZE; ++p) {
#pragma HLS PIPELINE II=1
                float lane[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=lane complete dim=1
                unpack_bus16(intermediate_in.read(), lane);
                for (int d = 0; d < PACK_SIZE; ++d) {
#pragma HLS UNROLL
                    activation_tile[s][p * PACK_SIZE + d] = lane[d];
                }
            }
        }

    DOWN_HALF_TILES:
        for (int half = 0; half < FFN_TILE_OUT / FFN_TILE_K; ++half) {
            const int in_base = stream_base + half * FFN_TILE_K;
        DOWN_OUTPUT_TILES:
            for (int out_base = 0; out_base < HIDDEN; out_base += FFN_TILE_OUT) {
                load_down_weight_tile(weights, out_base, in_base, weight_tile);

            DOWN_K_PACKS:
                for (int kp = 0; kp < FFN_TILE_K / FFN_K_PAR; ++kp) {
                DOWN_TOKENS:
                    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
                    DOWN_OUTPUT_GROUPS:
                        for (int j = 0; j < FFN_TILE_OUT; j += FFN_MAC_GROUP) {
#pragma HLS PIPELINE II=1
                            float x[FFN_K_PAR];
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
                            for (int d = 0; d < FFN_K_PAR; ++d) {
#pragma HLS UNROLL
                                x[d] = activation_tile[s][
                                    half * FFN_TILE_K + kp * FFN_K_PAR + d];
                            }

                            for (int jj = 0; jj < FFN_MAC_GROUP; ++jj) {
#pragma HLS UNROLL
                                float w_lane[FFN_K_PAR];
#pragma HLS ARRAY_PARTITION variable=w_lane complete dim=1
                                unpack_bus16(weight_tile[j + jj][kp], w_lane);
                                output_buf[s][out_base + j + jj] +=
                                    dot16_300mhz(x, w_lane);
                            }
                        }
                    }
                }
            }
        }
    }
}

static void fused_ffn_layernorm_write(
    const bus_t *residual,
    float sublayer[MAX_SEQ_LEN][HIDDEN],
    const bus_t *gamma,
    const bus_t *beta,
    int seq_len,
    bus_t *output)
{
#pragma HLS INLINE off
#pragma HLS ARRAY_RESHAPE variable=sublayer cyclic factor=FFN_MAC_GROUP dim=2
    bus_t gamma_cache[PACKS];
    bus_t beta_cache[PACKS];
    bus_t local_x[PACKS];
#pragma HLS BIND_STORAGE variable=gamma_cache type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=beta_cache type=RAM_2P impl=BRAM
#pragma HLS BIND_STORAGE variable=local_x type=RAM_2P impl=BRAM

LOAD_FFN_NORM:
    for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
        gamma_cache[p] = gamma[p];
        beta_cache[p] = beta[p];
    }

FFN_NORM_TOKENS:
    for (int s = 0; s < seq_len; ++s) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=128
        float sum_banks[LN_REDUCE_BANKS];
        float sumsq_banks[LN_REDUCE_BANKS];
#pragma HLS ARRAY_PARTITION variable=sum_banks complete dim=1
#pragma HLS ARRAY_PARTITION variable=sumsq_banks complete dim=1
#pragma HLS DEPENDENCE variable=sum_banks inter false
#pragma HLS DEPENDENCE variable=sumsq_banks inter false
        for (int b = 0; b < LN_REDUCE_BANKS; ++b) {
#pragma HLS UNROLL
            sum_banks[b] = 0.0f;
            sumsq_banks[b] = 0.0f;
        }

    ADD_ACCUMULATE:
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float r[PACK_SIZE];
            float x[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=r complete dim=1
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
            unpack_bus16(residual[s * PACKS + p], r);
            const int bank_group = p & (LN_REDUCE_GROUPS - 1);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                const float v = r[i] + sublayer[s][p * PACK_SIZE + i];
                const int bank = bank_group * PACK_SIZE + i;
                x[i] = v;
                sum_banks[bank] += v;
                sumsq_banks[bank] += v * v;
            }
            local_x[p] = pack_bus16(x);
        }

        float mean;
        float inv_stddev;
        layernorm_statistics_300mhz(sum_banks, sumsq_banks, mean, inv_stddev);

    NORMALIZE_WRITE:
        for (int p = 0; p < PACKS; ++p) {
#pragma HLS PIPELINE II=1
            float x[PACK_SIZE];
            float g[PACK_SIZE];
            float b[PACK_SIZE];
            float y[PACK_SIZE];
#pragma HLS ARRAY_PARTITION variable=x complete dim=1
#pragma HLS ARRAY_PARTITION variable=g complete dim=1
#pragma HLS ARRAY_PARTITION variable=b complete dim=1
#pragma HLS ARRAY_PARTITION variable=y complete dim=1
            unpack_bus16(local_x[p], x);
            unpack_bus16(gamma_cache[p], g);
            unpack_bus16(beta_cache[p], b);
            for (int i = 0; i < PACK_SIZE; ++i) {
#pragma HLS UNROLL
                y[i] = g[i] * ((x[i] - mean) * inv_stddev) + b[i];
            }
            output[s * PACKS + p] = pack_bus16(y);
        }
    }
}

extern "C" {
void bert_ffn_down_norm_kernel(
    const bus_t *residual_hidden,
    hidden_stream_t &intermediate_in,
    const bus_t *down_w_all,
    const bus_t *down_b_all,
    const bus_t *norm_gamma_all,
    const bus_t *norm_beta_all,
    int layer_index,
    int valid_seq_len,
    bus_t *output_hidden)
{
#pragma HLS INLINE off
#pragma HLS INTERFACE m_axi port=residual_hidden offset=slave bundle=gmem_residual depth=6144 max_read_burst_length=64 num_read_outstanding=16
#pragma HLS INTERFACE m_axi port=output_hidden offset=slave bundle=gmem_output depth=6144 max_write_burst_length=64 num_write_outstanding=16
#pragma HLS INTERFACE axis port=intermediate_in
#pragma HLS INTERFACE m_axi port=down_w_all offset=slave bundle=gmem_down depth=1769472 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=down_b_all offset=slave bundle=gmem_down depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=norm_gamma_all offset=slave bundle=gmem_down depth=576 max_read_burst_length=128 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=norm_beta_all offset=slave bundle=gmem_down depth=576 max_read_burst_length=128 num_read_outstanding=32

#pragma HLS INTERFACE s_axilite port=residual_hidden
#pragma HLS INTERFACE s_axilite port=down_w_all
#pragma HLS INTERFACE s_axilite port=down_b_all
#pragma HLS INTERFACE s_axilite port=norm_gamma_all
#pragma HLS INTERFACE s_axilite port=norm_beta_all
#pragma HLS INTERFACE s_axilite port=layer_index
#pragma HLS INTERFACE s_axilite port=valid_seq_len
#pragma HLS INTERFACE s_axilite port=output_hidden
#pragma HLS INTERFACE s_axilite port=return

    const int seq_len = sanitize_seq_len(valid_seq_len);
    const int layer = sanitize_layer(layer_index);
    const int w_off = layer * FFN_DN_W_PACKS;
    const int b_off = layer * FFN_DN_B_PACKS;
    const int norm_off = layer * PACKS;

    static float output_buf[MAX_SEQ_LEN][HIDDEN];
#pragma HLS BIND_STORAGE variable=output_buf type=RAM_2P impl=URAM latency=3
#pragma HLS ARRAY_RESHAPE variable=output_buf cyclic factor=FFN_MAC_GROUP dim=2

    compute_down_projection_stream(
        intermediate_in,
        down_w_all + w_off,
        down_b_all + b_off,
        seq_len,
        output_buf);
    fused_ffn_layernorm_write(
        residual_hidden,
        output_buf,
        norm_gamma_all + norm_off,
        norm_beta_all + norm_off,
        seq_len,
        output_hidden);
}
}
