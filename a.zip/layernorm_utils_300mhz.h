#ifndef BERT_LAYERNORM_UTILS_300MHZ_H
#define BERT_LAYERNORM_UTILS_300MHZ_H

#include "bert_model_300mhz.h"

// Four recurrence groups keep a four-cycle gap between updates to the same
// accumulator while halving the reduction tree and routing load.
static const int LN_REDUCE_GROUPS = 4;
static const int LN_REDUCE_BANKS  = LN_REDUCE_GROUPS * PACK_SIZE; // 64
static const float BERT_LAYERNORM_EPS = 1.0e-12f;

static inline float reduce64_ln(const float in[64]) {
#pragma HLS INLINE
    float s1[32];
    float s2[16];
    float s3[8];
    float s4[4];
    float s5[2];
#pragma HLS ARRAY_PARTITION variable=s1 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s2 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s3 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s4 complete dim=1
#pragma HLS ARRAY_PARTITION variable=s5 complete dim=1
    for (int i = 0; i < 32; ++i) {
#pragma HLS UNROLL
        s1[i] = in[2 * i] + in[2 * i + 1];
    }
    for (int i = 0; i < 16; ++i) {
#pragma HLS UNROLL
        s2[i] = s1[2 * i] + s1[2 * i + 1];
    }
    for (int i = 0; i < 8; ++i) {
#pragma HLS UNROLL
        s3[i] = s2[2 * i] + s2[2 * i + 1];
    }
    for (int i = 0; i < 4; ++i) {
#pragma HLS UNROLL
        s4[i] = s3[2 * i] + s3[2 * i + 1];
    }
    for (int i = 0; i < 2; ++i) {
#pragma HLS UNROLL
        s5[i] = s4[2 * i] + s4[2 * i + 1];
    }
    return s5[0] + s5[1];
}

static inline void layernorm_statistics_300mhz(
    const float sum_banks[LN_REDUCE_BANKS],
    const float sumsq_banks[LN_REDUCE_BANKS],
    float &mean,
    float &inv_stddev)
{
#pragma HLS INLINE
    const float total_sum = reduce64_ln(sum_banks);
    const float total_sum_sq = reduce64_ln(sumsq_banks);
    const float inv_hidden = 1.0f / (float)HIDDEN;
    mean = total_sum * inv_hidden;
    const float raw_variance = total_sum_sq * inv_hidden - mean * mean;
    const float variance = hls::fmaxf(raw_variance, 0.0f);
    inv_stddev = hls::rsqrtf(variance + BERT_LAYERNORM_EPS);
}

#endif
