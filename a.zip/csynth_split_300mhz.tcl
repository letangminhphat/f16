# Vitis HLS 2022.1
# Chi chay C synthesis tung kernel, KHONG export XO.
# Chay:
#   cd /home/minhphat/base
#   vitis_hls -f csynth_split_300mhz.tcl

set script_dir [file dirname [file normalize [info script]]]
set build_dir  [file join $script_dir build_hls]
set report_dir [file join $script_dir rp]
set part_name  "xcu250-figd2104-2L-e"
set clock_ns   3.333

file mkdir $build_dir
file mkdir $report_dir

proc save_csynth_report {build_dir report_dir project_name kernel_name} {
    set source_report [file join \
        $build_dir $project_name solution1 syn report \
        "csynth.rpt"]
    set target_report [file join $report_dir "${kernel_name}.rpt"]

    if {![file exists $source_report]} {
        error "Khong tim thay C synthesis report: $source_report"
    }

    file copy -force $source_report $target_report
    puts "Saved report: $target_report"
}

cd $build_dir

# ============================================================
# 1. QKV kernel
# ============================================================
open_project -reset bert_qkv_kernel
set_top bert_qkv_kernel
add_files [file join $script_dir qkv_kernel_300mhz.cpp] \
    -cflags "-I$script_dir"
open_solution -reset solution1 -flow_target vitis
set_part $part_name
create_clock -period $clock_ns -name default
set_clock_uncertainty 0.250
config_compile -pipeline_loops 1
config_interface -m_axi_addr64
csynth_design
save_csynth_report \
    $build_dir $report_dir bert_qkv_kernel bert_qkv_kernel
close_project

# ============================================================
# 2. Attention + Output projection + AddNorm kernel
# ============================================================
open_project -reset bert_attention_out_norm_kernel
set_top bert_attention_out_norm_kernel
add_files [file join $script_dir attention_out_norm_kernel_300mhz.cpp] \
    -cflags "-I$script_dir"
open_solution -reset solution1 -flow_target vitis
set_part $part_name
create_clock -period $clock_ns -name default
set_clock_uncertainty 0.250
config_compile -pipeline_loops 1
config_interface -m_axi_addr64
csynth_design
save_csynth_report \
    $build_dir $report_dir \
    bert_attention_out_norm_kernel bert_attention_out_norm_kernel
close_project

# ============================================================
# 3. FFN Up + GELU kernel
# ============================================================
open_project -reset bert_ffn_up_kernel
set_top bert_ffn_up_kernel
add_files [file join $script_dir ffn_up_kernel_300mhz.cpp] \
    -cflags "-I$script_dir"
open_solution -reset solution1 -flow_target vitis
set_part $part_name
create_clock -period $clock_ns -name default
set_clock_uncertainty 0.250
config_compile -pipeline_loops 1
config_interface -m_axi_addr64
csynth_design
save_csynth_report \
    $build_dir $report_dir bert_ffn_up_kernel bert_ffn_up_kernel
close_project

# ============================================================
# 4. FFN Down + AddNorm kernel
# ============================================================
open_project -reset bert_ffn_down_norm_kernel
set_top bert_ffn_down_norm_kernel
add_files [file join $script_dir ffn_down_norm_kernel_300mhz.cpp] \
    -cflags "-I$script_dir"
open_solution -reset solution1 -flow_target vitis
set_part $part_name
create_clock -period $clock_ns -name default
set_clock_uncertainty 0.250
config_compile -pipeline_loops 1
config_interface -m_axi_addr64
csynth_design
save_csynth_report \
    $build_dir $report_dir \
    bert_ffn_down_norm_kernel bert_ffn_down_norm_kernel
close_project

exit
