// Scheduling fragment for an out-of-order OpenCL command queue.
// Buffer placement must match link_u250_300mhz.cfg.
// This is intentionally a function fragment: integrate it into the existing host.

#include <CL/cl2.hpp>
#include <vector>
#include <stdexcept>
#include <string>

static void check_cl(cl_int err, const char *what) {
    if (err != CL_SUCCESS) {
        throw std::runtime_error(std::string(what) + " failed: " + std::to_string(err));
    }
}

struct BertKernels {
    cl::Kernel qkv;
    cl::Kernel attention_norm;
    cl::Kernel ffn_up;
    cl::Kernel ffn_down_norm;
};

struct BertBuffers {
    cl::Buffer attention_mask;
    cl::Buffer q_w, q_b, k_w, k_b, v_w, v_b;
    cl::Buffer o_w, o_b, attn_gamma, attn_beta;
    cl::Buffer up_w, up_b, down_w, down_b, ffn_gamma, ffn_beta;
    cl::Buffer hidden_a, hidden_b;
    cl::Buffer q_buf, k_buf, v_buf;
};

void enqueue_bert_base(
    cl::CommandQueue &queue,
    BertKernels &k,
    BertBuffers &b,
    int seq_len,
    cl::Event *final_event)
{
    cl_int err = CL_SUCCESS;
    int a = 0;
    cl::Event previous;
    bool has_previous = false;

    for (int layer = 0; layer < 12; ++layer) {
        cl::Event qkv_event, attn_event, up_event, down_event;
        std::vector<cl::Event> wait_one(1);

        a = 0;
        err  = k.qkv.setArg(a++, b.hidden_a);
        err |= k.qkv.setArg(a++, b.q_w);
        err |= k.qkv.setArg(a++, b.q_b);
        err |= k.qkv.setArg(a++, b.k_w);
        err |= k.qkv.setArg(a++, b.k_b);
        err |= k.qkv.setArg(a++, b.v_w);
        err |= k.qkv.setArg(a++, b.v_b);
        err |= k.qkv.setArg(a++, layer);
        err |= k.qkv.setArg(a++, seq_len);
        err |= k.qkv.setArg(a++, b.q_buf);
        err |= k.qkv.setArg(a++, b.k_buf);
        err |= k.qkv.setArg(a++, b.v_buf);
        check_cl(err, "set qkv args");
        if (has_previous) wait_one[0] = previous;
        check_cl(queue.enqueueTask(
            k.qkv, has_previous ? &wait_one : nullptr, &qkv_event), "enqueue qkv");

        a = 0;
        err  = k.attention_norm.setArg(a++, b.hidden_a);
        err |= k.attention_norm.setArg(a++, b.q_buf);
        err |= k.attention_norm.setArg(a++, b.k_buf);
        err |= k.attention_norm.setArg(a++, b.v_buf);
        err |= k.attention_norm.setArg(a++, b.attention_mask);
        err |= k.attention_norm.setArg(a++, b.o_w);
        err |= k.attention_norm.setArg(a++, b.o_b);
        err |= k.attention_norm.setArg(a++, b.attn_gamma);
        err |= k.attention_norm.setArg(a++, b.attn_beta);
        err |= k.attention_norm.setArg(a++, layer);
        err |= k.attention_norm.setArg(a++, seq_len);
        err |= k.attention_norm.setArg(a++, b.hidden_b);
        check_cl(err, "set attention args");
        wait_one[0] = qkv_event;
        check_cl(queue.enqueueTask(k.attention_norm, &wait_one, &attn_event), "enqueue attention");

        a = 0;
        err  = k.ffn_up.setArg(a++, b.hidden_b);
        err |= k.ffn_up.setArg(a++, b.up_w);
        err |= k.ffn_up.setArg(a++, b.up_b);
        err |= k.ffn_up.setArg(a++, layer);
        err |= k.ffn_up.setArg(a++, seq_len);
        check_cl(err, "set ffn up args");

        a = 0;
        err  = k.ffn_down_norm.setArg(a++, b.hidden_b);
        err |= k.ffn_down_norm.setArg(a++, b.down_w);
        err |= k.ffn_down_norm.setArg(a++, b.down_b);
        err |= k.ffn_down_norm.setArg(a++, b.ffn_gamma);
        err |= k.ffn_down_norm.setArg(a++, b.ffn_beta);
        err |= k.ffn_down_norm.setArg(a++, layer);
        err |= k.ffn_down_norm.setArg(a++, seq_len);
        err |= k.ffn_down_norm.setArg(a++, b.hidden_a);
        check_cl(err, "set ffn down args");
        wait_one[0] = attn_event;
        check_cl(queue.enqueueTask(k.ffn_down_norm, &wait_one, &down_event), "enqueue ffn down");
        check_cl(queue.enqueueTask(k.ffn_up, &wait_one, &up_event), "enqueue ffn up");

        previous = down_event;
        has_previous = true;
    }

    if (final_event != nullptr) {
        *final_event = previous;
    }
}
