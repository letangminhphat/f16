# accelerator_v3: BERT encoder Vitis HLS architecture for Alveo U250

## Audited source and actual model

The implementation was derived from every BERT C source file in `sources/`:

- `bert_encoder_layer.h`: compile-time shapes and function contracts.
- `bert_linear.c`: row-major dense equations and loop order token → output → input.
- `bert_attention.c`: head transforms, scaled dot product, key mask, stable softmax, and SV.
- `bert_norm.c`: post-residual LayerNorm.
- `bert_ffn.c`: tanh GELU and both FFN projections.
- `bert_encoder_layer.c`: the invoked one-layer operator order and residual paths.
- `main.c`: the actual entry point, one invocation, deterministic data initialization, and mask.

The audited C source has `TEST_SMALL=1`, but the accelerator deployment profile
is explicitly forced to standard BERT-Base dimensions:

| Parameter | Value | Evidence |
|---|---:|---|
| Batch | 1 | one static input and one call in `main.c` |
| Sequence length | 128 | forced accelerator deployment profile |
| Hidden size | 768 | standard BERT-Base profile |
| Heads | 12 | standard BERT-Base profile |
| Head dimension | 64 | hidden size divided by heads |
| FFN intermediate | 3072 | standard BERT-Base profile |
| Encoder layers | 12 | host-reused hardware layer contract |
| Vocabulary size | 30522 | standard BERT-Base metadata |
| Maximum position | 512 | standard BERT-Base metadata |
| Type vocabulary | 2 | standard BERT-Base metadata |
| Datatype | FP32 for input, weight, bias, accumulation, nonlinear, and output | all model arrays and accumulators are `float` |
| LayerNorm epsilon | `1e-12f` | `EPSILON` |
| Attention mask value | `-10000.0f` | `NEG_INF_MASK` |

The source has no embedding tables, embedding LayerNorm, model loader, or
multi-layer weight loader. The standard vocabulary/position metadata is a
deployment assumption. The accelerator starts from hidden `[128][768]`; no
embedding kernel or embedding Tcl script is generated.

## Source math preserved

- Dense weights are logically `[input][output]`; `Y[t][o] = bias[o] + Σ X[t][i]W[i][o]`.
- Q/K/V are projected as `[token][hidden]`, then physically emitted as
  `[head][token][head_dim]`.
- Attention score is `dot(Q,K) / sqrt(HEAD_DIM)`.
- A key is masked only when `attention_mask[key] == 0.0f`; the additive value is
  exactly `-10000.0f`. Query rows are not suppressed.
- Softmax is stable: row maximum, exact `expf(score-max)`, sum, and division.
- LayerNorm is post-residual, per token, uses population variance (division by
  hidden size), then `gamma * normalized + beta`.
- GELU preserves `0.5*x*(1+tanh(0.7978845608028654*(x+0.044715*x^3)))` and its
  source operation order.

## Kernel decomposition and dataflow

```text
DDR0 hidden
  -> K1 bert_qkv_kernel
       -> Q/K/V streams ---------------------> K2 exact attention
       -> residual-A ----------------------.       -> context
                                              `----> K3 Wo + bias + residual + LayerNorm
                                                       |-> FFN input -> K4 W1 + bias + GELU
                                                       `-> residual-B -----------.
                                                            K4 intermediate ---> K5 W2 + bias + residual + LayerNorm
                                                                                   -> DDR0 hidden ping/pong
```

K1 holds hidden X on chip and time-multiplexes one tiled A-W engine across Q,
K, and V. It does not read X three times. K2 keeps Q rows resident and K/V on
chip and performs exact two-pass row-fused attention; neither score nor
probability tensors have a DDR interface. K3, K4, and K5 fuse all lightweight
post-operations into their owning major kernels.

## Stream contracts

All streams use `ap_axiu<512,0,0,0>`. FP32 lane 0 is bits `[31:0]`, lane 15 is
bits `[511:480]`, unused tail lanes are zero, `keep/strb` are all ones, and
`TLAST` marks the final word of one tensor. Producer and consumer loop orders
are identical.

| Stream | Logical/physical order | Current scalars / 512-bit words | Producer | Consumer | Candidate FIFO |
|---|---|---:|---|---|---:|
| Q | `[head][token][head_dim]` | 98,304 / 6,144 | K1 | K2 | 64 |
| K | `[head][token][head_dim]` | 98,304 / 6,144 | K1 | K2 | 64 |
| V | `[head][token][head_dim]` | 98,304 / 6,144 | K1 | K2 | 64 |
| residual-A | `[token][hidden]` | 98,304 / 6,144 | K1 | K3 | 64 |
| context | `[token][hidden]` | 98,304 / 6,144 | K2 | K3 | 64 |
| FFN input | `[token][hidden]` | 98,304 / 6,144 | K3 | K4 | 64 |
| residual-B | `[token][hidden]` | 98,304 / 6,144 | K3 | K5 | 64 |
| FFN intermediate | `[token][ffn]` | 393,216 / 24,576 | K4 | K5 | 64 |

The cross-kernel production policy is intentional: K1 emits Q, K, V, then
residual-A. K3 emits the FFN input before residual-B, while K5 consumes the K4
intermediate before residual-B. This ordering avoids a cyclic FIFO wait without
requiring two processes to read the same AXI parameter bundle. Logical
per-token/per-head word ceilings are defined in `stream_contracts.h`; physical
tensors are continuously packed without row-boundary padding.

## Packed memory and weight layout

Hidden, mask, bias, gamma, beta, and final output are contiguous FP32 packed
16 scalars per 512-bit word. Major-kernel offsets and strides are expressed in
512-bit words.

Weights are not consumed in the C row-major file order. Each logical
`[input_dim][output_dim]` matrix must be packed as:

```text
[input_tile][output_tile][input_lane][output_lane]
```

Tails are explicitly zero-padded to `TILE_K × TILE_N`; helpers in
`bert_layout.h` define the only index formula. The host-side packer must use
the selected build profile because FFN UP and FFN DOWN have independent tile
sizes. Matrix base offsets point to individually word-aligned matrices.

## Compute engines

The A-W projections use a weight-stationary loop order. Each contiguous weight
tile is loaded once, then reused across all 128 resident tokens before the next
tile is loaded. Accumulation goes directly into the banked full output buffer;
the earlier activation-tile copy and repeated per-row-tile weight loads are gone.
QKV and Wo use `MAC_LANES × OUT_PAR`; FFN uses its larger independent
`FFN_MAC_LANES × FFN_OUT_PAR` datapath. Tail guards preserve padded tile support.

Attention uses a separate A-A path because QK and SV access patterns differ
from weights. Per head/query it computes a score row with resident Q and reused
K, adds the exact source mask, derives the stable maximum, then computes exp,
the denominator, and the exp-times-V numerator in the second pass. A zero
denominator returns zero context; with the source's finite `-10000` mask, an
all-masked row still follows the original stable-softmax behavior.

The v3 attention path banks Q/K/V across head groups, K across query-key lanes,
and V across weighted-value lanes. It processes two heads concurrently in the
balanced/performance profiles. QK evaluates multiple keys concurrently, row
maximum and exponentials operate on multiple score lanes, and SV uses rotating
partial accumulators so the FP32 recurrence does not force every key onto one
accumulator. QKV and Wo continue to use the direct-activation A-W engine
described above; attention AddNorm remains cached and vectorized because it was
not the v2 bottleneck.

## Build profiles

`config/build_profiles.h` provides:

- `BERT_ROUTE_FRIENDLY`: 8 MAC lanes × 8 output lanes, tile `8×64×16`,
  one head, QK key parallelism 2, softmax/SV parallelism 2, FIFO depth 32.
- `BERT_BALANCED`: 16 MAC lanes × 16 output lanes, tile `8×64×32`,
  two heads, QK key parallelism 4, softmax/SV parallelism 4, FIFO depth 64.
- `BERT_PERFORMANCE` (default): 16 MAC lanes × 16 output lanes, tile
  `16×128×32`, two heads, QK key parallelism 8, softmax/SV parallelism 4,
  FFN parallelism `20×16`, eight GELU lanes, FFN tile `160×32`, FIFO depth 128.

FFN UP and DOWN tile constants are separate in every profile. These are
design-time candidates only; none has synthesis or route evidence in this
source-only task.

## U250 mapping and layer reuse

`config/system_u250.cfg` proposes SLR0 QKV plus FFN DOWN, SLR1 attention,
SLR2 Wo/AddNorm, and SLR3 FFN UP. DDR0 contains activation ping/pong and
mask, DDR1 QKV, DDR2 Wo/W1, and DDR3 W2. The map is explicitly provisional
until link reports confirm bank locality, SLL crossings, congestion, and WNS.

The hardware is one reusable encoder layer, never twelve replicated layers.
Every parameter group has a base word, a per-layer word stride, and a
`layer_index`. For a model with multiple packed layers the host invokes all
five kernels for layer `l`, choosing activation A as input/B as output for even
layers and B/A for odd layers. `NUM_LAYERS` is 12 in the forced deployment
profile; external weights and the host loop are still required.

## Assumptions and unknowns

- The host creates tile-major packed weight blobs; no host or loader exists in
  the audited repository, so only the exact device/offset contract is supplied.
- BERT-Base vocabulary 30522, maximum position 512, and type vocabulary 2 are
  deployment assumptions because the C source does not contain embedding metadata.
- Matrices are individually 512-bit-word aligned. Equal-shaped Q/K/V matrices
  share one layer stride; equal-sized bias/LayerNorm vectors in a parameter
  group share one layer stride.
- `active_sequence_length` is clamped to `SEQ_LEN` and is an additional key
  bound; pass `SEQ_LEN` to reproduce the C source using only its mask tensor.
- The repository identifies a `xilinx_u250_gen3x16_xdma_3_1_202020_1` platform
  in example logs but contains no installed `.xpfm` path. Tcl uses the standard
  `xcu250-figd2104-2L-e` part and permits `U250_PART` override.
- `report_v2` contains five Vitis HLS 2022.1 csynth reports for the measured
  16×16 balanced profile. All five meet the 5 ns target. The exact measurements
  and the report-grounded v3 changes are recorded in `REPORT_V2_ANALYSIS.md`.
- The weight-stationary GEMM path, enlarged FFN/GELU parallelism, and parallel
  attention introduced in v3 require fresh csynth and post-link reports before their
  latency and resource effects can be treated as achieved results.
