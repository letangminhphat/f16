#ifndef BERT_SOFTMAX_HLS_H
#define BERT_SOFTMAX_HLS_H

#include "math_utils_hls.h"

namespace bert {

template <int LANES>
struct ParallelSumReducer;

template <>
struct ParallelSumReducer<2> {
    static softmax_accum_t reduce(const softmax_accum_t input[2]) {
#pragma HLS INLINE
        return input[0] + input[1];
    }
};

template <>
struct ParallelSumReducer<4> {
    static softmax_accum_t reduce(const softmax_accum_t input[4]) {
#pragma HLS INLINE
        const softmax_accum_t low = input[0] + input[1];
        const softmax_accum_t high = input[2] + input[3];
        return low + high;
    }
};

template <>
struct ParallelSumReducer<8> {
    static softmax_accum_t reduce(const softmax_accum_t input[8]) {
#pragma HLS INLINE
        softmax_accum_t stage4[4];
        softmax_accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    sum8_to4:
        for (int lane = 0; lane < 4; ++lane) {
#pragma HLS UNROLL
            stage4[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    sum4_to2:
        for (int lane = 0; lane < 2; ++lane) {
#pragma HLS UNROLL
            stage2[lane] = stage4[lane * 2] + stage4[lane * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <>
struct ParallelSumReducer<16> {
    static softmax_accum_t reduce(const softmax_accum_t input[16]) {
#pragma HLS INLINE
        softmax_accum_t stage8[8];
        softmax_accum_t stage4[4];
        softmax_accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage8 complete
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    sum16_to8:
        for (int lane = 0; lane < 8; ++lane) {
#pragma HLS UNROLL
            stage8[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    sum8_to4:
        for (int lane = 0; lane < 4; ++lane) {
#pragma HLS UNROLL
            stage4[lane] = stage8[lane * 2] + stage8[lane * 2 + 1];
        }
    sum4_to2:
        for (int lane = 0; lane < 2; ++lane) {
#pragma HLS UNROLL
            stage2[lane] = stage4[lane * 2] + stage4[lane * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <int LANES>
struct ParallelMaxReducer;

template <>
struct ParallelMaxReducer<2> {
    static softmax_accum_t reduce(const softmax_accum_t input[2]) {
#pragma HLS INLINE
        return input[0] > input[1] ? input[0] : input[1];
    }
};

template <>
struct ParallelMaxReducer<4> {
    static softmax_accum_t reduce(const softmax_accum_t input[4]) {
#pragma HLS INLINE
        const softmax_accum_t low = input[0] > input[1] ? input[0] : input[1];
        const softmax_accum_t high = input[2] > input[3] ? input[2] : input[3];
        return low > high ? low : high;
    }
};

inline softmax_accum_t stable_exp(softmax_accum_t score,
                                  softmax_accum_t maximum) {
#pragma HLS INLINE
    return exact_exp(score - maximum);
}

template <int N>
softmax_accum_t row_max(const softmax_accum_t scores[N]) {
    softmax_accum_t lane_maximum[ATTENTION_PAR];
#pragma HLS ARRAY_PARTITION variable=lane_maximum complete
initialize_maximum_lanes:
    for (int lane = 0; lane < ATTENTION_PAR; ++lane) {
#pragma HLS UNROLL
        lane_maximum[lane] = scores[lane];
    }
row_max_groups:
    for (int base = ATTENTION_PAR; base < N; base += ATTENTION_PAR) {
#pragma HLS PIPELINE II=1
    row_max_lanes:
        for (int lane = 0; lane < ATTENTION_PAR; ++lane) {
#pragma HLS UNROLL
            const softmax_accum_t candidate = scores[base + lane];
            lane_maximum[lane] = candidate > lane_maximum[lane]
                                         ? candidate
                                         : lane_maximum[lane];
        }
    }
    return ParallelMaxReducer<ATTENTION_PAR>::reduce(lane_maximum);
}

template <int N>
softmax_accum_t row_exp_sum(const softmax_accum_t scores[N],
                            softmax_accum_t maximum,
                            softmax_accum_t exponentials[N]) {
    softmax_accum_t lane_sum[ATTENTION_PAR];
#pragma HLS ARRAY_PARTITION variable=lane_sum complete
initialize_exp_sum_lanes:
    for (int lane = 0; lane < ATTENTION_PAR; ++lane) {
#pragma HLS UNROLL
        lane_sum[lane] = 0.0f;
    }
row_exp_sum_groups:
    for (int base = 0; base < N; base += ATTENTION_PAR) {
#pragma HLS PIPELINE
    row_exp_sum_lanes:
        for (int lane = 0; lane < ATTENTION_PAR; ++lane) {
#pragma HLS UNROLL
            const int key = base + lane;
            const softmax_accum_t exponential =
                stable_exp(scores[key], maximum);
            exponentials[key] = exponential;
            lane_sum[lane] += exponential;
        }
    }
    return ParallelSumReducer<ATTENTION_PAR>::reduce(lane_sum);
}

inline softmax_accum_t safe_reciprocal(softmax_accum_t denominator) {
#pragma HLS INLINE
    return denominator > 0.0f ? 1.0f / denominator : 0.0f;
}

template <int N, int D>
void row_softmax_weighted_value(const softmax_accum_t scores[N],
                                const float values[N][D],
                                float context[D]) {
    softmax_accum_t exponentials[N];
#pragma HLS ARRAY_PARTITION variable=exponentials cyclic factor=ATTENTION_PAR
#pragma HLS ARRAY_PARTITION variable=values cyclic factor=ATTENTION_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=values cyclic factor=OUT_PAR dim=2
    const softmax_accum_t maximum = row_max<N>(scores);
    const softmax_accum_t sum = row_exp_sum<N>(scores, maximum, exponentials);
    const softmax_accum_t reciprocal = safe_reciprocal(sum);
weighted_value_dimension_groups:
    for (int base = 0; base < D; base += OUT_PAR) {
        softmax_accum_t partial[OUT_PAR][ATTENTION_PAR * SV_ACCUM_SLOTS];
#pragma HLS ARRAY_PARTITION variable=partial complete dim=0
    initialize_weighted_partials:
        for (int output_lane = 0; output_lane < OUT_PAR; ++output_lane) {
#pragma HLS UNROLL
        initialize_weighted_partial_lanes:
            for (int partial_lane = 0;
                 partial_lane < ATTENTION_PAR * SV_ACCUM_SLOTS;
                 ++partial_lane) {
#pragma HLS UNROLL
                partial[output_lane][partial_lane] = 0.0f;
            }
        }
    weighted_value_key_groups:
        for (int key_base = 0; key_base < N; key_base += ATTENTION_PAR) {
#pragma HLS PIPELINE II=1
            const int group = key_base / ATTENTION_PAR;
            const int slot = group % SV_ACCUM_SLOTS;
        weighted_value_output_lanes:
            for (int output_lane = 0; output_lane < OUT_PAR; ++output_lane) {
#pragma HLS UNROLL
            weighted_value_key_lanes:
                for (int key_lane = 0; key_lane < ATTENTION_PAR; ++key_lane) {
#pragma HLS UNROLL
                    const int key = key_base + key_lane;
                    const int dim = base + output_lane;
                    const int partial_lane = slot * ATTENTION_PAR + key_lane;
                    if (key < N && dim < D) {
                        const softmax_accum_t product =
                            exponentials[key] * values[key][dim];
                        partial[output_lane][partial_lane] += product;
                    }
                }
            }
        }
    finalize_weighted_value_lanes:
        for (int output_lane = 0; output_lane < OUT_PAR; ++output_lane) {
#pragma HLS UNROLL
            const int dim = base + output_lane;
            if (dim < D) {
                const softmax_accum_t numerator =
                    ParallelSumReducer<ATTENTION_PAR * SV_ACCUM_SLOTS>::reduce(
                        partial[output_lane]);
                context[dim] = numerator * reciprocal;
            }
        }
    }
}

}  // namespace bert

#endif
