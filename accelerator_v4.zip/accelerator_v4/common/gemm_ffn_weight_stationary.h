#ifndef BERT_GEMM_FFN_WEIGHT_STATIONARY_H
#define BERT_GEMM_FFN_WEIGHT_STATIONARY_H

#include "gemm_tiled.h"

namespace bert {

template <int LANES>
struct WeightStationaryReducer;

template <>
struct WeightStationaryReducer<8> {
    static accum_t reduce(const accum_t input[8]) {
#pragma HLS INLINE
        accum_t stage4[4];
        accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    ws_sum8_to4:
        for (int lane = 0; lane < 4; ++lane) {
#pragma HLS UNROLL
            stage4[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    ws_sum4_to2:
        for (int lane = 0; lane < 2; ++lane) {
#pragma HLS UNROLL
            stage2[lane] = stage4[lane * 2] + stage4[lane * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <>
struct WeightStationaryReducer<16> {
    static accum_t reduce(const accum_t input[16]) {
#pragma HLS INLINE
        accum_t stage8[8];
        accum_t stage4[4];
        accum_t stage2[2];
#pragma HLS ARRAY_PARTITION variable=stage8 complete
#pragma HLS ARRAY_PARTITION variable=stage4 complete
#pragma HLS ARRAY_PARTITION variable=stage2 complete
    ws_sum16_to8:
        for (int lane = 0; lane < 8; ++lane) {
#pragma HLS UNROLL
            stage8[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    ws_sum8_to4:
        for (int lane = 0; lane < 4; ++lane) {
#pragma HLS UNROLL
            stage4[lane] = stage8[lane * 2] + stage8[lane * 2 + 1];
        }
    ws_sum4_to2:
        for (int lane = 0; lane < 2; ++lane) {
#pragma HLS UNROLL
            stage2[lane] = stage4[lane * 2] + stage4[lane * 2 + 1];
        }
        return stage2[0] + stage2[1];
    }
};

template <>
struct WeightStationaryReducer<20> {
    static accum_t reduce(const accum_t input[20]) {
#pragma HLS INLINE
        accum_t stage10[10];
        accum_t stage5[5];
#pragma HLS ARRAY_PARTITION variable=stage10 complete
#pragma HLS ARRAY_PARTITION variable=stage5 complete
    ws_sum20_to10:
        for (int lane = 0; lane < 10; ++lane) {
#pragma HLS UNROLL
            stage10[lane] = input[lane * 2] + input[lane * 2 + 1];
        }
    ws_sum10_to5:
        for (int lane = 0; lane < 5; ++lane) {
#pragma HLS UNROLL
            stage5[lane] = stage10[lane * 2] + stage10[lane * 2 + 1];
        }
        const accum_t low = stage5[0] + stage5[1];
        const accum_t high = stage5[2] + stage5[3];
        return (low + high) + stage5[4];
    }
};

template <int M, int N, int OUTPUT_PAR>
void clear_full_output(float output[M][N]) {
clear_full_output_rows:
    for (int row = 0; row < M; ++row) {
    clear_full_output_groups:
        for (int output_base = 0; output_base < N; output_base += OUTPUT_PAR) {
#pragma HLS PIPELINE II=1
        clear_full_output_lanes:
            for (int lane = 0; lane < OUTPUT_PAR; ++lane) {
#pragma HLS UNROLL
                const int output = output_base + lane;
                if (output < N) {
                    output[row][output] = 0.0f;
                }
            }
        }
    }
}

template <int M, int K, int N, int TK, int TN, int MAC_PAR, int OUTPUT_PAR>
void accumulate_weight_tile_full_rows(const float input[M][K],
                                      const float weight[TK][TN],
                                      int input_base,
                                      int output_base,
                                      float output[M][N]) {
accumulate_full_input_groups:
    for (int input_group = 0; input_group < TK; input_group += MAC_PAR) {
    accumulate_full_output_groups:
        for (int local_output_base = 0;
             local_output_base < TN;
             local_output_base += OUTPUT_PAR) {
        accumulate_full_rows:
            for (int row = 0; row < M; ++row) {
#pragma HLS PIPELINE II=1
            accumulate_full_output_lanes:
                for (int output_lane = 0; output_lane < OUTPUT_PAR;
                     ++output_lane) {
#pragma HLS UNROLL
                    const int local_output = local_output_base + output_lane;
                    const int global_output = output_base + local_output;
                    accum_t products[MAC_PAR];
#pragma HLS ARRAY_PARTITION variable=products complete
                accumulate_full_mac_lanes:
                    for (int mac_lane = 0; mac_lane < MAC_PAR;
                         ++mac_lane) {
#pragma HLS UNROLL
                        const int local_input = input_group + mac_lane;
                        const int global_input = input_base + local_input;
                        if (global_input < K && global_output < N &&
                            local_output < TN) {
                            products[mac_lane] = input[row][global_input]
                                               * weight[local_input][local_output];
                        } else {
                            products[mac_lane] = 0.0f;
                        }
                    }
                    if (global_output < N && local_output < TN) {
                        output[row][global_output] +=
                            WeightStationaryReducer<MAC_PAR>::reduce(products);
                    }
                }
            }
        }
    }
}

template <int M, int N, int TN, int OUTPUT_PAR>
void add_full_output_bias(float output[M][N],
                          const axi_word_t* parameters,
                          offset_t bias_word_offset) {
add_full_bias_tiles:
    for (int output_base = 0; output_base < N; output_base += TN) {
        float bias_tile[TN];
#pragma HLS ARRAY_PARTITION variable=bias_tile cyclic factor=OUTPUT_PAR
        load_bias_tile<TN>(parameters, bias_word_offset, output_base, bias_tile);
    add_full_bias_rows:
        for (int row = 0; row < M; ++row) {
        add_full_bias_groups:
            for (int local_output_base = 0;
                 local_output_base < TN;
                 local_output_base += OUTPUT_PAR) {
#pragma HLS PIPELINE II=1
            add_full_bias_lanes:
                for (int lane = 0; lane < OUTPUT_PAR; ++lane) {
#pragma HLS UNROLL
                    const int local_output = local_output_base + lane;
                    const int global_output = output_base + local_output;
                    if (local_output < TN && global_output < N) {
                        output[row][global_output] += bias_tile[local_output];
                    }
                }
            }
        }
    }
}

template <int M, int K, int N, int TK, int TN, int MAC_PAR, int OUTPUT_PAR>
void gemm_ffn_weight_stationary(const float input[M][K],
                                const axi_word_t* weights,
                                offset_t matrix_word_offset,
                                const axi_word_t* parameters,
                                offset_t bias_word_offset,
                                float output[M][N]) {
    float weight_tile[TK][TN];
#pragma HLS ARRAY_PARTITION variable=weight_tile cyclic factor=OUTPUT_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=weight_tile cyclic factor=MAC_PAR dim=1

    clear_full_output<M, N, OUTPUT_PAR>(output);
ffn_weight_output_tiles:
    for (int output_base = 0; output_base < N; output_base += TN) {
    ffn_weight_input_tiles:
        for (int input_base = 0; input_base < K; input_base += TK) {
            load_weight_tile<K, N, TK, TN>(
                weights, matrix_word_offset, input_base, output_base, weight_tile);
            accumulate_weight_tile_full_rows<M, K, N, TK, TN,
                                             MAC_PAR, OUTPUT_PAR>(
                input, weight_tile, input_base, output_base, output);
        }
    }
    add_full_output_bias<M, N, TN, OUTPUT_PAR>(
        output, parameters, bias_word_offset);
}

}  // namespace bert

#endif
