#ifndef BERT_GELU_HLS_H
#define BERT_GELU_HLS_H

#include "math_utils_hls.h"

namespace bert {

inline float gelu_exact_source_formula(float x) {
#pragma HLS INLINE
    const float sqrt_2_over_pi = 0.7978845608028654f;
    const float x3 = x * x * x;
    const float inner = sqrt_2_over_pi * (x + 0.044715f * x3);
    return 0.5f * x * (1.0f + exact_tanh(inner));
}

template <int N>
void gelu_vector(float values[N]) {
gelu_vector_groups:
    for (int base = 0; base < N; base += FFN_GELU_PAR) {
#pragma HLS PIPELINE II=1
    gelu_vector_lanes:
        for (int lane = 0; lane < FFN_GELU_PAR; ++lane) {
#pragma HLS UNROLL
            const int index = base + lane;
            if (index < N) {
                values[index] = gelu_exact_source_formula(values[index]);
            }
        }
    }
}

}  // namespace bert

#endif
