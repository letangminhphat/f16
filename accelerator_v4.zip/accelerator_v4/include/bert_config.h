#ifndef BERT_CONFIG_H
#define BERT_CONFIG_H

#include "../config/build_profiles.h"

namespace bert {

// Forced deployment profile: standard BERT-Base, batch 1, sequence length 128.
static const int BATCH_SIZE = 1;
static const int SEQ_LEN = 128;
static const int HIDDEN_SIZE = 768;
static const int NUM_HEADS = 12;
static const int HEAD_DIM = 64;
static const int FFN_INTERMEDIATE = 3072;
static const int NUM_LAYERS = 12;

// Standard BERT-Base metadata; encoder kernels still accept hidden input directly.
static const int VOCAB_SIZE = 30522;
static const int MAX_POSITION = 512;
static const int TYPE_VOCAB_SIZE = 2;

static const float LAYERNORM_EPSILON = 1.0e-12f;
static const float ATTENTION_NEGATIVE_MASK = -10000.0f;

static const int AXI_BITS = 512;
static const int SCALAR_BITS = 32;
static const int AXI_LANES = AXI_BITS / SCALAR_BITS;

static const int TILE_M = BERT_PROFILE_TILE_M;
static const int TILE_K = BERT_PROFILE_TILE_K;
static const int TILE_N = BERT_PROFILE_TILE_N;
static const int MAC_LANES = BERT_PROFILE_MAC_LANES;
static const int OUT_PAR = BERT_PROFILE_OUT_PAR;
static const int HEAD_PAR = BERT_PROFILE_HEAD_PAR;
static const int QK_KEY_PAR = BERT_PROFILE_QK_KEY_PAR;
static const int ATTENTION_PAR = BERT_PROFILE_ATTENTION_PAR;
static const int SV_ACCUM_SLOTS = 4;
static const int FFN_MAC_LANES = BERT_PROFILE_FFN_MAC_LANES;
static const int FFN_OUT_PAR = BERT_PROFILE_FFN_OUT_PAR;
static const int FFN_GELU_PAR = BERT_PROFILE_FFN_GELU_PAR;
static const int FIFO_DEPTH = BERT_PROFILE_FIFO_DEPTH;

static_assert(BATCH_SIZE == 1, "The audited C entry point has one sample");
static_assert(HIDDEN_SIZE == NUM_HEADS * HEAD_DIM,
              "Hidden size must equal heads times head dimension");
static_assert(AXI_BITS % SCALAR_BITS == 0, "AXI words must contain whole scalars");
static_assert(HIDDEN_SIZE % AXI_LANES == 0,
              "Hidden rows must align to 512-bit stream words");
static_assert(HEAD_DIM % AXI_LANES == 0,
              "Head rows must align to 512-bit stream words");
static_assert(FFN_INTERMEDIATE % AXI_LANES == 0,
              "FFN rows must align to 512-bit stream words");
static_assert(TILE_M > 0 && TILE_K > 0 && TILE_N > 0, "Tiles must be positive");
static_assert(MAC_LANES > 0 && OUT_PAR > 0 && HEAD_PAR > 0,
              "Parallel factors must be positive");
static_assert(HEAD_PAR == 1 || HEAD_PAR == 2,
              "Attention head parallelism supports one or two heads");
static_assert(NUM_HEADS % HEAD_PAR == 0,
              "Head parallelism must divide the number of heads");
static_assert(MAC_LANES == 8 || MAC_LANES == 16,
              "QK reduction supports 8 or 16 MAC lanes");
static_assert(QK_KEY_PAR == 2 || QK_KEY_PAR == 4 || QK_KEY_PAR == 8,
              "QK key parallelism supports 2, 4, or 8 lanes");
static_assert(ATTENTION_PAR == 2 || ATTENTION_PAR == 4,
              "Softmax/SV parallelism supports 2 or 4 lanes");
static_assert(SEQ_LEN % QK_KEY_PAR == 0 && SEQ_LEN % ATTENTION_PAR == 0,
              "Attention parallel factors must divide the sequence length");
static_assert((ATTENTION_PAR * SV_ACCUM_SLOTS == 8) ||
              (ATTENTION_PAR * SV_ACCUM_SLOTS == 16),
              "SV reduction supports 8 or 16 partial sums");
static_assert(FFN_MAC_LANES == 8 || FFN_MAC_LANES == 16 ||
              FFN_MAC_LANES == 20,
              "FFN MAC parallelism supports 8, 16, or 20 lanes");
static_assert(FFN_OUT_PAR == 8 || FFN_OUT_PAR == 16,
              "FFN output parallelism supports 8 or 16 lanes");
static_assert(FFN_GELU_PAR == 2 || FFN_GELU_PAR == 4 || FFN_GELU_PAR == 8,
              "FFN GELU parallelism supports 2, 4, or 8 lanes");
static_assert(TILE_K % MAC_LANES == 0, "TILE_K must be divisible by MAC_LANES");
static_assert(TILE_N % OUT_PAR == 0, "TILE_N must be divisible by OUT_PAR");
static_assert(SEQ_LEN % TILE_M == 0, "Sequence length must align to TILE_M");
static_assert(HIDDEN_SIZE % TILE_K == 0 && HIDDEN_SIZE % TILE_N == 0,
              "Hidden size must align to the shared GEMM tiles");
static_assert(BERT_FFN_UP_TILE_K % FFN_MAC_LANES == 0,
              "FFN UP TILE_K must align to FFN MAC lanes");
static_assert(BERT_FFN_UP_TILE_N % FFN_OUT_PAR == 0,
              "FFN UP TILE_N must align to FFN output lanes");
static_assert(BERT_FFN_DOWN_TILE_K % FFN_MAC_LANES == 0,
              "FFN DOWN TILE_K must align to FFN MAC lanes");
static_assert(BERT_FFN_DOWN_TILE_N % FFN_OUT_PAR == 0,
              "FFN DOWN TILE_N must align to FFN output lanes");
static_assert(FFN_INTERMEDIATE % BERT_FFN_UP_TILE_N == 0,
              "FFN size must align to FFN UP output tiles");
static_assert(HIDDEN_SIZE % BERT_FFN_DOWN_TILE_N == 0,
              "Hidden size must align to FFN DOWN output tiles");

}  // namespace bert

#endif
