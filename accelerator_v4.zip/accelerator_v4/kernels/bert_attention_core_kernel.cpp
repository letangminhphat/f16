#include "gemm_act_act.h"
#include "math_utils_hls.h"
#include "packed_io.h"
#include "softmax_hls.h"
#include "stream_contracts.h"

using namespace bert;

/*
Architecture basis:
- Spatial FPGA: attention has a dedicated A-A engine and a FIFO boundary.
- AutoTrans: exact row-fused QK/softmax/SV without score or probability DDR traffic.
- ProTEA/Tiled QKV/UbiMoE: Q row residence, K/V reuse, and fused exp-times-V numerator.

U250 adaptation:
- Banked K/V buffers feed parallel QK keys and parallel softmax/SV lanes on SLR1.
*/
extern "C" void bert_attention_core_kernel(
    const axi_word_t* attention_mask,
    tensor_stream_t& q_in,
    tensor_stream_t& k_in,
    tensor_stream_t& v_in,
    tensor_stream_t& context_out,
    offset_t mask_word_offset,
    unsigned int active_sequence_length,
    unsigned int layer_index) {
#pragma HLS INTERFACE m_axi port=attention_mask offset=slave bundle=gmem_act \
    max_read_burst_length=16 num_read_outstanding=4
#pragma HLS INTERFACE axis port=q_in
#pragma HLS INTERFACE axis port=k_in
#pragma HLS INTERFACE axis port=v_in
#pragma HLS INTERFACE axis port=context_out
#pragma HLS INTERFACE s_axilite port=attention_mask bundle=control
#pragma HLS INTERFACE s_axilite port=mask_word_offset bundle=control
#pragma HLS INTERFACE s_axilite port=active_sequence_length bundle=control
#pragma HLS INTERFACE s_axilite port=layer_index bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    float query[NUM_HEADS][SEQ_LEN][HEAD_DIM];
    float key[NUM_HEADS][SEQ_LEN][HEAD_DIM];
    float value[NUM_HEADS][SEQ_LEN][HEAD_DIM];
    float mask[SEQ_LEN];
    float context[SEQ_LEN][HIDDEN_SIZE];
#pragma HLS BIND_STORAGE variable=query type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=key type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=value type=ram_2p impl=bram
#pragma HLS ARRAY_PARTITION variable=query cyclic factor=HEAD_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=query cyclic factor=AXI_LANES dim=3
#pragma HLS ARRAY_PARTITION variable=key cyclic factor=HEAD_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=key cyclic factor=QK_KEY_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=key cyclic factor=AXI_LANES dim=3
#pragma HLS ARRAY_PARTITION variable=value cyclic factor=HEAD_PAR dim=1
#pragma HLS ARRAY_PARTITION variable=value cyclic factor=ATTENTION_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=value cyclic factor=AXI_LANES dim=3
#pragma HLS ARRAY_PARTITION variable=mask cyclic factor=QK_KEY_PAR
#pragma HLS ARRAY_PARTITION variable=context cyclic factor=AXI_LANES dim=2

    stream_read_head_tensor(q_in, query);
    stream_read_head_tensor(k_in, key);
    stream_read_head_tensor(v_in, value);
    load_packed_vector<SEQ_LEN>(attention_mask, mask_word_offset, mask);

    const unsigned int active_length =
        active_sequence_length > static_cast<unsigned int>(SEQ_LEN)
            ? static_cast<unsigned int>(SEQ_LEN)
            : active_sequence_length;
    const float scale = 1.0f / exact_sqrt(static_cast<float>(HEAD_DIM));

attention_head_groups:
    for (int head_base = 0; head_base < NUM_HEADS; head_base += HEAD_PAR) {
    attention_query_rows:
        for (int query_token = 0; query_token < SEQ_LEN; ++query_token) {
            softmax_accum_t scores[HEAD_PAR][SEQ_LEN];
            float context_row[HEAD_PAR][HEAD_DIM];
#pragma HLS BIND_STORAGE variable=scores type=ram_1p impl=bram
#pragma HLS ARRAY_PARTITION variable=scores complete dim=1
#pragma HLS ARRAY_PARTITION variable=scores cyclic factor=QK_KEY_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=context_row complete dim=1
#pragma HLS ARRAY_PARTITION variable=context_row cyclic factor=OUT_PAR dim=2

        attention_parallel_heads:
            for (int head_lane = 0; head_lane < HEAD_PAR; ++head_lane) {
#pragma HLS UNROLL
                const int head = head_base + head_lane;
                // Pass 1 computes exact scaled/masked scores and the softmax maximum.
                qk_row<SEQ_LEN, HEAD_DIM>(
                    query[head][query_token], key[head], mask,
                    active_length, scale, scores[head_lane]);
                // Pass 2 computes exact exp/sum and accumulates exp(score-max) * V.
                row_softmax_weighted_value<SEQ_LEN, HEAD_DIM>(
                    scores[head_lane], value[head], context_row[head_lane]);
            }
        write_context_heads:
            for (int head_lane = 0; head_lane < HEAD_PAR; ++head_lane) {
                const int head = head_base + head_lane;
        write_context_groups:
                for (int base = 0; base < HEAD_DIM; base += OUT_PAR) {
#pragma HLS PIPELINE II=1
            write_context_lanes:
                    for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
                        const int dim = base + lane;
                        if (dim < HEAD_DIM) {
                            context[query_token][head * HEAD_DIM + dim] =
                                context_row[head_lane][dim];
                        }
                    }
                }
            }
        }
    }

    (void)layer_index;  // The mask is layer-invariant; retained for launch symmetry.
    stream_write_matrix<SEQ_LEN, HIDDEN_SIZE>(context, context_out);
}
