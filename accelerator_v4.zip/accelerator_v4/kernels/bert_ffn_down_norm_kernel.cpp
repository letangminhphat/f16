#include "bert_kernel_args.h"
#include "gemm_ffn_weight_stationary.h"
#include "layernorm_hls.h"
#include "packed_io.h"
#include "residual_hls.h"
#include "stream_contracts.h"

using namespace bert;

/*
Architecture basis:
- Spatial FPGA: FFN DOWN/AddNorm terminates the layer and writes only final hidden state.
- AutoTrans: major linear and AddNorm operations are fused without fine-grained kernels.
- ProTEA/Tiled QKV/UbiMoE: asymmetric FFN tiling, row buffering, and activation ping-pong.

U250 adaptation:
- Candidate SLR3 and DDR3 weights; output returns to DDR0 for layer-to-layer ping-pong.
*/
extern "C" void bert_ffn_down_norm_kernel(
    const axi_word_t* w2_weights,
    const axi_word_t* ffn_down_parameters,
    axi_word_t* hidden_out,
    tensor_stream_t& ffn_intermediate_in,
    tensor_stream_t& ffn_residual_in,
    offset_t output_word_offset,
    offset_t w2_base_word,
    offset_t w2_layer_stride_words,
    offset_t b2_base_word,
    offset_t gamma_base_word,
    offset_t beta_base_word,
    offset_t parameter_layer_stride_words,
    unsigned int layer_index) {
#pragma HLS INTERFACE m_axi port=w2_weights offset=slave bundle=gmem_w2 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=ffn_down_parameters offset=slave bundle=gmem_w2 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=hidden_out offset=slave bundle=gmem_act \
    max_write_burst_length=64 num_write_outstanding=16
#pragma HLS INTERFACE axis port=ffn_intermediate_in
#pragma HLS INTERFACE axis port=ffn_residual_in
#pragma HLS INTERFACE s_axilite port=w2_weights bundle=control
#pragma HLS INTERFACE s_axilite port=ffn_down_parameters bundle=control
#pragma HLS INTERFACE s_axilite port=hidden_out bundle=control
#pragma HLS INTERFACE s_axilite port=output_word_offset bundle=control
#pragma HLS INTERFACE s_axilite port=w2_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=w2_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=b2_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=gamma_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=beta_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=parameter_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=layer_index bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    float intermediate[SEQ_LEN][FFN_INTERMEDIATE];
    float residual[SEQ_LEN][HIDDEN_SIZE];
    float projection[SEQ_LEN][HIDDEN_SIZE];
    float output[SEQ_LEN][HIDDEN_SIZE];
    float gamma_cache[HIDDEN_SIZE];
    float beta_cache[HIDDEN_SIZE];
#pragma HLS BIND_STORAGE variable=intermediate type=ram_2p impl=uram
#pragma HLS BIND_STORAGE variable=residual type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=projection type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=output type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=gamma_cache type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=beta_cache type=ram_2p impl=bram
#pragma HLS ARRAY_PARTITION variable=intermediate cyclic factor=FFN_MAC_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=residual cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=projection cyclic factor=FFN_OUT_PAR dim=2
#pragma HLS ARRAY_PARTITION variable=output cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=gamma_cache cyclic factor=AXI_LANES
#pragma HLS ARRAY_PARTITION variable=beta_cache cyclic factor=AXI_LANES

    // Consume the FFN result before the residual to match upstream production.
    stream_read_matrix<SEQ_LEN, FFN_INTERMEDIATE>(
        ffn_intermediate_in, intermediate);
    stream_read_matrix<SEQ_LEN, HIDDEN_SIZE>(ffn_residual_in, residual);

    const offset_t w2_word = layer_word_offset(
        w2_base_word, w2_layer_stride_words, layer_index);
    const offset_t b2_word = layer_word_offset(
        b2_base_word, parameter_layer_stride_words, layer_index);
    const offset_t gamma_word = layer_word_offset(
        gamma_base_word, parameter_layer_stride_words, layer_index);
    const offset_t beta_word = layer_word_offset(
        beta_base_word, parameter_layer_stride_words, layer_index);

    load_layernorm_parameters<HIDDEN_SIZE>(
        ffn_down_parameters, gamma_word, beta_word, gamma_cache, beta_cache);

    gemm_ffn_weight_stationary<SEQ_LEN, FFN_INTERMEDIATE, HIDDEN_SIZE,
                               BERT_FFN_DOWN_TILE_K, BERT_FFN_DOWN_TILE_N,
                               FFN_MAC_LANES, FFN_OUT_PAR>(
        intermediate, w2_weights, w2_word,
        ffn_down_parameters, b2_word, projection);

ffn_down_addnorm_tokens:
    for (int token = 0; token < SEQ_LEN; ++token) {
        float added[HIDDEN_SIZE];
#pragma HLS ARRAY_PARTITION variable=added cyclic factor=OUT_PAR
        residual_add_token<HIDDEN_SIZE>(projection[token], residual[token], added);
        layernorm_token_cached<HIDDEN_SIZE>(
            added, gamma_cache, beta_cache, output[token]);
    }
    store_packed_matrix<SEQ_LEN, HIDDEN_SIZE>(hidden_out, output_word_offset, output);
}
