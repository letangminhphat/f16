# accelerator_v3 attention optimization

## Scope

The complete attention pipeline is covered:

1. Q, K, and V projections in `bert_qkv_kernel`.
2. Scaled QK, mask, stable softmax, and weighted V in
   `bert_attention_core_kernel`.
3. Wo projection, residual addition, and LayerNorm in
   `bert_attention_output_norm_kernel`.

The kernel interfaces, tensor order, 512-bit streams, FP32 datatype, mask value,
softmax definition, residual path, LayerNorm epsilon, and BERT-Base dimensions
remain unchanged.

## Report-driven changes

The v2 attention core used only 71 DSP while taking 24,702,056 cycles. About
14,464 of 16,066 cycles per query row were spent in QK. The performance profile
therefore uses two concurrent heads and eight concurrent QK keys per head. Q/K/V
are banked across head lanes; K is additionally banked across key lanes and the
existing 16 feature lanes.

The row maximum and exponential sum now process four scores concurrently. SV
processes four keys and 16 output dimensions concurrently. Four rotating FP32
accumulator slots break the immediate recurrence; a balanced 16-input tree
combines them after each dimension group.

QKV and Wo use the v3 weight-stationary GEMM path and reuse every weight tile
across all 128 tokens. AddNorm keeps the existing cached/vectorized
implementation because its v2 latency is small relative to projection and QK.

## Expected effect and verification boundary

The QK key trip count is structurally reduced from 128 scalar keys to 16 groups
per head in the default profile, while the head trip count is reduced from 12 to
6 groups. Softmax/SV key group counts are reduced by four. These are structural
targets, not measured latency claims. A fresh csynth report must confirm achieved
II, DSP/BRAM growth, clock timing, and whether the SLR1 resource budget remains
valid. No build or synthesis was run while creating this source.
