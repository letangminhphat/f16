# U250 candidate kernel mapping

This is a pre-route candidate, not a measured placement claim.

| Kernel | Candidate SLR | Input stream(s) | Output stream(s) | DDR dependency | Post-link checks |
|---|---|---|---|---|---|
| `bert_qkv_kernel` | SLR0 | hidden from DDR0 | Q, K, V, residual-A | DDR0 input; DDR1 QKV weights/parameters | Shares SLR0 compute/BRAM budget with FFN DOWN |
| `bert_attention_core_kernel` | SLR1 | Q, K, V | context | DDR0 mask | K/V BRAM, exp/div latency, stream stalls |
| `bert_attention_output_norm_kernel` | SLR2 | context, residual-A | FFN input, residual-B | DDR2 Wo/parameters | 1056 measured BRAM requires a dedicated SLR |
| `bert_ffn_up_gelu_kernel` | SLR3 | FFN input | FFN intermediate | DDR2 W1/parameters | Dedicated SLR for the enlarged FFN datapath and parallel GELU |
| `bert_ffn_down_norm_kernel` | SLR0 | FFN intermediate, residual-B | hidden to DDR0 | DDR3 W2/parameters; DDR0 output | Must fit beside QKV; validate DSP, BRAM, SLL crossings, and DDR0 locality |

The physical stream path is SLR0 → SLR1 → SLR2 → SLR3 → SLR0. The long
bypass streams are residual-A (SLR0→SLR2) and residual-B (SLR2→SLR0).
After link, verify `report_utilization -slr`, timing/WNS/TNS, route status,
congestion, SLL crossings, DDR-port contention, and actual bank-to-SLR locality.

This mapping keeps the BRAM-heavy attention core and attention output on
dedicated SLR1/SLR2. The enlarged FFN UP datapath receives SLR3. FFN DOWN moves
to SLR0 beside QKV because its estimated scaled DSP plus QKV remains near, but
below, one quarter of the U250 device total; only post-link utilization can
confirm that estimate and routing feasibility.
