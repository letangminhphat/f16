# accelerator_v3 FFN optimization

## Changes

- FFN UP and FFN DOWN use a weight-stationary traversal. A weight tile is loaded
  once and reused for all 128 tokens instead of being reloaded for each row tile.
- The performance profile uses 20 FP32 MAC lanes and 16 output lanes, or 320
  products per compute row cycle, compared with 256 in the measured v2 profile.
- The performance input tile is 160×32. The existing zero-padded tile-major
  layout handles the 768 and 3072 input tails without changing logical shapes.
- GELU evaluates eight elements concurrently instead of one.
- FFN DOWN moves to candidate SLR0 beside QKV; FFN UP receives candidate SLR3.

The W1/W2 equations, FP32 datatype, tanh GELU formula, residual, LayerNorm,
kernel interfaces, and output shapes are unchanged.

## Verification and the 100 ms target

The measured v2 FFN kernels total 26,600,371 cycles per layer. The new loop
structure removes repeated weight loads and increases arithmetic parallelism,
but no new latency/resource result is claimed before csynth.

At the existing 5 ns target, an exact FP32 12-layer latency below 100 ms cannot
be guaranteed by source changes alone. The new reports must establish each
kernel's achieved latency and the post-link critical path. If the complete
12-layer result remains above 100 ms, meeting that bound requires an additional
architectural change such as a shared/fused wider FFN engine, reduced precision,
or more device-level compute; silently changing FP32 was intentionally avoided.
