file mkdir xo

open_project build_qkv_hls
open_solution solution1
export_design -format xo -output xo/bert_qkv_kernel.xo
close_project

open_project build_attention_hls
open_solution solution1
export_design -format xo -output xo/bert_attention_core_kernel.xo
close_project

open_project build_attention_output_hls
open_solution solution1
export_design -format xo -output xo/bert_attention_output_norm_kernel.xo
close_project

open_project build_ffn_up_hls
open_solution solution1
export_design -format xo -output xo/bert_ffn_up_gelu_kernel.xo
close_project

open_project build_ffn_down_hls
open_solution solution1
export_design -format xo -output xo/bert_ffn_down_norm_kernel.xo
close_project

exit
