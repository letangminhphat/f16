#ifndef BERT_RESIDUAL_HLS_H
#define BERT_RESIDUAL_HLS_H

#include "bert_types.h"

namespace bert {

template <int N>
void residual_add_token(const float projection[N],
                        const float residual[N],
                        float result[N]) {
residual_add_groups:
    for (int base = 0; base < N; base += AXI_LANES) {
#pragma HLS PIPELINE II=1
    residual_add_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int hidden = base + lane;
            if (hidden < N) {
                result[hidden] = projection[hidden] + residual[hidden];
            }
        }
    }
}

}  // namespace bert

#endif
