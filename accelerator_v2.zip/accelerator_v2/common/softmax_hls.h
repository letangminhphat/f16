#ifndef BERT_SOFTMAX_HLS_H
#define BERT_SOFTMAX_HLS_H

#include "math_utils_hls.h"

namespace bert {

inline softmax_accum_t stable_exp(softmax_accum_t score,
                                  softmax_accum_t maximum) {
#pragma HLS INLINE
    return exact_exp(score - maximum);
}

template <int N>
softmax_accum_t row_max(const softmax_accum_t scores[N]) {
    softmax_accum_t maximum = scores[0];
row_max_loop:
    for (int key = 1; key < N; ++key) {
#pragma HLS PIPELINE II=1
        maximum = scores[key] > maximum ? scores[key] : maximum;
    }
    return maximum;
}

template <int N>
softmax_accum_t row_exp_sum(const softmax_accum_t scores[N],
                            softmax_accum_t maximum,
                            softmax_accum_t exponentials[N]) {
    softmax_accum_t sum = 0.0f;
row_exp_sum_loop:
    for (int key = 0; key < N; ++key) {
#pragma HLS PIPELINE II=1
        const softmax_accum_t exponential = stable_exp(scores[key], maximum);
        exponentials[key] = exponential;
        sum += exponential;
    }
    return sum;
}

inline softmax_accum_t safe_reciprocal(softmax_accum_t denominator) {
#pragma HLS INLINE
    return denominator > 0.0f ? 1.0f / denominator : 0.0f;
}

template <int N, int D>
void row_softmax_weighted_value(const softmax_accum_t scores[N],
                                const float values[N][D],
                                float context[D]) {
    softmax_accum_t exponentials[N];
#pragma HLS BIND_STORAGE variable=exponentials type=ram_1p impl=bram
    const softmax_accum_t maximum = row_max<N>(scores);
    const softmax_accum_t sum = row_exp_sum<N>(scores, maximum, exponentials);
    const softmax_accum_t reciprocal = safe_reciprocal(sum);
initialize_context_groups:
    for (int base = 0; base < D; base += OUT_PAR) {
#pragma HLS PIPELINE II=1
    initialize_context_lanes:
        for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
            const int dim = base + lane;
            if (dim < D) {
                context[dim] = 0.0f;
            }
        }
    }
weighted_value_keys:
    for (int key = 0; key < N; ++key) {
    weighted_value_groups:
        for (int base = 0; base < D; base += OUT_PAR) {
#pragma HLS PIPELINE II=1
        weighted_value_lanes:
            for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
                const int dim = base + lane;
                if (dim < D) {
                    const softmax_accum_t product =
                        exponentials[key] * values[key][dim];
                    context[dim] += product;
                }
            }
        }
    }
normalize_context_groups:
    for (int base = 0; base < D; base += OUT_PAR) {
#pragma HLS PIPELINE II=1
    normalize_context_lanes:
        for (int lane = 0; lane < OUT_PAR; ++lane) {
#pragma HLS UNROLL
            const int dim = base + lane;
            if (dim < D) {
                context[dim] *= reciprocal;
            }
        }
    }
}

}  // namespace bert

#endif
