#ifndef BERT_BIAS_HLS_H
#define BERT_BIAS_HLS_H

#include "packed_io.h"

namespace bert {

inline bias_t load_bias_value(const axi_word_t* parameters,
                              offset_t bias_word_offset,
                              int output_index) {
#pragma HLS INLINE
    return load_packed_scalar(parameters, bias_word_offset, output_index);
}

template <int N>
void load_bias_tile(const axi_word_t* parameters,
                    offset_t bias_word_offset,
                    int output_base,
                    float bias_tile[N]) {
    static_assert(N % AXI_LANES == 0,
                  "Bias tiles must contain whole 512-bit words");
load_bias_words:
    for (int word = 0; word < N / AXI_LANES; ++word) {
#pragma HLS PIPELINE II=1
        float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        unpack_scalar_array(
            parameters[bias_word_offset + output_base / AXI_LANES + word],
            lanes);
    load_bias_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            bias_tile[word * AXI_LANES + lane] = lanes[lane];
        }
    }
}

template <int N>
void add_bias_vector(float values[N],
                     const axi_word_t* parameters,
                     offset_t bias_word_offset) {
add_bias_vector_loop:
    for (int index = 0; index < N; ++index) {
#pragma HLS PIPELINE II=1
        values[index] += load_bias_value(parameters, bias_word_offset, index);
    }
}

}  // namespace bert

#endif
