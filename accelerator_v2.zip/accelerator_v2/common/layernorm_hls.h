#ifndef BERT_LAYERNORM_HLS_H
#define BERT_LAYERNORM_HLS_H

#include "math_utils_hls.h"
#include "packed_io.h"

namespace bert {

template <int N>
void load_layernorm_parameters(const axi_word_t* parameters,
                               offset_t gamma_word_offset,
                               offset_t beta_word_offset,
                               float gamma[N],
                               float beta[N]) {
    load_packed_vector<N>(parameters, gamma_word_offset, gamma);
    load_packed_vector<N>(parameters, beta_word_offset, beta);
}

template <int N>
layernorm_accum_t compute_mean(const float token[N]) {
    layernorm_accum_t partial[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=partial complete
initialize_mean_partial:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
        partial[lane] = 0.0f;
    }
compute_mean_groups:
    for (int base = 0; base < N; base += AXI_LANES) {
#pragma HLS PIPELINE
    compute_mean_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int index = base + lane;
            if (index < N) {
                partial[lane] += token[index];
            }
        }
    }
    layernorm_accum_t sum = 0.0f;
reduce_mean_partial:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS PIPELINE
        sum += partial[lane];
    }
    return sum / static_cast<float>(N);
}

template <int N>
layernorm_accum_t compute_variance(const float token[N],
                                   layernorm_accum_t mean) {
    layernorm_accum_t partial[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=partial complete
initialize_variance_partial:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
        partial[lane] = 0.0f;
    }
compute_variance_groups:
    for (int base = 0; base < N; base += AXI_LANES) {
#pragma HLS PIPELINE
    compute_variance_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int index = base + lane;
            if (index < N) {
                const layernorm_accum_t difference = token[index] - mean;
                partial[lane] += difference * difference;
            }
        }
    }
    layernorm_accum_t sum = 0.0f;
reduce_variance_partial:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS PIPELINE
        sum += partial[lane];
    }
    return sum / static_cast<float>(N);
}

template <int N>
void normalize_affine(const float token[N],
                      layernorm_accum_t mean,
                      layernorm_accum_t variance,
                      const axi_word_t* parameters,
                      offset_t gamma_word_offset,
                      offset_t beta_word_offset,
                      float output[N]) {
    const layernorm_accum_t inverse_std =
        1.0f / exact_sqrt(variance + LAYERNORM_EPSILON);
normalize_affine_loop:
    for (int index = 0; index < N; ++index) {
#pragma HLS PIPELINE II=1
        const float gamma = load_packed_scalar(parameters, gamma_word_offset, index);
        const float beta = load_packed_scalar(parameters, beta_word_offset, index);
        output[index] = gamma * (token[index] - mean) * inverse_std + beta;
    }
}

template <int N>
void normalize_affine_cached(const float token[N],
                             layernorm_accum_t mean,
                             layernorm_accum_t variance,
                             const float gamma[N],
                             const float beta[N],
                             float output[N]) {
    const layernorm_accum_t inverse_std =
        1.0f / exact_sqrt(variance + LAYERNORM_EPSILON);
normalize_affine_cached_groups:
    for (int base = 0; base < N; base += AXI_LANES) {
#pragma HLS PIPELINE II=1
    normalize_affine_cached_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int index = base + lane;
            if (index < N) {
                output[index] =
                    gamma[index] * (token[index] - mean) * inverse_std + beta[index];
            }
        }
    }
}

template <int N>
void layernorm_token(const float token[N],
                     const axi_word_t* parameters,
                     offset_t gamma_word_offset,
                     offset_t beta_word_offset,
                     float output[N]) {
    const layernorm_accum_t mean = compute_mean<N>(token);
    const layernorm_accum_t variance = compute_variance<N>(token, mean);
    normalize_affine<N>(token, mean, variance, parameters,
                        gamma_word_offset, beta_word_offset, output);
}

template <int N>
void layernorm_token_cached(const float token[N],
                            const float gamma[N],
                            const float beta[N],
                            float output[N]) {
    const layernorm_accum_t mean = compute_mean<N>(token);
    const layernorm_accum_t variance = compute_variance<N>(token, mean);
    normalize_affine_cached<N>(token, mean, variance, gamma, beta, output);
}

}  // namespace bert

#endif
