#ifndef BERT_KERNEL_ARGS_H
#define BERT_KERNEL_ARGS_H

#include "bert_types.h"

namespace bert {

// All offsets and strides are in 512-bit words, never bytes or FP32 elements.
struct LayerBufferContract {
    offset_t base_word;
    offset_t layer_stride_words;
};

struct QkvOffsetContract {
    LayerBufferContract wq;
    LayerBufferContract wk;
    LayerBufferContract wv;
    LayerBufferContract bq;
    LayerBufferContract bk;
    LayerBufferContract bv;
};

struct AttentionOutputOffsetContract {
    LayerBufferContract wo;
    LayerBufferContract bo;
    LayerBufferContract gamma;
    LayerBufferContract beta;
};

struct FfnUpOffsetContract {
    LayerBufferContract w1;
    LayerBufferContract b1;
};

struct FfnDownOffsetContract {
    LayerBufferContract w2;
    LayerBufferContract b2;
    LayerBufferContract gamma;
    LayerBufferContract beta;
};

inline offset_t layer_word_offset(offset_t base_word,
                                  offset_t layer_stride_words,
                                  unsigned int layer_index) {
#pragma HLS INLINE
    return base_word + static_cast<offset_t>(layer_index) * layer_stride_words;
}

}  // namespace bert

#endif
