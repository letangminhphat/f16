#ifndef BERT_LAYOUT_H
#define BERT_LAYOUT_H

#include "bert_config.h"
#include "bert_types.h"

namespace bert {

inline int ceil_div(int value, int divisor) {
#pragma HLS INLINE
    return (value + divisor - 1) / divisor;
}

inline offset_t hidden_index(int token, int hidden) {
#pragma HLS INLINE
    return static_cast<offset_t>(token) * HIDDEN_SIZE + hidden;
}

// Q/K/V stream layout is [head][token][head_dim].
inline offset_t qkv_index(int head, int token, int dim) {
#pragma HLS INLINE
    return (static_cast<offset_t>(head) * SEQ_LEN + token) * HEAD_DIM + dim;
}

inline offset_t context_index(int token, int hidden) {
#pragma HLS INLINE
    return hidden_index(token, hidden);
}

inline offset_t ffn_index(int token, int intermediate) {
#pragma HLS INLINE
    return static_cast<offset_t>(token) * FFN_INTERMEDIATE + intermediate;
}

inline offset_t mask_index(int key_token) {
#pragma HLS INLINE
    return key_token;
}

// Physical weight layout:
// [input_tile][output_tile][input_lane][output_lane], with zero-padded tails.
inline offset_t weight_tile_index(int input_index,
                                  int output_index,
                                  int output_dim,
                                  int tile_k,
                                  int tile_n) {
#pragma HLS INLINE
    const int output_tiles = ceil_div(output_dim, tile_n);
    const int input_tile = input_index / tile_k;
    const int output_tile = output_index / tile_n;
    const int input_lane = input_index % tile_k;
    const int output_lane = output_index % tile_n;
    return (((static_cast<offset_t>(input_tile) * output_tiles + output_tile) * tile_k
             + input_lane) * tile_n) + output_lane;
}

inline offset_t packed_word_count(offset_t scalar_count) {
#pragma HLS INLINE
    return (scalar_count + AXI_LANES - 1) / AXI_LANES;
}

inline offset_t tile_major_matrix_scalars(int input_dim,
                                          int output_dim,
                                          int tile_k,
                                          int tile_n) {
#pragma HLS INLINE
    return static_cast<offset_t>(ceil_div(input_dim, tile_k))
         * ceil_div(output_dim, tile_n) * tile_k * tile_n;
}

inline offset_t tile_major_matrix_words(int input_dim,
                                        int output_dim,
                                        int tile_k,
                                        int tile_n) {
#pragma HLS INLINE
    return packed_word_count(tile_major_matrix_scalars(input_dim, output_dim,
                                                        tile_k, tile_n));
}

}  // namespace bert

#endif
