#ifndef BERT_QUANTIZATION_H
#define BERT_QUANTIZATION_H

#include "bert_types.h"

namespace bert {

// The audited source is FP32. This explicit identity policy reserves a stable
// interface for a later calibrated W8A8 profile without silently quantizing now.
struct QuantizationPolicy {
    float scale;
    int zero_point;
    bool enabled;
};

inline input_t quantize_input_identity(float value, const QuantizationPolicy&) {
#pragma HLS INLINE
    return value;
}

inline output_t dequantize_output_identity(accum_t value,
                                           const QuantizationPolicy&) {
#pragma HLS INLINE
    return value;
}

}  // namespace bert

#endif
