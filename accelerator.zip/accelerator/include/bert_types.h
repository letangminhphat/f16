#ifndef BERT_TYPES_H
#define BERT_TYPES_H

#include <ap_axi_sdata.h>
#include <ap_int.h>
#include <hls_stream.h>
#include <stdint.h>

#include "bert_config.h"

namespace bert {

typedef float input_t;
typedef float weight_t;
typedef float bias_t;
typedef float accum_t;
typedef float output_t;
typedef float softmax_accum_t;
typedef float layernorm_accum_t;

typedef ap_uint<AXI_BITS> axi_word_t;
typedef ap_axiu<AXI_BITS, 0, 0, 0> axis_word_t;
typedef hls::stream<axis_word_t> tensor_stream_t;
typedef ap_uint<32> index_t;
typedef unsigned long long offset_t;

union fp32_bits_t {
    float fp;
    uint32_t bits;
};

inline ap_uint<32> scalar_to_bits(float value) {
#pragma HLS INLINE
    fp32_bits_t converted;
    converted.fp = value;
    return ap_uint<32>(converted.bits);
}

inline float bits_to_scalar(ap_uint<32> value) {
#pragma HLS INLINE
    fp32_bits_t converted;
    converted.bits = value.to_uint();
    return converted.fp;
}

}  // namespace bert

#endif
