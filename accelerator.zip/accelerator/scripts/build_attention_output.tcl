open_project -reset build_attention_output_hls
set_top bert_attention_output_norm_kernel
add_files ../kernels/bert_attention_output_norm_kernel.cpp \
    -cflags "-I../include -I../common -I../config"

open_solution -reset solution1 -flow_target vitis
set_part xcu250-figd2104-2L-e
create_clock -period 5.000 -name default

config_interface -m_axi_addr64

csynth_design
exit
