#ifndef BERT_RESIDUAL_HLS_H
#define BERT_RESIDUAL_HLS_H

#include "bert_types.h"

namespace bert {

template <int N>
void residual_add_token(const float projection[N],
                        const float residual[N],
                        float result[N]) {
residual_add_loop:
    for (int hidden = 0; hidden < N; ++hidden) {
#pragma HLS PIPELINE II=1
        result[hidden] = projection[hidden] + residual[hidden];
    }
}

}  // namespace bert

#endif
