#ifndef BERT_PACKED_IO_H
#define BERT_PACKED_IO_H

#include "bert_layout.h"
#include "bert_types.h"

namespace bert {

// Lane 0 contains the lowest-addressed scalar and occupies bits [31:0].
inline void pack_scalar_array(const float scalars[AXI_LANES], axi_word_t& word) {
#pragma HLS INLINE
pack_lanes:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
        word.range((lane + 1) * SCALAR_BITS - 1, lane * SCALAR_BITS) =
            scalar_to_bits(scalars[lane]);
    }
}

inline void unpack_scalar_array(const axi_word_t& word, float scalars[AXI_LANES]) {
#pragma HLS INLINE
unpack_lanes:
    for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
        const ap_uint<32> bits =
            word.range((lane + 1) * SCALAR_BITS - 1, lane * SCALAR_BITS);
        scalars[lane] = bits_to_scalar(bits);
    }
}

inline float load_packed_scalar(const axi_word_t* memory,
                                offset_t base_word,
                                offset_t scalar_index) {
#pragma HLS INLINE
    const offset_t word_index = base_word + scalar_index / AXI_LANES;
    const int lane = static_cast<int>(scalar_index % AXI_LANES);
    const axi_word_t word = memory[word_index];
    return bits_to_scalar(word.range((lane + 1) * SCALAR_BITS - 1,
                                     lane * SCALAR_BITS));
}

inline void store_packed_scalar(axi_word_t* memory,
                                offset_t base_word,
                                offset_t scalar_index,
                                float value) {
#pragma HLS INLINE
    const offset_t word_index = base_word + scalar_index / AXI_LANES;
    const int lane = static_cast<int>(scalar_index % AXI_LANES);
    axi_word_t word = memory[word_index];
    word.range((lane + 1) * SCALAR_BITS - 1, lane * SCALAR_BITS) =
        scalar_to_bits(value);
    memory[word_index] = word;
}

template <int N>
void load_packed_vector(const axi_word_t* memory,
                        offset_t base_word,
                        float local[N]) {
load_vector_words:
    for (int word_index = 0; word_index < (N + AXI_LANES - 1) / AXI_LANES;
         ++word_index) {
#pragma HLS PIPELINE II=1
        float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        unpack_scalar_array(memory[base_word + word_index], lanes);
    load_vector_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int index = word_index * AXI_LANES + lane;
            if (index < N) {
                local[index] = lanes[lane];
            }
        }
    }
}

template <int N>
void store_packed_vector(axi_word_t* memory,
                         offset_t base_word,
                         const float local[N]) {
store_vector_words:
    for (int word_index = 0; word_index < (N + AXI_LANES - 1) / AXI_LANES;
         ++word_index) {
#pragma HLS PIPELINE II=1
        float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
    store_vector_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int index = word_index * AXI_LANES + lane;
            lanes[lane] = index < N ? local[index] : 0.0f;
        }
        axi_word_t word = 0;
        pack_scalar_array(lanes, word);
        memory[base_word + word_index] = word;
    }
}

template <int ROWS, int COLS>
void load_packed_matrix(const axi_word_t* memory,
                        offset_t base_word,
                        float matrix[ROWS][COLS]) {
    const int words_per_row = (COLS + AXI_LANES - 1) / AXI_LANES;
load_matrix_rows:
    for (int row = 0; row < ROWS; ++row) {
    load_matrix_words:
        for (int word_index = 0; word_index < words_per_row; ++word_index) {
#pragma HLS PIPELINE II=1
            float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
            unpack_scalar_array(
                memory[base_word + static_cast<offset_t>(row) * words_per_row
                       + word_index],
                lanes);
        load_matrix_lanes:
            for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                const int column = word_index * AXI_LANES + lane;
                if (column < COLS) {
                    matrix[row][column] = lanes[lane];
                }
            }
        }
    }
}

template <int ROWS, int COLS>
void store_packed_matrix(axi_word_t* memory,
                         offset_t base_word,
                         const float matrix[ROWS][COLS]) {
    const int words_per_row = (COLS + AXI_LANES - 1) / AXI_LANES;
store_matrix_rows:
    for (int row = 0; row < ROWS; ++row) {
    store_matrix_words:
        for (int word_index = 0; word_index < words_per_row; ++word_index) {
#pragma HLS PIPELINE II=1
            float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        store_matrix_lanes:
            for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
                const int column = word_index * AXI_LANES + lane;
                lanes[lane] = column < COLS ? matrix[row][column] : 0.0f;
            }
            axi_word_t packed = 0;
            pack_scalar_array(lanes, packed);
            memory[base_word + static_cast<offset_t>(row) * words_per_row
                   + word_index] = packed;
        }
    }
}

template <int ROWS, int COLS>
void load_contiguous_tile(const axi_word_t* memory,
                          offset_t base_word,
                          offset_t first_scalar,
                          int valid_rows,
                          int valid_cols,
                          int row_stride,
                          float tile[ROWS][COLS]) {
load_tile_rows:
    for (int row = 0; row < ROWS; ++row) {
    load_tile_cols:
        for (int col = 0; col < COLS; ++col) {
#pragma HLS PIPELINE II=1
            tile[row][col] = (row < valid_rows && col < valid_cols)
                ? load_packed_scalar(memory, base_word,
                                     first_scalar + static_cast<offset_t>(row) * row_stride + col)
                : 0.0f;
        }
    }
}

template <int ROWS, int COLS>
void store_contiguous_tile(axi_word_t* memory,
                           offset_t base_word,
                           offset_t first_scalar,
                           int valid_rows,
                           int valid_cols,
                           int row_stride,
                           const float tile[ROWS][COLS]) {
store_tile_rows:
    for (int row = 0; row < ROWS; ++row) {
    store_tile_cols:
        for (int col = 0; col < COLS; ++col) {
#pragma HLS PIPELINE II=1
            if (row < valid_rows && col < valid_cols) {
                store_packed_scalar(memory, base_word,
                                    first_scalar + static_cast<offset_t>(row) * row_stride + col,
                                    tile[row][col]);
            }
        }
    }
}

}  // namespace bert

#endif
