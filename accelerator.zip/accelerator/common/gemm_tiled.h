#ifndef BERT_GEMM_TILED_H
#define BERT_GEMM_TILED_H

#include "bias_hls.h"
#include "bert_layout.h"
#include "packed_io.h"

namespace bert {

template <int M, int K, int TM, int TK>
void load_activation_tile(const float input[M][K],
                          int row_base,
                          int input_base,
                          float tile[TM][TK]) {
load_activation_rows:
    for (int row = 0; row < TM; ++row) {
    load_activation_columns:
        for (int input_lane = 0; input_lane < TK; ++input_lane) {
#pragma HLS PIPELINE II=1
            const int global_row = row_base + row;
            const int global_input = input_base + input_lane;
            tile[row][input_lane] =
                (global_row < M && global_input < K)
                    ? input[global_row][global_input]
                    : 0.0f;
        }
    }
}

template <int K, int N, int TK, int TN>
void load_weight_tile(const axi_word_t* weights,
                      offset_t matrix_word_offset,
                      int input_base,
                      int output_base,
                      float tile[TK][TN]) {
    static_assert((TK * TN) % AXI_LANES == 0,
                  "A weight tile must contain a whole number of AXI words");
    const int output_tiles = (N + TN - 1) / TN;
    const int input_tile = input_base / TK;
    const int output_tile = output_base / TN;
    const offset_t tile_scalar_base =
        static_cast<offset_t>(input_tile * output_tiles + output_tile) * TK * TN;
load_weight_words:
    for (int word_index = 0; word_index < (TK * TN) / AXI_LANES; ++word_index) {
#pragma HLS PIPELINE II=1
        float lanes[AXI_LANES];
#pragma HLS ARRAY_PARTITION variable=lanes complete
        unpack_scalar_array(
            weights[matrix_word_offset + tile_scalar_base / AXI_LANES + word_index],
            lanes);
    load_weight_lanes:
        for (int lane = 0; lane < AXI_LANES; ++lane) {
#pragma HLS UNROLL
            const int flat = word_index * AXI_LANES + lane;
            const int input_lane = flat / TN;
            const int output_lane = flat % TN;
            const int global_input = input_base + input_lane;
            const int global_output = output_base + output_lane;
            tile[input_lane][output_lane] =
                (global_input < K && global_output < N) ? lanes[lane] : 0.0f;
        }
    }
}

template <int TM, int TN>
void clear_output_tile(float output[TM][TN]) {
clear_output_rows:
    for (int row = 0; row < TM; ++row) {
    clear_output_columns:
        for (int output_lane = 0; output_lane < TN; ++output_lane) {
#pragma HLS PIPELINE II=1
            output[row][output_lane] = 0.0f;
        }
    }
}

template <int TM, int TK, int TN>
void compute_output_tile(const float activation[TM][TK],
                         const float weight[TK][TN],
                         float output[TM][TN]) {
compute_input_groups:
    for (int input_base = 0; input_base < TK; input_base += MAC_LANES) {
    compute_output_groups:
        for (int output_base = 0; output_base < TN; output_base += OUT_PAR) {
        compute_rows:
            for (int row = 0; row < TM; ++row) {
#pragma HLS PIPELINE II=1
            compute_outputs:
                for (int output_lane = 0; output_lane < OUT_PAR; ++output_lane) {
#pragma HLS UNROLL
                    const int output_index = output_base + output_lane;
                    accum_t partial = 0.0f;
                compute_mac_lanes:
                    for (int mac_lane = 0; mac_lane < MAC_LANES; ++mac_lane) {
#pragma HLS UNROLL
                        const int input_index = input_base + mac_lane;
                        if (input_index < TK && output_index < TN) {
                            partial += activation[row][input_index]
                                     * weight[input_index][output_index];
                        }
                    }
                    if (output_index < TN) {
                        output[row][output_index] += partial;
                    }
                }
            }
        }
    }
}

template <int N, int TM, int TN>
void add_bias(float output[TM][TN],
              const axi_word_t* parameters,
              offset_t bias_word_offset,
              int output_base) {
add_bias_rows:
    for (int row = 0; row < TM; ++row) {
    add_bias_columns:
        for (int output_lane = 0; output_lane < TN; ++output_lane) {
#pragma HLS PIPELINE II=1
            const int global_output = output_base + output_lane;
            if (global_output < N) {
                output[row][output_lane] +=
                    load_bias_value(parameters, bias_word_offset, global_output);
            }
        }
    }
}

template <int M, int N, int TM, int TN>
void store_output_tile(const float tile[TM][TN],
                       int row_base,
                       int output_base,
                       float output[M][N]) {
store_output_rows:
    for (int row = 0; row < TM; ++row) {
    store_output_columns:
        for (int output_lane = 0; output_lane < TN; ++output_lane) {
#pragma HLS PIPELINE II=1
            const int global_row = row_base + row;
            const int global_output = output_base + output_lane;
            if (global_row < M && global_output < N) {
                output[global_row][global_output] = tile[row][output_lane];
            }
        }
    }
}

template <int M, int N, int TM, int TN>
void postprocess_and_emit(const float tile[TM][TN],
                          int row_base,
                          int output_base,
                          float output[M][N]) {
#pragma HLS INLINE
    // Identity postprocess for the shared GEMM. GELU and AddNorm are fused by
    // their owning major kernels before any value leaves the chip.
    store_output_tile<M, N, TM, TN>(tile, row_base, output_base, output);
}

}  // namespace bert

#endif
