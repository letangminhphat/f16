#ifndef BERT_TILE_BUFFERS_H
#define BERT_TILE_BUFFERS_H

#include "bert_types.h"

namespace bert {

template <int TM, int TK, int TN>
struct GemmTileBuffers {
    input_t activation[TM][TK];
    weight_t weight[TK][TN];
    accum_t output[TM][TN];
};

template <int DIM>
struct TokenRowBuffer {
    float values[DIM];
};

template <int N, int D>
struct HeadActivationBuffer {
    float values[N][D];
};

}  // namespace bert

#endif
