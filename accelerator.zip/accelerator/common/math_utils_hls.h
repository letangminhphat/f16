#ifndef BERT_MATH_UTILS_HLS_H
#define BERT_MATH_UTILS_HLS_H

#include <hls_math.h>

#include "bert_types.h"

namespace bert {

template <typename T>
inline T min_value(T a, T b) {
#pragma HLS INLINE
    return a < b ? a : b;
}

template <typename T>
inline T max_value(T a, T b) {
#pragma HLS INLINE
    return a > b ? a : b;
}

inline float exact_exp(float value) {
#pragma HLS INLINE
    return hls::expf(value);
}

inline float exact_sqrt(float value) {
#pragma HLS INLINE
    return hls::sqrtf(value);
}

inline float exact_tanh(float value) {
#pragma HLS INLINE
    return hls::tanhf(value);
}

}  // namespace bert

#endif
