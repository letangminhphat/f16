#ifndef BERT_BIAS_HLS_H
#define BERT_BIAS_HLS_H

#include "packed_io.h"

namespace bert {

inline bias_t load_bias_value(const axi_word_t* parameters,
                              offset_t bias_word_offset,
                              int output_index) {
#pragma HLS INLINE
    return load_packed_scalar(parameters, bias_word_offset, output_index);
}

template <int N>
void add_bias_vector(float values[N],
                     const axi_word_t* parameters,
                     offset_t bias_word_offset) {
add_bias_vector_loop:
    for (int index = 0; index < N; ++index) {
#pragma HLS PIPELINE II=1
        values[index] += load_bias_value(parameters, bias_word_offset, index);
    }
}

}  // namespace bert

#endif
