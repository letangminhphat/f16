#ifndef BERT_LAYERNORM_HLS_H
#define BERT_LAYERNORM_HLS_H

#include "math_utils_hls.h"
#include "packed_io.h"

namespace bert {

template <int N>
layernorm_accum_t compute_mean(const float token[N]) {
    layernorm_accum_t sum = 0.0f;
compute_mean_loop:
    for (int index = 0; index < N; ++index) {
#pragma HLS PIPELINE II=1
        sum += token[index];
    }
    return sum / static_cast<float>(N);
}

template <int N>
layernorm_accum_t compute_variance(const float token[N],
                                   layernorm_accum_t mean) {
    layernorm_accum_t sum = 0.0f;
compute_variance_loop:
    for (int index = 0; index < N; ++index) {
#pragma HLS PIPELINE II=1
        const layernorm_accum_t difference = token[index] - mean;
        sum += difference * difference;
    }
    return sum / static_cast<float>(N);
}

template <int N>
void normalize_affine(const float token[N],
                      layernorm_accum_t mean,
                      layernorm_accum_t variance,
                      const axi_word_t* parameters,
                      offset_t gamma_word_offset,
                      offset_t beta_word_offset,
                      float output[N]) {
    const layernorm_accum_t inverse_std =
        1.0f / exact_sqrt(variance + LAYERNORM_EPSILON);
normalize_affine_loop:
    for (int index = 0; index < N; ++index) {
#pragma HLS PIPELINE II=1
        const float gamma = load_packed_scalar(parameters, gamma_word_offset, index);
        const float beta = load_packed_scalar(parameters, beta_word_offset, index);
        output[index] = gamma * (token[index] - mean) * inverse_std + beta;
    }
}

template <int N>
void layernorm_token(const float token[N],
                     const axi_word_t* parameters,
                     offset_t gamma_word_offset,
                     offset_t beta_word_offset,
                     float output[N]) {
    const layernorm_accum_t mean = compute_mean<N>(token);
    const layernorm_accum_t variance = compute_variance<N>(token, mean);
    normalize_affine<N>(token, mean, variance, parameters,
                        gamma_word_offset, beta_word_offset, output);
}

}  // namespace bert

#endif
