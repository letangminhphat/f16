# U250 candidate kernel mapping

This is a pre-route candidate, not a measured placement claim.

| Kernel | Candidate SLR | Input stream(s) | Output stream(s) | DDR dependency | Post-link checks |
|---|---|---|---|---|---|
| `bert_qkv_kernel` | SLR0 | hidden from DDR0 | Q, K, V, residual-A | DDR0 input; DDR1 QKV weights/parameters | SLR0 DSP/URAM, DDR1 bandwidth, crossings to SLR1 |
| `bert_attention_core_kernel` | SLR1 | Q, K, V | context | DDR0 mask | K/V BRAM, exp/div latency, stream stalls |
| `bert_attention_output_norm_kernel` | SLR1 | context, residual-A | FFN input, residual-B | DDR2 Wo/parameters | Combined SLR1 utilization and fan-out pressure |
| `bert_ffn_up_gelu_kernel` | SLR2 | FFN input | FFN intermediate | DDR2 W1/parameters | DDR2 contention with Wo, URAM, WNS |
| `bert_ffn_down_norm_kernel` | SLR3 | FFN intermediate, residual-B | hidden to DDR0 | DDR3 W2/parameters; DDR0 output | DDR3 bandwidth, SLR2-to-SLR3 crossing, output burst |

The physical stream direction is SLR0 → SLR1 → SLR2 → SLR3. The only long
bypass streams are residual-A (SLR0→SLR1) and residual-B (SLR1→SLR3).
After link, verify `report_utilization -slr`, timing/WNS/TNS, route status,
congestion, SLL crossings, DDR-port contention, and actual bank-to-SLR locality.

If SLR1 is overfull, the documented alternative is attention alone on SLR1,
Wo plus FFN UP on SLR2, and FFN DOWN on SLR3.
