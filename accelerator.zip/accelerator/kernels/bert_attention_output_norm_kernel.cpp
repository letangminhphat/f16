#include "bert_kernel_args.h"
#include "gemm_act_weight.h"
#include "layernorm_hls.h"
#include "residual_hls.h"
#include "stream_contracts.h"

using namespace bert;

/*
Architecture basis:
- Spatial FPGA: a coarse Wo/AddNorm stage with FIFO input/output.
- AutoTrans: linear and AddNorm work stay fused at a major-kernel boundary.
- ProTEA/Tiled QKV/UbiMoE: tiled projection, row buffering, and stream locality.

U250 adaptation:
- Shares candidate SLR1 with attention core; no projection intermediate reaches DDR.
*/
extern "C" void bert_attention_output_norm_kernel(
    const axi_word_t* wo_weights,
    const axi_word_t* attention_parameters,
    tensor_stream_t& context_in,
    tensor_stream_t& residual_in,
    tensor_stream_t& ffn_input_out,
    tensor_stream_t& ffn_residual_out,
    offset_t wo_base_word,
    offset_t wo_layer_stride_words,
    offset_t bo_base_word,
    offset_t gamma_base_word,
    offset_t beta_base_word,
    offset_t parameter_layer_stride_words,
    unsigned int layer_index) {
#pragma HLS INTERFACE m_axi port=wo_weights offset=slave bundle=gmem_wo \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=attention_parameters offset=slave bundle=gmem_wo \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE axis port=context_in
#pragma HLS INTERFACE axis port=residual_in
#pragma HLS INTERFACE axis port=ffn_input_out
#pragma HLS INTERFACE axis port=ffn_residual_out
#pragma HLS INTERFACE s_axilite port=wo_weights bundle=control
#pragma HLS INTERFACE s_axilite port=attention_parameters bundle=control
#pragma HLS INTERFACE s_axilite port=wo_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=wo_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=bo_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=gamma_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=beta_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=parameter_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=layer_index bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    float context[SEQ_LEN][HIDDEN_SIZE];
    float residual[SEQ_LEN][HIDDEN_SIZE];
    float projection[SEQ_LEN][HIDDEN_SIZE];
    float normalized[SEQ_LEN][HIDDEN_SIZE];
#pragma HLS BIND_STORAGE variable=context type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=residual type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=projection type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=normalized type=ram_2p impl=bram
#pragma HLS ARRAY_PARTITION variable=context cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=residual cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=projection cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=normalized cyclic factor=AXI_LANES dim=2

    stream_read_matrix<SEQ_LEN, HIDDEN_SIZE>(context_in, context);
    stream_read_matrix<SEQ_LEN, HIDDEN_SIZE>(residual_in, residual);

    const offset_t wo_word = layer_word_offset(
        wo_base_word, wo_layer_stride_words, layer_index);
    const offset_t bo_word = layer_word_offset(
        bo_base_word, parameter_layer_stride_words, layer_index);
    const offset_t gamma_word = layer_word_offset(
        gamma_base_word, parameter_layer_stride_words, layer_index);
    const offset_t beta_word = layer_word_offset(
        beta_base_word, parameter_layer_stride_words, layer_index);

    gemm_act_weight<SEQ_LEN, HIDDEN_SIZE, HIDDEN_SIZE,
                    TILE_M, TILE_K, TILE_N>(
        context, wo_weights, wo_word, attention_parameters, bo_word, projection);

attention_addnorm_tokens:
    for (int token = 0; token < SEQ_LEN; ++token) {
        float added[HIDDEN_SIZE];
#pragma HLS ARRAY_PARTITION variable=added cyclic factor=OUT_PAR
        residual_add_token<HIDDEN_SIZE>(projection[token], residual[token], added);
        layernorm_token<HIDDEN_SIZE>(added, attention_parameters,
                                     gamma_word, beta_word, normalized[token]);
    }

    // One copy feeds FFN UP; the second is the exact residual consumed by K5.
    stream_write_matrix<SEQ_LEN, HIDDEN_SIZE>(normalized, ffn_input_out);
    stream_write_matrix<SEQ_LEN, HIDDEN_SIZE>(normalized, ffn_residual_out);
}
