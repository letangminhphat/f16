#include "bert_kernel_args.h"
#include "gelu_hls.h"
#include "gemm_act_weight.h"
#include "stream_contracts.h"

using namespace bert;

/*
Architecture basis:
- Spatial FPGA: FFN UP is an independent compute-heavy pipeline stage.
- AutoTrans: an A-W linear engine fuses its elementwise post-operation.
- ProTEA/Tiled QKV/UbiMoE: tile-major weights, input reuse, and stage-specific parallelism.

U250 adaptation:
- Separate FFN-UP tile profile on candidate SLR2; pre-GELU data never leaves on-chip RAM.
*/
extern "C" void bert_ffn_up_gelu_kernel(
    const axi_word_t* w1_weights,
    const axi_word_t* ffn_up_parameters,
    tensor_stream_t& ffn_input_in,
    tensor_stream_t& ffn_intermediate_out,
    offset_t w1_base_word,
    offset_t w1_layer_stride_words,
    offset_t b1_base_word,
    offset_t b1_layer_stride_words,
    unsigned int layer_index) {
#pragma HLS INTERFACE m_axi port=w1_weights offset=slave bundle=gmem_w1 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE m_axi port=ffn_up_parameters offset=slave bundle=gmem_w1 \
    max_read_burst_length=64 num_read_outstanding=32
#pragma HLS INTERFACE axis port=ffn_input_in
#pragma HLS INTERFACE axis port=ffn_intermediate_out
#pragma HLS INTERFACE s_axilite port=w1_weights bundle=control
#pragma HLS INTERFACE s_axilite port=ffn_up_parameters bundle=control
#pragma HLS INTERFACE s_axilite port=w1_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=w1_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=b1_base_word bundle=control
#pragma HLS INTERFACE s_axilite port=b1_layer_stride_words bundle=control
#pragma HLS INTERFACE s_axilite port=layer_index bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    float input[SEQ_LEN][HIDDEN_SIZE];
    float intermediate[SEQ_LEN][FFN_INTERMEDIATE];
#pragma HLS BIND_STORAGE variable=input type=ram_2p impl=bram
#pragma HLS BIND_STORAGE variable=intermediate type=ram_2p impl=uram
#pragma HLS ARRAY_PARTITION variable=input cyclic factor=AXI_LANES dim=2
#pragma HLS ARRAY_PARTITION variable=intermediate cyclic factor=AXI_LANES dim=2

    stream_read_matrix<SEQ_LEN, HIDDEN_SIZE>(ffn_input_in, input);
    const offset_t w1_word = layer_word_offset(
        w1_base_word, w1_layer_stride_words, layer_index);
    const offset_t b1_word = layer_word_offset(
        b1_base_word, b1_layer_stride_words, layer_index);

    gemm_act_weight<SEQ_LEN, HIDDEN_SIZE, FFN_INTERMEDIATE,
                    TILE_M, BERT_FFN_UP_TILE_K, BERT_FFN_UP_TILE_N>(
        input, w1_weights, w1_word, ffn_up_parameters, b1_word, intermediate);

ffn_up_gelu_tokens:
    for (int token = 0; token < SEQ_LEN; ++token) {
        gelu_vector<FFN_INTERMEDIATE>(intermediate[token]);
    }
    stream_write_matrix<SEQ_LEN, FFN_INTERMEDIATE>(
        intermediate, ffn_intermediate_out);
}
